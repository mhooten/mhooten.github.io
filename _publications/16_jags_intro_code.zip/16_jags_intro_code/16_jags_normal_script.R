######################################
####                              ####
#### Using JAGS for Normal Models ####
####                              ####
######################################

###
### Load data
###

MD.df = read.csv("MedicalData.csv", header=TRUE)
MD.df

y = MD.df$BP[MD.df$Age=="adult"] # extract adults' blood pressure readings
hist(y,main="Blood Pressure",xlab="y")
rug(y)

n=length(y)
n

###
### Fit a Hierarchical-Poisson Model assuming p and all N are unknown (but lambda is known) 
### Assess convergence and report posterior inference
###

library(rjags)

m.jags <- "
  model{
    for(i in 1:n){
      y[i] ~ dnorm(mu, tau)
    }
    mu ~ dnorm(mu_0, tau_0)
    tau ~ dgamma(alpha, beta)
    s2 = 1/tau
  }
"

## NOTES: - the second parameter in a JAGS normal distribution is PRECISION
##.       - JAGS' gamma distribution uses the rate parameterization
##        - assuming variance~IG(a,b) is equivalent to assuming precision~G(a,b)
##        - we can compute derived quantities inside JAGS if we need them

n.mcmc = 10000
n.burn = round(0.2*n.mcmc)
mod = textConnection(m.jags)

m.out = jags.model(mod, data = list("y" = y, "n" = n, "alpha" = 0.01, "beta" = 0.01, "mu_0" = 0, "tau_0" = 1/(10^6)), n.chains = 3, n.adapt = 0)
m.samples = jags.samples(m.out, c("mu", "tau", "s2"), n.mcmc)

matplot(m.samples$mu[1,,], type = "l", col = 1:3, lty = 1, ylab = expression(mu), xlab = "iteration")
apply(m.samples$mu[1,,], 2, mean)
apply(m.samples$mu[1,,], 2, quantile, c(0.05,0.975))

matplot(m.samples$tau[1,,], type = "l", col = 1:3, lty = 1, ylab = expression(tau), xlab = "iteration")

matplot(m.samples$s2[1,,], type = "l", col = 1:3, lty = 1, ylab = expression(sigma^2), xlab = "iteration")
apply(m.samples$s2[1,,], 2, mean)
apply(m.samples$s2[1,,], 2, quantile, c(0.05,0.975))

m.samples = coda.samples(m.out, c("mu", "s2"), n.mcmc)
gelman.diag(m.samples)

## Compare to previous MCMC output:
## mu: posterior mean = 72.68388 (70.46853, 74.87032)
## s2: posterior mean = 123.919 (93.75129, 163.53589)
