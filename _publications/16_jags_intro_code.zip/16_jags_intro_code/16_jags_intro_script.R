########################
####                ####
#### Intro. to JAGS ####
####                ####
########################

###
### Read data for binomial model
###

fish.df = read.table("mosquitofish.txt", header = TRUE)
head(fish.df)

n = 32 # the groups of fish that were only counted once
y = fish.df$N1[1:n]
N = fish.df$N0[1:n]

plot(N, y, asp = TRUE)
abline(0, 1)

###
### Fit Binomial Model in JAGS with 1 Chain
###

library(rjags)

m.jags <- "
  model{
    for(i in 1:n){
      y[i] ~ dbin(p, N[i])
    }
    p ~ dbeta(alpha, beta)
  }
"

## m.jags is a string that contains the model statement that JAGS will read
## NOTES: - the for-loop structure is how JAGS works with vectors; when we work with vectors in JAGS, we'll need to use them
##        - JAGS has built-in PDF functions like dbin() which may differ from R conventions in name and parameterization
##        - we use tildas to relate a variable with its distribution

n.mcmc = 1000 # number of MCMC iterations 
n.burn = round(0.2*n.mcmc) # number of iterations for burn-in
mod = textConnection(m.jags) # puts m.jags string into correct format for JAGS

typeof(m.jags)
typeof(mod)

m.out = jags.model(mod, data = list("y" = y, "n" = n, "N" = N, "alpha" = 1, "beta" = 1), n.chains = 1, n.adapt = 0)
m.samples = jags.samples(m.out, c("p"), n.mcmc)

dim(m.samples$p)
plot(m.samples$p[1,,1], type = "l", lty = 1, ylab = "p", xlab = "iteration", ylim = c(0,1))

hist(m.samples$p[1,n.burn:n.mcmc,1], breaks = 30, xlim = c(0,1), prob = TRUE, xlab = "p", ylab = "density", main = "")
lines(density(m.samples$p[1,n.burn:n.mcmc,1]), lwd = 2, col = 2)

acf(m.samples$p[1,,1])

###
### Fit Binomial Model in JAGS with 3 Chains
###

mod = textConnection(m.jags) # necessary to initialize the algorithm again
m.out = jags.model(mod, data = list("y" = y, "n" = n, "N" = N, "alpha" = 1, "beta" = 1), n.chains = 3, n.adapt = 0)
m.samples = jags.samples(m.out, c("p"), n.mcmc)

###
### Manually Compute Gelman-Rubin Statistic / Potential Scale Reduction Factor
###

matplot(m.samples$p[1,,], type = "l", col = 1:3, lty = 1, ylab = "p", xlab = "iteration", ylim = c(0,1))

keep.idx = n.burn:n.mcmc
K = length(keep.idx)
w = mean(apply(m.samples$p[1, keep.idx,], 2, var))
b = K*var(apply(m.samples$p[1, keep.idx,], 2, mean))
v.hat = w*(K-1)/K + b/K
r.hat = sqrt(v.hat/w)
r.hat

###
### Compute G-R in CODA
###

library(coda)

m.samples # mcarray using jags.samples()
m.samples = coda.samples(m.out, c("p"), n.mcmc)
m.samples # mcmc.list using coda.samples()

gelman.diag(m.samples) # requires mcmc.list object as input

###
### In-class Breakout Session - Simulate Data
###

n = 10
lambda = 20
N = rpois(n, lambda)
p = 0.8
y = rbinom(n, N, p)

plot(N, y, xlim = c(0, max(N)), ylim = c(0, max(N)))
abline(0, 1)

###
### Fit a Binomial-Poisson Model assuming p and all N are unknown (but lambda is known) 
### Assess convergence and report posterior inference
###

library(rjags)

m.jags <- "
  model{
    for(i in 1:n){
      y[i] ~ dbin(p, N[i])
      N[i] ~ dpois(lam)
    }
    p ~ dbeta(alpha, beta)
  }
"