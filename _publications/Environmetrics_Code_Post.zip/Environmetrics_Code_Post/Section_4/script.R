###
###  Libraries and Subroutines 
###

library(tictoc)
library(PoissonBinomial)

logit<-function(p){
  log(p/(1-p))
}

logit.inv<-function(x){
  exp(x)/(1+exp(x)) 
}

crossdist <- function(S1,S2) {
    c1 <- complex(real=S1[,1], imaginary=S1[,2])
    c2 <- complex(real=S2[,1], imaginary=S2[,2])
    dist <- outer(c1, c2, function(z1, z2) Mod(z1-z2))
    dist
}

###
###  Read in data
###

load("snowshoe.RData")

if(FALSE){
par(mar=c(2,1.5,2,1.5))
layout(matrix(1:15,3,5,byrow=TRUE))
for(i in 1:n){
  plot(A,type="n",asp=TRUE,main=i,xlab="",ylab="",xaxt="n",yaxt="n")
  text(matrix(X[Y[i,]==0,],,2),labels=Y[i,Y[i,]==0],cex=1,col=rgb(0,0,0,.3))
  text(matrix(X[Y[i,]>0,],,2),labels=Y[i,Y[i,]>0],cex=1.5,col=1)
  polygon(A,lwd=1.5,lty=3,border=rgb(0,0,0,.5))
}
}

###
###  Fit SCR Model w/ single-stage algorithm (JAGS) 
###

n.mcmc=100000

source("scr.0.mcmc.jags.R") 
tic()
out.0=scr.0.mcmc(Y,J,M,X,A,n.mcmc)
toc.0=toc()

if(FALSE){
  layout(matrix(1:3,3,1))
  plot(out.0$beta.save[1,],type="l")
  plot(out.0$beta.save[2,],type="l")
  plot(out.0$psi.save,type="l")
}

###
###  Fit SCR Model w/ Stage 1 Algorithm 
###

source("scr.stg.1.R")  
tic()
out.1=scr.stg.1(Y,J,M,X,A,n.mcmc)
toc.1=toc()

if(FALSE){
  layout(matrix(1:3,3,1))
  plot(out.1$beta.star[1,],type="l")
  plot(out.1$beta.star[2,],type="l")
  plot(out.1$psi.star,type="l")
}

###
###  Fit SCR Model w/ Stage 2 Algorithm (Poisson-Binom)
###

source("scr.stg.2.Pb.R")   
tic()
out.2.Pb=scr.stg.2.Pb(n,J,L,M,X,A,out.1)
toc.2.Pb=toc()

if(FALSE){
  layout(matrix(1:3,3,1))
  plot(out.2.Pb$beta.save[1,],type="l",lty=1)
  plot(out.2.Pb$beta.save[2,],type="l",lty=1)
  plot(out.2.Pb$psi.save,type="l")
}

###
###  Fit SCR Model w/ Stage 2 Algorithm (Poisson)
###

source("scr.stg.2.P.R")   
tic()
out.2.P=scr.stg.2.P(n,J,L,M,X,A,out.1)
toc.2.P=toc()

if(FALSE){
  layout(matrix(1:3,3,1))
  plot(out.2.P$beta.save[1,],type="l",lty=1)
  plot(out.2.P$beta.save[2,],type="l",lty=1)
  plot(out.2.P$psi.save,type="l")
}

###
###  Sample N from Full-Conditional 
###

n.sim=10000
S.sim=cbind(runif(n.sim,min(A[,1]),max(A[,1])),runif(n.sim,min(A[,2]),max(A[,2])))
D2.sim=crossdist(S.sim,X)^2  # n.sim x L matrix of distances b/w S.sim and X

library(foreach)
library(doParallel)

cores=detectCores()
print(cores)
cl <- makeCluster(cores[1], setup_strategy = "sequential")
registerDoParallel(cl)

tic() # Poisson-binomial
N.2.Pb.parallel=rep(0,n.mcmc)
N.2.Pb.parallel <- foreach(k=1:n.mcmc) %dopar% {
  P.2.Pb.sim=logit.inv(out.2.Pb$beta.save[1,k]+out.2.Pb$beta.save[2,k]*D2.sim)
  num.2.Pb.tmp=out.2.Pb$psi.save[k]*apply((1-P.2.Pb.sim)^J,1,prod)
  psi.2.Pb.bar=mean(num.2.Pb.tmp/(num.2.Pb.tmp+1-out.2.Pb$psi.save[k]))
  n+rbinom(1,M-n,psi.2.Pb.bar)
}
N.out.2.Pb = unlist(N.2.Pb.parallel)
toc.2.Pb.par=toc()

tic() # Poisson
N.2.P.parallel=rep(0,n.mcmc)
N.2.P.parallel <- foreach(k=1:n.mcmc) %dopar% {
  P.2.P.sim=logit.inv(out.2.P$beta.save[1,k]+out.2.P$beta.save[2,k]*D2.sim)
  num.2.P.tmp=out.2.P$psi.save[k]*apply((1-P.2.P.sim)^J,1,prod)
  psi.2.P.bar=mean(num.2.P.tmp/(num.2.P.tmp+1-out.2.P$psi.save[k]))
  n+rpois(1,(M-n)*psi.2.P.bar) 
}
N.out.2.P = unlist(N.2.P.parallel)
toc.2.P.par=toc()

###
### Plot posteriors for parameters
###

if(FALSE){
col.1.1=rgb(1,.65,0,alpha=.8)
col.1.2=rgb(1,.65,0,alpha=.4)
col.2.1=rgb(.4,.6,.8,alpha=.8)
col.2.2=rgb(.4,.6,.8,alpha=.4)
bw1=bw.nrd(out.2.Pb$beta.save[1,])*1.7
bw2=bw.nrd(out.2.Pb$beta.save[2,])*1.7
bw3=bw.nrd(out.2.Pb$psi.save)*1.7
tab.0=table(c(out.0$N.save,seq(n,M,1)))/n.mcmc
tab.1=table(c(N.out.2.Pb,seq(n,M,1)))/n.mcmc
tab.2=table(c(N.out.2.P,seq(n,M,1)))/n.mcmc
attributes(tab.2)$dimnames[[1]]=as.numeric(attributes(tab.2)$dimnames[[1]])+.25
layout(matrix(1:4,2,2))
plot(density(out.2.Pb$beta.save[1,],bw=bw1),lwd=2,col=col.1.1,ylab="density",main="a",xlab=bquote(beta[0]))
lines(density(out.2.P$beta.save[1,],bw=bw1),lwd=2,col=col.2.1,lty=2)
legend("topleft",col=c(col.1.1,col.2.1),lwd=2,lty=c(1,2,1),legend=c("Pois-binom","Pois"),bty="n")
plot(density(out.2.Pb$beta.save[2,],bw=bw2),lwd=2,col=col.1.1,ylab="density",main="b",xlab=bquote(beta[1]))
lines(density(out.2.P$beta.save[2,],bw=bw2),lwd=2,lty=2,col=col.2.1)
plot(density(out.2.Pb$psi.save,bw=bw3),lwd=2,col=col.1.1,ylab="density",main="c",xlab=bquote(psi),xlim=c(0,1))
lines(density(out.2.P$psi.save,bw=bw3),lwd=2,lty=2,col=col.2.1)
plot(tab.1,col=col.1.1,type="h",xlim=c(0,M/2),ylim=c(0,max(tab.1,tab.2)),ylab="probability",xlab="N",lwd=2,main="d",xaxt="n")
lines(tab.2,col=col.2.1,type="h",lty=1,lwd=1) 
axis(1,round(seq(0,M,,40)))
abline(v=n,lwd=1.5,lty=3,col=rgb(0,0,0,.7))
legend("topright",lty=3,col=rgb(0,0,0,.7),lwd=1.5,legend=c("n"),bty="n")
}

###
###  Inference for detection probability function p  
###

mean(logit.inv(out.2.Pb$beta.save[1,]))
mean(logit.inv(out.2.Pb$beta.save[1,]+out.2.Pb$beta.save[2,]*(100^2)))
mean(logit.inv(out.2.P$beta.save[1,]))
mean(logit.inv(out.2.P$beta.save[1,]+out.2.P$beta.save[2,]*(100^2)))

n.p=100
d.vec=seq(0,max(dist(X))/2,,n.p)
P.2.Pb.mat=matrix(0,n.mcmc,n.p)
P.2.P.mat=matrix(0,n.mcmc,n.p)
for(j in 1:n.p){
  P.2.Pb.mat[,j]=logit.inv(out.2.Pb$beta.save[1,]+out.2.Pb$beta.save[2,]*(d.vec[j]^2))
  P.2.P.mat[,j]=logit.inv(out.2.P$beta.save[1,]+out.2.P$beta.save[2,]*(d.vec[j]^2))
}
P.2.Pb.l=apply(P.2.Pb.mat,2,quantile,.025)
P.2.Pb.u=apply(P.2.Pb.mat,2,quantile,.975)
P.2.Pb.m=apply(P.2.Pb.mat,2,mean)
P.2.P.l=apply(P.2.P.mat,2,quantile,.025)
P.2.P.u=apply(P.2.P.mat,2,quantile,.975)
P.2.P.m=apply(P.2.P.mat,2,mean)

if(FALSE){
  plot(d.vec,P.2.Pb.m,type="n",ylim=c(0,max(P.2.Pb.u,P.2.Pb.u)),xlab="distance (m)",ylab="p")
  polygon(c(d.vec,rev(d.vec)),c(P.2.Pb.u,rev(P.2.Pb.l)),border=NA,col=col.1.2)
  lines(d.vec,P.2.Pb.m,col=col.1.1,lwd=2)
  polygon(c(d.vec,rev(d.vec)),c(P.2.P.u,rev(P.2.P.l)),border=NA,col=col.2.2,density=5,angle=90)
  lines(d.vec,P.2.P.m,col=col.2.1,lwd=2,lty=2)
  legend("topright",lty=c(1,1,1,3),lwd=c(5,2,1,2),col=c(col.1.2,col.1.1,col.2.2,col.2.1),legend=c("P-b 95% CI","P-b mean","Pois 95% CI","Pois mean"),bty="n")
}


###
###  Inference for N
###

mean(N.out.2.Pb)
quantile(N.out.2.Pb,c(0.025,0.975)) 

mean(N.out.2.P) 
quantile(N.out.2.P,c(0.025,0.975))

###
###  Posterior Power to Detect 
###

n.sim=10000
S.X.sim=cbind(runif(n.sim,min(A[,1]),max(A[,1])),runif(n.sim,min(A[,2]),max(A[,2])))
D2.X.sim=crossdist(S.sim,X)^2  # n.sim x L matrix of distances b/w S.sim and X

ptd.2.Pb=0
ptd.2.P=0
for(k in 1:n.mcmc){
  if(k%%10000==0){cat(k," ")}
  tmp.idx=sample(1:n.sim,1)
  p.2.Pb.vec=logit.inv(out.2.Pb$beta.save[1,k]+out.2.Pb$beta.save[2,k]*D2.sim[tmp.idx,])
  p.2.P.vec=logit.inv(out.2.P$beta.save[1,k]+out.2.P$beta.save[2,k]*D2.sim[tmp.idx,])
  y.2.Pb.vec=rbinom(L,J,p.2.Pb.vec)
  y.2.P.vec=rbinom(L,J,p.2.P.vec)
  ptd.2.Pb=ptd.2.Pb+(sum(y.2.Pb.vec)>0)/n.mcmc
  ptd.2.P=ptd.2.P+(sum(y.2.P.vec)>0)/n.mcmc
};cat("\n")

ptd.2.Pb
ptd.2.P

###
###  Alternative Posterior Power to Detect 
###

ptd.2.Pb.alt=mean(n/N.out.2.Pb)
ptd.2.P.alt=mean(n/N.out.2.P)

ptd.2.Pb.alt
ptd.2.P.alt

###
###  Timing of MCMC algorithms 
###

time.mins.0=(toc.0$toc - toc.0$tic)/60
time.mins.1=(toc.1$toc - toc.1$tic)/60
time.mins.2.Pb=(toc.2.Pb$toc - toc.2.Pb$tic)/60
time.mins.2.P=(toc.2.P$toc - toc.2.P$tic)/60

paste(round(time.mins.0, 3), " min elapsed", sep = "")
paste(round(time.mins.1, 3), " min elapsed", sep = "")
paste(round(time.mins.2.Pb, 3), " min elapsed", sep = "")
paste(round(time.mins.2.P, 3), " min elapsed", sep = "")

###
###   Calc. effective sample size (for mu)
###

library(coda)
mcmc.0=as.mcmc(out.0$beta.save[1,])
mcmc.2.Pb=as.mcmc(out.2.Pb$beta.save[1,])
mcmc.2.P=as.mcmc(out.2.P$beta.save[1,])

n.eff.0=effectiveSize(mcmc.0)
n.eff.2.Pb=effectiveSize(mcmc.2.Pb)
n.eff.2.P=effectiveSize(mcmc.2.P)

c(n.eff.0,n.eff.2.Pb,n.eff.2.P)

time.per.eff.iter.0=time.mins.0/n.eff.0
time.per.eff.iter.2.Pb=(time.mins.1+time.mins.2.Pb)/n.eff.2.Pb
time.per.eff.iter.2.P=(time.mins.1+time.mins.2.P)/n.eff.2.P

c(time.per.eff.iter.0,time.per.eff.iter.2.Pb,time.per.eff.iter.2.P)

