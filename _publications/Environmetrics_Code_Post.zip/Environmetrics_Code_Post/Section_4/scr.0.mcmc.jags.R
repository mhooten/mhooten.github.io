scr.0.mcmc <- function(Y,J,M,X,A,n.mcmc){

###
###  Libraries and Subroutines 
###

library(rjags)
library(coda)

logit <- function(p){
  log(p)-log(1-p)
}

logit.inv <- function(x){
  exp(x)/(1+exp(x)) 
}

###
###  Setup Variables 
###

n=dim(Y)[1]
L=dim(Y)[2]

x.lims=range(A[,1])
y.lims=range(A[,2])

Y.aug=rbind(Y,matrix(0,M-n,L))

###
###  Priors and Starting Values 
###

beta=c(-2,-.0001)
psi=mean(n/M,1)

S=matrix(0,M,2)
#for(i in 1:n){
#  S[i,1]=X[Y[i,]==max(Y[i,]),1][1]
#  S[i,2]=X[Y[i,]==max(Y[i,]),2][1]
#}
#S[-(1:n),1]=runif(M-n,x.lims[1],x.lims[2])
#S[-(1:n),2]=runif(M-n,y.lims[1],y.lims[2])

S[,1]=runif(M,x.lims[1],x.lims[2])
S[,2]=runif(M,y.lims[1],y.lims[2])

mu=0
tau=1/1000

a=1
b=1

###
###  Specify CR Model in JAGS
###

m.jags <-"
  model{
    for(i in 1:M){
      for(l in 1:L){
        Y[i,l] ~ dbin(z[i]*P[i,l],J) 
      }
    }
    for(i in 1:M){
      z[i] ~ dbin(psi,1)
      for(l in 1:L){
        P[i,l] <- ilogit(beta0+beta1*(pow(S[i,1]-X[l,1],2) + pow(S[i,2]-X[l,2],2)))
      }
      S[i,1] ~ dunif(xlims[1],xlims[2])
      S[i,2] ~ dunif(ylims[1],ylims[2])
    }
    psi ~ dbeta(a,b)
    beta0 ~ dnorm(mu,tau)
    beta1 ~ dnorm(mu,tau)
    N<-sum(z[1:M])
}
"

n.burn=round(.2*n.mcmc)
mod<-textConnection(m.jags) # read model

###
###  Fit Model using JAGS
###

m.out<-jags.model(mod,data=list('Y'=Y.aug,'M'=M,'J'=J,'L'=L,'xlims'=x.lims,'ylims'=y.lims,'mu'=mu,'tau'=tau,'X'=X,'a'=a,'b'=b),inits=list(beta0=beta[1],beta1=beta[2],psi=psi,z=rep(1,M),S=S),n.chains=1,n.adapt=0) 

m.samples=jags.samples(m.out,c('psi','beta0','beta1','N'),n.mcmc)

psi.save=c(m.samples$psi[1,,1])
beta.save=rbind(c(m.samples$beta0[1,,1]),c(m.samples$beta1[1,,1]))
N.save=c(m.samples$N[1,,1])

###
###  Write Output 
###

list(psi.save=psi.save,n.mcmc=n.mcmc,beta.save=beta.save,N.save=N.save,mu=mu,s2=1/tau)

}
