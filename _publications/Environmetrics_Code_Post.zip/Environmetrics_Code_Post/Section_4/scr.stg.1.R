scr.stg.1 <- function(Y,J,M,X,A,n.mcmc){

###
###  Libraries and Subroutines 
###
  
logit <- function(p){
  log(p)-log(1-p)
}

logit.inv <- function(x){
  exp(x)/(1+exp(x)) 
}

crossdist <- function(S1,S2) { 
    c1 <- complex(real=S1[,1], imaginary=S1[,2]) 
    c2 <- complex(real=S2[,1], imaginary=S2[,2]) 
    dist <- outer(c1, c2, function(z1, z2) Mod(z1-z2)) 
    dist 
} 

###
###  Setup Variables 
###

n=dim(Y)[1]
L=dim(Y)[2]

###
###  Priors and Starting Values 
###

x.lims=range(A[,1])
y.lims=range(A[,2])

psi=n/M
a=1
b=1
beta=c(-2,-.0001)

mu.beta=rep(0,2)
s2.beta=1000
sig.beta=sqrt(s2.beta)
beta.tune=c(1,.00001)

n.sim=1000
S.sim=cbind(runif(n.sim,x.lims[1],x.lims[2]),runif(n.sim,y.lims[1],y.lims[2]))
D2=t(crossdist(S.sim,X)^2)   # L x n.sim matrix of distances b/w S.sim and X

P=logit.inv(beta[1]+beta[2]*D2)  
p.detect=1-exp(J*apply(log(1-P),2,sum))
ldenom.int=n*log(mean(p.detect))

mh.2=sum(apply(Y,1,function(y,J,P){log(mean(exp(apply(dbinom(y,J,P,log=TRUE),2,sum))))},J=J,P=P))-ldenom.int+sum(dnorm(beta,mu.beta,sig.beta,log=TRUE))

###
###  Begin First-Stage MCMC Loop 
###

beta.star=matrix(0,2,n.mcmc)
psi.star=rbeta(n.mcmc,a,b)

for(k in 1:n.mcmc){
  if(k%%100==0) cat(k," ")

  ###
  ###  Sample beta
  ###

  beta.star.star=rnorm(2,beta,beta.tune)

  P.star.star=logit.inv(beta.star.star[1]+beta.star.star[2]*D2)  
  p.detect.star.star=1-exp(J*apply(log(1-P.star.star),2,sum))
  ldenom.int.star.star=n*log(mean(p.detect.star.star))

  mh.1=sum(apply(Y,1,function(y,J,P){log(mean(exp(apply(dbinom(y,J,P,log=TRUE),2,sum))))},J=J,P=P.star.star))-ldenom.int.star.star+sum(dnorm(beta.star.star,mu.beta,sig.beta,log=TRUE))

  mh=exp(mh.1-mh.2)
  if(mh > runif(1)){
    beta=beta.star.star
    P=P.star.star
    mh.2=mh.1
  }

  ###
  ###  Save Samples 
  ###
  
  beta.star[,k]=beta

};cat("\n")

###
###  Write Output 
###

list(n.mcmc=n.mcmc,beta.star=beta.star,psi.star=psi.star,a=a,b=b)

}
