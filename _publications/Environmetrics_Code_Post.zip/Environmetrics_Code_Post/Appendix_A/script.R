###
###  Simulate Data
###

set.seed(1001)
M=100
psi=.4
p=.25
z=rbinom(M,1,psi)
N=sum(z)
J=3
y.full=rbinom(M,J,p*z)
y=rep(0,M)
n=sum(y.full>0)
y[1:n]=y.full[y.full>0]

###
###  Fit C-R Full Model w/ PX-DA 
###

library(tictoc)
source("cr.0.mcmc.R")
n.mcmc=200000
tic()
out.0=cr.0.mcmc(y,J,n.mcmc)
toc()

###
###  Fit C-R Model w/ RB and PX-DA 
###

source("cr.1.mcmc.R")
tic()
out.1=cr.1.mcmc(y,J,n.mcmc)
toc()

layout(matrix(1:3,3,1))
plot(density(out.0$p.save),xlim=c(0,1),main="a",xlab="p",lwd=2,ylab="density")
lines(density(out.1$p.star),col=2,lwd=2)
lines(density(out.1$p.save),col=3,lwd=2)
abline(v=p,lty=3,col=rgb(0,0,0,.5),lwd=2)
legend("topright",col=c(1,2,3,rgb(0,0,0,.5)),lty=c(1,1,1,3),lwd=2,legend=c("Single-Stage","First-Stage","Second-Stage","p truth"),bty="n")
plot(density(out.0$psi.save),xlim=c(0,1),main="b",xlab=bquote(psi),lwd=2,ylab="density")
lines(density(out.1$psi.star),col=2,lwd=2)
lines(density(out.1$psi.save),col=3,lwd=2)
abline(v=psi,lty=3,col=rgb(0,0,0,.5),lwd=2)
legend("topright",col=rgb(0,0,0,.5),lwd=2,lty=3,legend=bquote(psi~"truth"),bty="n")
plot(table(c(out.0$N.save,seq(n,M,1)))/n.mcmc,col=1,type="l",xlim=c(0,M),ylab="probability",xlab="N",lwd=3,main="c")
lines(table(c(out.1$N.star,seq(n,M,1)))/n.mcmc,col=2,lwd=2)
lines(table(c(out.1$N.save,seq(n,M,1)))/n.mcmc,col=3,lwd=2)
abline(v=n,lty=2,col=rgb(0,0,0,.5),lwd=2)
abline(v=N,lty=3,col=rgb(0,0,0,.5),lwd=2)
legend("topright",col=rgb(0,0,0,.5),lwd=2,lty=c(2,3),legend=c("n","N truth"),bty="n")

