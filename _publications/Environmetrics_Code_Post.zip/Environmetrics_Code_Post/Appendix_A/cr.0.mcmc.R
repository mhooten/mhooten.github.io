cr.0.mcmc <- function(y,J,n.mcmc){

###
###  Setup Variables 
###

M=length(y)
n=sum(y>0)

psi.save=rep(0,n.mcmc)
p.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)
z.mean=rep(0,M)

###
###  Priors and Starting Values 
###

p=mean(y[y>0]/J)
psi=n/M
z=rep(0,M)
z[y>0]=1
alpha=1
beta=1

###
###  Begin MCMC Loop 
###

for(k in 1:n.mcmc){
  if(k%%10000==0) cat(k," ")

  ###
  ###  Sample z 
  ###

  psi.tmp=(psi*(1-p)^J)/(psi*(1-p)^J + 1-psi) 
  z[y==0]=rbinom(sum(y==0),1,psi.tmp)

  ###
  ###  Sample p 
  ###
 
  alpha.tmp=sum(y[z==1])+1
  beta.tmp=sum((J-y)[z==1])+1
  p=rbeta(1,alpha.tmp,beta.tmp)

  ###
  ###  Sample psi 
  ###

  alpha.tmp=sum(z)+alpha
  beta.tmp=M-sum(z)+beta
  psi=rbeta(1,alpha.tmp,beta.tmp)

  ###
  ###  Save Samples 
  ###
 
  z.mean=z.mean+z/n.mcmc
  p.save[k]=p
  psi.save[k]=psi
  N.save[k]=sum(z)

}
cat("\n")

###
###  Write Output 
###

list(z.mean=z.mean,N.save=N.save,p.save=p.save,psi.save=psi.save,n.mcmc=n.mcmc)

}
