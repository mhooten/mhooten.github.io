cr.1.mcmc <- function(y,J,n.mcmc){

#
#  Fits C-R model using RB and PX-DA and Binom for n
#

###
###  Setup Variables 
###

M=length(y)
n=sum(y>0)

p.save=rep(0,n.mcmc)
psi.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)
Dbar.save=rep(0,n.mcmc)

###
###  Priors and Starting Values  
###

alpha.psi=1
beta.psi=1

alpha.p=1
beta.p=1

###
###  First Stage Posteriors to use as Prior for Second Stage 
###

p.star=rep(0,n.mcmc)
psi.star=rep(0,n.mcmc)
p=.5
psi=.5
for(k in 1:n.mcmc){
  if(k%%10000==0){cat(k," ")}

  ###
  ### Update p 
  ###

  p.star.star=rbeta(1,alpha.p,beta.p)
  mh.1=sum(dbinom(y[y>0],J,p.star.star,log=TRUE))-n*log(1-(1-p.star.star)^J)
  mh.2=sum(dbinom(y[y>0],J,p,log=TRUE))-n*log(1-(1-p)^J)
  mh=exp(mh.1-mh.2)
  if(mh > runif(1)){
    p=p.star.star
  }
  p.star[k]=p

  ###
  ### Update psi 
  ###

  psi=rbeta(1,alpha.psi,beta.psi)
  psi.star[k]=psi
};cat("\n")

N.0.star=rbinom(n.mcmc,M-n,(psi.star*(1-p.star)^J)/(psi.star*(1-p.star)^J+1-psi.star))

tmp.idx=sample(1:n.mcmc,1)
p=p.star[tmp.idx]
psi=psi.star[tmp.idx]
N.0=N.0.star[tmp.idx]

p.tmp=psi*(1-(1-p)^J)
mh.2=lchoose(M,n)+n*dbinom(1,1,p.tmp,log=TRUE)+(M-n)*dbinom(0,1,p.tmp,log=TRUE)

###
###  Begin MCMC Loop for Second Stage	 
###

for(k in 1:n.mcmc){
  if(k%%1000==0){cat(k," ")}

  ###
  ### Update p and psi 
  ###

  tmp.idx=sample(1:n.mcmc,1)
  p.tmp=psi.star[tmp.idx]*(1-(1-p.star[tmp.idx])^J)
  mh.1=lchoose(M,n)+n*dbinom(1,1,p.tmp,log=TRUE)+(M-n)*dbinom(0,1,p.tmp,log=TRUE)

  mh=exp(mh.1-mh.2)
  if(mh > runif(1)){
    p=p.star[tmp.idx]
    psi=psi.star[tmp.idx]
    N.0=N.0.star[tmp.idx]
    mh.2=mh.1
  }
 
  ###
  ###  Save Samples 
  ###

  N.save[k]=N.0+n
  p.save[k]=p
  psi.save[k]=psi

};cat("\n")

###
###  Write Output
###

list(p.save=p.save,N.save=N.save,psi.save=psi.save,n.mcmc=n.mcmc,p.star=p.star,psi.star=psi.star,N.star=N.0.star+n)

}
