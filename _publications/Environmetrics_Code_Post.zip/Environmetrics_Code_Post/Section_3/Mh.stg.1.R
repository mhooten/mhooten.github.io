Mh.stg.1 <- function(y,J,n.mcmc){

###
###  Libraries and Subroutines 
###

logit <- function(p){
  log(p)-log(1-p)
}

logit.inv <- function(v){
  1/(1+exp(-v)) 
}

ldIG <- function(x,q,r){
  -(q+1)*log(x)-1/r/x-q*log(r)-lgamma(q)
}

###
###  Setup Variables 
###

M=length(y)
n=sum(y>0)

###
###  Priors and Starting Values 
###

p=rep(mean(y[y>0]/J),n)
psi=n/M
alpha=1
beta=1
mu=-2
s2=.2
sig=sqrt(s2)

mu.0=-1
s2.0=1
sig.0=sqrt(s2.0)

r=100
q=.01

mu.tune=.5
s2.tune=.5

###
###  Set up Other Variables
###

mu.star=rep(0,n.mcmc)
s2.star=rep(0,n.mcmc)
psi.star=rbeta(n.mcmc,alpha,beta)

n.sim=10000
z=rnorm(n.sim)

p.detect=1-(1+exp(mu+sig*z))^(-J)
ldenom.int=n*log(mean(p.detect))

y.uniq=1:J
n.uniq=rep(0,J)
for(j in y.uniq){
  n.uniq[j]=sum(y[y>0]==j)
}

p=logit.inv(mu+sig*z)
mh.2=c(n.uniq)%*%log(sapply(y.uniq,function(y.uniq,J,p){mean(dbinom(y.uniq,J,p))},J=J,p=p))-ldenom.int+dnorm(mu,mu.0,sqrt(s2.0),log=TRUE)+ldIG(s2,q,r)

###
###  Begin First-Stage MCMC Loop 
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")
  
  ###
  ###  Sample mu and s2 
  ###

  mu.star.star=rnorm(1,mu,mu.tune)
  s2.star.star=rnorm(1,s2,s2.tune)
  if(s2.star.star>0){
    sig.star.star=sqrt(s2.star.star)

    p.detect.star=1-(1+exp(mu.star.star+sig.star.star*z))^(-J)
    ldenom.int.star=n*log(mean(p.detect.star))

    p.star=logit.inv(mu.star.star+sig.star.star*z)
    mh.1=c(n.uniq)%*%log(sapply(y.uniq,function(y.uniq,J,p){mean(dbinom(y.uniq,J,p))},J=J,p=p.star))-ldenom.int.star+dnorm(mu.star.star,mu.0,sig.0,log=TRUE)+ldIG(s2.star.star,q,r)
    mh=exp(mh.1-mh.2)

    if(mh > runif(1)){
      mh.2=mh.1
      mu=mu.star.star
      s2=s2.star.star
      sig=sig.star.star
    }
  }
  
  ###
  ###  Save Samples 
  ###
  
  mu.star[k]=mu 
  s2.star[k]=s2

};cat("\n")

###
###  Write Output
###

list(mu.star=mu.star,s2.star=s2.star,psi.star=psi.star,n.mcmc=n.mcmc,q=q,r=r,mu.0=mu.0,s2.0=s2.0,alpha=alpha,beta=beta)

}
