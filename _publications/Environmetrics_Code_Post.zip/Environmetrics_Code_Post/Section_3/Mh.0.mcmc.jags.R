Mh.0.mcmc <- function(y,J,n.mcmc){

###
###  Libraries and Subroutines 
###

library(rjags)
library(coda)

logit <- function(p){
  log(p)-log(1-p)
}

###
###  Setup Variables 
###

M=length(y)
n=sum(y>0)

###
###  Priors and Starting Values 
###

alpha=1
beta=1
mu.0=-1
s2.0=1
mu0=mu.0
tau0=1/s2.0

r=100
q=.01

a=q
b=1/r

###
###  Specify CR Model in JAGS
###

m.jags <-"
  model{
    for(i in 1:M){
      y[i] ~ dbin(z[i]*p[i],J) 
    }
    for(i in 1:M){
      z[i] ~ dbin(psi,1)
      logit(p[i]) = v[i]
      v[i] ~ dnorm(mu,tau)
    }
    psi ~ dbeta(alpha,beta)
    mu ~ dnorm(mu0,tau0)
    tau ~ dgamma(a,b)
}
"

n.burn=round(.2*n.mcmc)
mod<-textConnection(m.jags) # read model

###
###  Fit Model using JAGS
###

m.out<-jags.model(mod,data=list('y'=y,'M'=M,'J'=J,'alpha'=alpha,'beta'=beta,'mu0'=mu0,'tau0'=tau0,'a'=a,'b'=b),inits=list(z=rep(1,M)),n.chains=1,n.adapt=1000) 

m.samples=jags.samples(m.out,c('psi','mu','tau'),n.mcmc)

psi.save=c(m.samples$psi[1,,1])
mu.save=c(m.samples$mu[1,,1])
tau.save=c(m.samples$tau[1,,1])
s2.save=1/tau.save

###
###  Write Output 
###

list(psi.save=psi.save,mu.save=mu.save,tau.save=tau.save,n.mcmc=n.mcmc,r=r,q=q,mu=mu,s2=s2,alpha=alpha,beta=beta,s2.save=s2.save,mu.0=mu.0,s2.0=s2.0)

}
