Mh.stg.2.P <- function(n,J,M,out.1){

###
###  Setup Variables
###

n.mcmc=out.1$n.mcmc
mu.save=rep(0,n.mcmc)
s2.save=rep(0,n.mcmc)
psi.save=rep(0,n.mcmc)

###
###  Starting values for Second Stage 
###

s2.star=out.1$s2.star
mu.star=out.1$mu.star
psi.star=out.1$psi.star

sig.star=sqrt(s2.star)
idx.star=sample(1:n.mcmc,1)
mu=mu.star[idx.star]
s2=s2.star[idx.star]
sig=sqrt(s2)
psi=psi.star[idx.star]

n.sim=1000
Z=matrix(rnorm(M*n.sim),M,n.sim)

P.tmp=psi*(1-(1+exp(mu+sig*Z))^(-J))
mh.2=log(mean(dpois(n,apply(P.tmp,2,sum))))

###
###  Parallelized Integration for Mh.1
###

library(foreach)
library(doParallel)

cores=detectCores()
print(cores)
cl <- makeCluster(cores[1], setup_strategy = "sequential")
registerDoParallel(cl)

mh.1.parallel=rep(0,n.mcmc)

mh.1.parallel <- foreach(i=1:n.mcmc) %dopar% {
  P.tmp=psi.star[i]*(1-(1+exp(mu.star[i]+sig.star[i]*Z))^(-J))
  log(mean(dpois(n,apply(P.tmp,2,sum))))
}

mh.1.save = unlist(mh.1.parallel)

###
###  Begin Second Stage MCMC Loop 
###

for(k in 1:n.mcmc){
  if(k%%10000==0) cat(k," ")

  ###
  ###  Update mu, s2, and psi 
  ###
  
  idx.star=sample(1:n.mcmc,1)

  mh=exp(mh.1.save[idx.star]-mh.2)
  
  if(mh>runif(1)){
    mu=mu.star[idx.star]
    s2=s2.star[idx.star]
    sig=sig.star[idx.star]
    psi=psi.star[idx.star]
    mh.2=mh.1.save[idx.star]
  }

  ###
  ###  Save Samples 
  ###
 
  mu.save[k]=mu
  s2.save[k]=s2
  psi.save[k]=psi

}
cat("\n")

###
###  Write Output 
###

list(psi.save=psi.save,mu.save=mu.save,s2.save=s2.save,n.mcmc=n.mcmc,mu.star=mu.star,s2.star=s2.star,psi.star=psi.star)

}

