###
###  Subroutines 
###

library(tictoc)
library(PoissonBinomial)

logit<-function(p){
  log(p/(1-p))
}

logit.inv<-function(x){
  exp(x)/(1+exp(x)) 
}

invgammastrt <- function(igmn,igvar){
  q <- 2+(igmn^2)/igvar
  r <- 1/(igmn*(q-1))
  list(r=r,q=q)
}

dIG <- function(x,q,r){
  x^(-(q+1))*exp(-1/r/x)/(r^q)/gamma(q)
}

###
###  Read in Data
###

sal.df=read.table("sal_data.txt",header=TRUE)
y.orig=apply(sal.df[sal.df$spp==0,1:4],1,sum) # P. jordani

J=4
M=1500
n=length(y.orig)
y=as.numeric(c(y.orig,rep(0,M-n)))

###
###  Fit Poisson-binomial M_h Model w/ PX-DA and Single-Stage Algorithm (JAGS)
###

n.mcmc=500000
source("Mh.0.mcmc.jags.R")
tic()
out.0=Mh.0.mcmc(y,J,n.mcmc)
toc.0=toc()

if(FALSE){
  layout(matrix(1:3,3,1))
  plot(out.0$psi.save,type="l")
  plot(out.0$mu.save,type="l")
  plot(sqrt(out.0$s2.save),type="l")
}

###
###  Fit M_h Model w/ Stage 1 Algorithm 
###

source("Mh.stg.1.R")
tic()
out.1=Mh.stg.1(y,J,n.mcmc)
toc.1=toc()

if(FALSE){
  layout(matrix(1:3,3,1))
  plot(out.1$psi.star,type="l")
  plot(out.1$mu.star,type="l")
  plot(sqrt(out.1$s2.star),type="l")
}

###
###  Fit Poisson-binomial M_h Model w/ Stage 2 Algorithm 
###

source("Mh.stg.2.Pb.R") 
tic()
out.2.Pb=Mh.stg.2.Pb(n,J,M,out.1)
toc.2.Pb=toc()

if(FALSE){
  layout(matrix(1:6,3,2,byrow=TRUE))
  plot(out.1$psi.star,type="l")
  plot(out.2.Pb$psi.save,type="l")
  plot(out.1$mu.star,type="l")
  plot(out.2.Pb$mu.save,type="l")
  plot(sqrt(out.1$s2.star),type="l")
  plot(sqrt(out.2.Pb$s2.save),type="l")
}

###
###  Fit Poisson M_h Model w/ Stage 2 Algorithm 
###

source("Mh.stg.2.P.R")
tic()
out.2.P=Mh.stg.2.P(n,J,M,out.1)
toc.2.P=toc()

if(FALSE){
  layout(matrix(1:6,3,2,byrow=TRUE))
  plot(out.1$psi.star,type="l")
  plot(out.2.P$psi.save,type="l")
  plot(out.1$mu.star,type="l")
  plot(out.2.P$mu.save,type="l")
  plot(sqrt(out.1$s2.star),type="l")
  plot(sqrt(out.2.P$s2.save),type="l")
}

###
###  Sample N post hoc
###

out.0$N.save=rep(0,n.mcmc)
out.2.Pb$N.save=rep(0,n.mcmc)
out.2.P$N.save=rep(0,n.mcmc)

tic()
n.sim=10000
e.tmp=rnorm(n.sim)
for(k in 1:n.mcmc){
  if(k%%10000==0){cat(k," ")}
  v.0.tmp=out.0$mu.save[k]+e.tmp*sqrt(out.0$s2.save[k])
  v.2.Pb.tmp=out.2.Pb$mu.save[k]+e.tmp*sqrt(out.2.Pb$s2.save[k])
  v.2.P.tmp=out.2.P$mu.save[k]+e.tmp*sqrt(out.2.P$s2.save[k])
  num.0.tmp=out.0$psi.save[k]*(1-logit.inv(v.0.tmp))^J
  num.2.Pb.tmp=out.2.Pb$psi.save[k]*(1-logit.inv(v.2.Pb.tmp))^J
  num.2.P.tmp=out.2.P$psi.save[k]*(1-logit.inv(v.2.P.tmp))^J
  psi.0.bar=mean(num.0.tmp/(num.0.tmp+1-out.0$psi.save[k]))
  psi.2.Pb.bar=mean(num.2.Pb.tmp/(num.2.Pb.tmp+1-out.2.Pb$psi.save[k]))
  psi.2.P.bar=mean(num.2.P.tmp/(num.2.P.tmp+1-out.2.P$psi.save[k]))
  out.0$N.save[k]=n+rbinom(1,M-n,psi.0.bar)
  out.2.Pb$N.save[k]=n+rbinom(1,M-n,psi.2.Pb.bar)
  out.2.P$N.save[k]=n+rpois(1,(M-n)*psi.2.P.bar)
};cat("\n")
toc.3=toc()

###
###  Plot posteriors for parameters 
###

col.0=rgb(0,0,0,alpha=.8)
col.2.Pb=rgb(1,.65,0,alpha=.8)
col.2.P=rgb(.4,.6,.8,alpha=.8)
col.3=rgb(0,0,0,alpha=.2)

if(FALSE){
  mu.bw=density(out.2.Pb$mu.save)$bw*1.75
  s2.bw=density(out.2.Pb$s2.save)$bw*1.5
  psi.bw=density(out.2.Pb$psi.save)$bw*1.75
  N.bw=density(out.2.Pb$N.save)$bw*1.2

  layout(matrix(1:4,2,2))
  plot(density(out.2.Pb$mu.save,bw=mu.bw),main="a",xlab=bquote(mu),lwd=2,ylab="density",col=col.2.Pb,ylim=c(0,1.1))
  lines(density(out.2.P$mu.save,bw=mu.bw),lwd=2,lty=2,col=col.2.P)
  plot(density(out.2.Pb$s2.save,bw=s2.bw),main="b",xlim=c(0,6),xlab=bquote(sigma^2),lwd=2,ylab="density",col=col.2.Pb,ylim=c(0,3))
  lines(density(out.2.P$s2.save,bw=s2.bw),lwd=2,lty=2,col=col.2.P)
  plot(density(out.2.Pb$psi.save,bw=psi.bw),main="c",xlab=bquote(psi),lwd=2,ylab="density",xlim=c(0,1),col=col.2.Pb,ylim=c(0,9))
  lines(density(out.2.P$psi.save,bw=psi.bw),lwd=2,lty=2,col=col.2.P)
  legend("topright",col=c(col.2.Pb,col.2.P),lwd=1.5,lty=c(1,2),legend=c("Pois-binom","Pois"),bty="n")
  plot(density(out.2.Pb$N.save,bw=N.bw),type="l",xlim=c(0,M),ylab="probability",xlab="N",lwd=2,main="d",col=col.2.Pb,ylim=c(0,.007))
  lines(density(out.2.P$N.save,bw=N.bw),type="l",lwd=2,lty=2,col=col.2.P)
  abline(v=n,lwd=1,lty=3,col=rgb(0,0,0,.7))
  legend("topright",col=rgb(0,0,0,.7),lwd=1,lty=3,legend=c("n"),bty="n")
}

###
###  Inference for N
###

mean(out.0$N.save)
quantile(out.0$N.save,c(0.025,0.975))

mean(out.2.Pb$N.save)
quantile(out.2.Pb$N.save,c(0.025,0.975))

mean(out.2.P$N.save)
quantile(out.2.P$N.save,c(0.025,0.975))

###
###  Posterior Power to Detect 
###

y.0.pred=rep(0,n.mcmc)
y.2.Pb.pred=rep(0,n.mcmc)
y.2.P.pred=rep(0,n.mcmc)
p.0.pred=rep(0,n.mcmc)
p.2.Pb.pred=rep(0,n.mcmc)
p.2.P.pred=rep(0,n.mcmc)
for(k in 1:n.mcmc){
  if(k%%10000==0){cat(k," ")}
  v.0.tmp=rnorm(1,out.0$mu.save[k],sqrt(out.0$s2.save[k]))
  v.2.Pb.tmp=rnorm(1,out.2.Pb$mu.save[k],sqrt(out.2.Pb$s2.save[k]))
  v.2.P.tmp=rnorm(1,out.2.P$mu.save[k],sqrt(out.2.P$s2.save[k]))
  p.0.pred[k]=logit.inv(v.0.tmp)
  p.2.Pb.pred[k]=logit.inv(v.2.Pb.tmp)
  p.2.P.pred[k]=logit.inv(v.2.P.tmp)
  y.0.pred[k]=rbinom(1,J,p.0.pred[k])
  y.2.Pb.pred[k]=rbinom(1,J,p.2.Pb.pred[k])
  y.2.P.pred[k]=rbinom(1,J,p.2.P.pred[k])
};cat("\n")
ptd.0=mean(y.0.pred>0)
ptd.2.Pb=mean(y.2.Pb.pred>0)
ptd.2.P=mean(y.2.P.pred>0)

ptd.0
ptd.2.Pb
ptd.2.P

if(FALSE){
  plot(density(p.2.Pb.pred),main="",xlab="conditional detection probability",lwd=2,ylab="density",col=col.2.Pb)
  lines(density(p.2.P.pred),lwd=2,col=col.2.P)
  legend("topright",col=c(col.2.Pb,col.2.P),lwd=2,legend=c("Pois-binom","Pois"),bty="n")
}

###
###  Alternative Posterior Power to Detect 
###

ptd.2.Pb.alt=mean(n/out.2.Pb$N.save)
ptd.2.P.alt=mean(n/out.2.P$N.save)

ptd.2.Pb.alt
ptd.2.P.alt

###
###  Timing of MCMC algorithms 
###

time.mins.0=(toc.0$toc - toc.0$tic)/60
time.mins.1=(toc.1$toc - toc.1$tic)/60
time.mins.2.Pb=(toc.2.Pb$toc - toc.2.Pb$tic)/60
time.mins.2.P=(toc.2.P$toc - toc.2.P$tic)/60

paste(round(time.mins.0, 3), " min elapsed", sep = "")
paste(round(time.mins.1, 3), " min elapsed", sep = "")
paste(round(time.mins.2.Pb, 3), " min elapsed", sep = "")
paste(round(time.mins.2.P, 3), " min elapsed", sep = "")

###
###   Calc. effective sample size (for mu)
###

library(coda)
mcmc.0=as.mcmc(out.0$mu.save)
mcmc.2.Pb=as.mcmc(out.2.Pb$mu.save)
mcmc.2.P=as.mcmc(out.2.P$mu.save)

n.eff.0=effectiveSize(mcmc.0)
n.eff.2.Pb=effectiveSize(mcmc.2.Pb)
n.eff.2.P=effectiveSize(mcmc.2.P)

c(n.eff.0,n.eff.2.Pb,n.eff.2.P)

time.per.eff.iter.0=time.mins.0/n.eff.0
time.per.eff.iter.2.Pb=(time.mins.1+time.mins.2.Pb)/n.eff.2.Pb
time.per.eff.iter.2.P=(time.mins.1+time.mins.2.P)/n.eff.2.P

c(time.per.eff.iter.0,time.per.eff.iter.2.Pb,time.per.eff.iter.2.P)

