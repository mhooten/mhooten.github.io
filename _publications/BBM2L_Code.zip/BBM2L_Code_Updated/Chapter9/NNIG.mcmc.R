NNIG.mcmc <- function(y,mu0,s20,q,r,mu.strt,n.mcmc){

###
### Code Box 9.1
###

n=length(y)
mu.save=rep(0,n.mcmc)
s2.save=rep(0,n.mcmc)
mu=mu.strt

for(k in 1:n.mcmc){
  if((k%%100)==0){cat(k," ")}

  tmp.r=1/(sum((y-mu)^2)/2+1/r)
  tmp.q=n/2+q
  s2=1/rgamma(1,tmp.q,,tmp.r)

  tmp.var=1/(n/s2+1/s20)
  tmp.mn=tmp.var*(sum(y)/s2+mu0/s20)
  mu=rnorm(1,tmp.mn,sqrt(tmp.var))

  mu.save[k]=mu
  s2.save[k]=s2

};cat("\n")

list(mu.save=mu.save,s2.save=s2.save,n.mcmc=n.mcmc)
}
