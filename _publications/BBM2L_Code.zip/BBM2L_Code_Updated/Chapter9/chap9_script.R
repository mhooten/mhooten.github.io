###
###  Chapter 9 R Script
###

###
###  Code Box 9.2
###
###  Normal-Normal-IG Posterior
###

n=10
mu=2
s2=1
set.seed(1)
y=rnorm(n,mu,sqrt(s2))

s2.mn=2
s2.var=100
q=(s2.mn^2)/s2.var+2
r=1/(s2.mn*(q-1))
mu0=0
s20=10

source("NNIG.mcmc.R")  #  Code Box 9.1
mcmc.out=NNIG.mcmc(y=y,mu0=mu0,s20=s20,q=q,r=r,mu.strt=0,n.mcmc=1000)

dIG <- function(x,r,q){x^(-(q+1))*exp(-1/r/x)/(r^q)/gamma(q)}

pdf(file="mu_s2_post.pdf",width=8,height=4)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(c(1,2,1,2,3,4),2,3))
plot(mcmc.out$mu.save,type="l",xlab="k",ylab=bquote(mu),main="a")
plot(mcmc.out$s2.save,type="l",xlab="k",ylab=bquote(sigma^2),main="c")
hist(mcmc.out$mu.save,col=8,prob=TRUE,xlab=bquote(mu),breaks=30,main="b")
curve(dnorm(x,mu0,sqrt(s20)),n=1000,from=0,to=6,lwd=1.5,lty=2,add=TRUE)
hist(mcmc.out$s2.save,col=8,prob=TRUE,xlab=bquote(sigma^2),breaks=30,main="d")
curve(dIG(x,r,q),n=1000,from=0,to=6,lwd=1.5,lty=2,add=TRUE)
dev.off()


