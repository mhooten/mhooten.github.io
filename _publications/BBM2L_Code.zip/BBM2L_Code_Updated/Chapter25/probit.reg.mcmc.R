probit.reg.mcmc <- function(z,X,X.pred,z.true,n.mcmc){

###
###  Code Box 25.4
###

###
###  Subroutines
###

rtn <- function(n,mu,sig2,low,high){
  flow=pnorm(low,mu,sqrt(sig2)) 
  fhigh=pnorm(high,mu,sqrt(sig2)) 
  u=runif(n) 
  tmp=flow+u*(fhigh-flow)
  x=qnorm(tmp,mu,sqrt(sig2))
  x
}

###
###  Preliminary Variables
###

X=as.matrix(X)
z=as.vector(z)
n=length(z)
p=dim(X)[2]
n.pred=dim(X.pred)[1]

beta.save=matrix(0,p,n.mcmc)
v.save=matrix(0,n,n.mcmc)
pred.acc.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)

z1=(z==1)
z0=(z==0)

###
###  Hyperparameters and Starting Values
###

beta.mn=rep(0,p)
beta.var=1

Sig.beta.inv=solve(beta.var*diag(p))
beta=beta.mn

###
###  MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ### Sample v 
  ###
 
  v=rep(0,n)
  v[z1]=rtn(sum(z),(X%*%beta)[z1],1,0,Inf)
  v[z0]=rtn(sum(1-z),(X%*%beta)[z0],1,-Inf,0)

  ###
  ### Sample beta
  ###

  tmp.chol=chol(t(X)%*%X + Sig.beta.inv)
  beta=backsolve(tmp.chol,backsolve(tmp.chol,t(X)%*%v + Sig.beta.inv%*%beta.mn,transpose=TRUE)+rnorm(p))

  ###
  ### Sample Predictions
  ###

  z.pred=rbinom(n.pred,1,pnorm(X.pred%*%beta))
  pred.acc.save[k]=sum((z.true-z.pred)==0)/n.pred 

  ###
  ### Save Samples 
  ###

  beta.save[,k]=beta
  v.save[,k]=v
  N.save[k]=sum(z)+sum(z.pred)

}
cat("\n")
 
###
###  Write output 
###

list(z=z,X=X,n.mcmc=n.mcmc,v.save=v.save,beta.save=beta.save,pred.acc.save=pred.acc.save,N.save=N.save)

}
