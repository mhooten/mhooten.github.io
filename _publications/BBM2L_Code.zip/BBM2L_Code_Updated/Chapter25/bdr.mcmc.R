bdr.mcmc <- function(y,z.obs,z.idx,z.true,X,n.mcmc){

####
####  Code Box 25.1
####

####
####  Libraries and Subroutines
####

rtn <- function(n,mu,sig2,low,high){
  flow=pnorm(low,mu,sqrt(sig2)) 
  fhigh=pnorm(high,mu,sqrt(sig2)) 
  u=runif(n) 
  tmp=flow+u*(fhigh-flow)
  x=qnorm(tmp,mu,sqrt(sig2))
  x
}

####
####  Setup Variables 
####

n=length(y)
p.X=dim(X)[2]
n.burn=round(0.25*n.mcmc)

z.mean=rep(0,n)
psi.mean=rep(0,n)
beta.save=matrix(0,p.X,n.mcmc)
p0.save=rep(0,n.mcmc)
p1.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)
pred.acc.save=rep(0,n.mcmc)

####
####  Hyperparameters and Starting Values 
####

beta=rep(0,p.X)
p0=.25
p1=.75
Xbeta=X%*%beta
psi=pnorm(Xbeta)
z=rep(0,n)
z[z.idx]=z.obs
n0=sum(z==0)
n1=sum(z==1)

v=rep(0,n)

ny0=sum(y==0)
ny1=sum(y==1)

alpha.0=1
beta.0=1
alpha.1=1
beta.1=1

Sig.beta=diag(p.X)
Sig.beta.inv=solve(Sig.beta)
mu.beta=rep(0,p.X)

XprimeX=t(X)%*%X
A.beta=XprimeX+Sig.beta.inv
A.beta.chol=chol(A.beta)
Sig.beta.inv.times.mu.beta=Sig.beta.inv%*%mu.beta

####
####  Begin Gibbs Loop 
####

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ####
  ####  Sample v 
  ####

  v[z==0]=rtn(n0,Xbeta[z==0],1,-Inf,0)
  v[z==1]=rtn(n1,Xbeta[z==1],1,0,Inf)

  ####
  ####  Sample beta 
  ####

  b.beta=t(X)%*%v+Sig.beta.inv.times.mu.beta
  beta=backsolve(A.beta.chol,backsolve(A.beta.chol,b.beta,transpose=TRUE)+rnorm(p.X))
  Xbeta=X%*%beta
  psi=pnorm(Xbeta)

  ####
  ####  Sample p0 
  ####

  sum.1=sum(y[z==0])+alpha.0 
  sum.2=sum(1-y[z==0])+beta.0 
  p0=rbeta(1,sum.1,sum.2)

  ####
  ####  Sample p1
  ####

  sum.1=sum(y[z==1])+alpha.1
  sum.2=sum(1-y[z==1])+beta.1 
  p1=rbeta(1,sum.1,sum.2)

  ####
  ####  Sample z 
  ####

  psi.numer=psi*(p1^y)*((1-p1)^(1-y))
  psi.tmp=psi.numer/(psi.numer+(1-psi)*(p0^y)*((1-p0)^(1-y)))
  psi.tmp[psi.tmp>1]=1
  z[-z.idx]=rbinom(n-length(z.idx),1,psi.tmp[-z.idx])
  n0=sum(z==0)
  n1=sum(z==1)

  ####
  ####  Prediction Accuracy 
  ####

  pred.acc.save[k]=sum((z.true-z)[-z.idx]==0)/(n-length(z.idx))

  ####
  ####  Save Samples 
  ####

  beta.save[,k]=beta
  p0.save[k]=p0
  p1.save[k]=p1
  if(k > n.burn){
    z.mean=z.mean+z/(n.mcmc-n.burn)
    psi.mean=psi.mean+psi/(n.mcmc-n.burn)
  }
  N.save[k]=sum(z)

}
cat("\n")

####
####  Write Output 
####

list(p0.save=p0.save,p1.save=p1.save,beta.save=beta.save,z.mean=z.mean,psi.mean=psi.mean,N.save=N.save,pred.acc.save=pred.acc.save,n.mcmc=n.mcmc)

}
