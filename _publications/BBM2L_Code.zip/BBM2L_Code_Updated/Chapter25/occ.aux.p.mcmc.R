occ.aux.p.mcmc <- function(y,J,X,z.true,z.idx,n.mcmc){

####
####   Code Box 25.5
####

####
####  Libraries and Subroutines
####

rtn <- function(n,mu,sig2,low,high){
  flow=pnorm(low,mu,sqrt(sig2)) 
  fhigh=pnorm(high,mu,sqrt(sig2)) 
  u=runif(n) 
  tmp=flow+u*(fhigh-flow)
  x=qnorm(tmp,mu,sqrt(sig2))
  x
}

####
####  Setup Variables 
####

n=length(y)
p.X=dim(X)[2]
n.burn=round(0.25*n.mcmc)

z.mean=rep(0,n)
beta.save=matrix(0,p.X,n.mcmc)
N.save=rep(0,n.mcmc)
p.save=rep(0,n.mcmc)
pred.acc.save=rep(0,n.mcmc)

####
####  Hyperparameters and Starting Values 
####

p=.5
beta=rep(0,p.X)
Xbeta=X%*%beta
psi=pnorm(Xbeta)
z=rep(0,n)
z[y==0]=0
n0=sum(z==0)
n1=sum(z==1)

v=rep(0,n)
ny0=sum(y==0)
ny1=sum(y==1)

alpha.p=1
beta.p=1

mu.beta=rep(0,p.X)
Sig.beta=diag(p.X)
Sig.beta.inv=solve(Sig.beta)

XprimeX=t(X)%*%X
A.beta=XprimeX+Sig.beta.inv
A.beta.chol=chol(A.beta)
Sig.beta.inv.times.mu.beta=Sig.beta.inv%*%mu.beta

####
####  Begin MCMC Loop 
####

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ####
  ####  Sample v 
  ####
 
  v[z==0]=rtn(n0,Xbeta[z==0],1,-Inf,0)
  v[z==1]=rtn(n1,Xbeta[z==1],1,0,Inf)

  ####
  ####  Sample beta 
  ####

  b.beta=t(X)%*%v+Sig.beta.inv.times.mu.beta
  beta=backsolve(A.beta.chol, backsolve(A.beta.chol, b.beta, transpose = TRUE) + rnorm(p.X))
  Xbeta=X%*%beta
  psi=pnorm(Xbeta)

  ####
  ####  Sample z 
  ####

  psi.numer=psi*(1-p)^J
  psi.tmp=psi.numer/(psi.numer+1-psi)
  z[y==0]=rbinom(sum(y==0),1,psi.tmp[y==0])
  z[y>0]=1
  n0=sum(z==0)
  n1=sum(z==1)

  ####
  ####  Sample p
  ####

  p=rbeta(1,sum(y[z==1])+alpha.p,sum(J-y[z==1])+beta.p)

  ####
  ####  Calculate Pred Accuracy 
  ####

  pred.acc.save[k]=sum((z.true-z[-z.idx])==0)/(n-length(z.idx))

  ####
  ####  Save Samples 
  ####

  beta.save[,k]=beta
  if(k > n.burn){
    z.mean=z.mean+z/(n.mcmc-n.burn)
  }
  N.save[k]=sum(z)
  p.save[k]=p

}
cat("\n")

####
####  Write Output 
####

list(beta.save=beta.save,z.mean=z.mean,N.save=N.save,pred.acc.save=pred.acc.save,n.mcmc=n.mcmc)

}
