###
###  Chapter 25 R Script
###

###
###  Code Box 25.2
###
###  Simulate BDR Data
###

RNGkind(sample.kind = "Rounding")
n=200
m=50
p1=.75
p0=.25

set.seed(101)
X=matrix(1,n,2)
X[,2]=rnorm(n)
beta=c(-.5,.5)

psi=pnorm(X%*%beta)
z=rbinom(n,1,psi)
y=rbinom(n,1,z*p1+(1-z)*p0)

z.idx=sort(sample(1:n,m))
z.obs=z[z.idx]

table(y)
table(z)
table(z.obs)
table(y-z)

###
###  Code Box 25.3
###
###  Fit BDR Model using Auxiliary Variables 
###

source("bdr.mcmc.R")  # Code Box 25.1
n.mcmc=20000
set.seed(1)
mcmc.out=bdr.mcmc(y=y,z.obs=z.obs,z.idx=z.idx,z.true=z,X=X,n.mcmc=n.mcmc)

#layout(matrix(1:3,3,1))
#matplot(t(mcmc.out$beta.save),type="l",lty=1)
#abline(h=beta,col=8)
#plot(mcmc.out$p0.save,type="l")
#abline(h=p0,col=8)
#plot(mcmc.out$p1.save,type="l")
#abline(h=p1,col=8)

pdf(file="bdr_post.pdf",width=10,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,-(1:1000)],breaks=60,col=8,xlab=bquote(beta[0]),prob=TRUE,main="a")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
abline(v=beta[1],lty=2,lwd=2)
hist(mcmc.out$beta.save[2,-(1:1000)],breaks=50,col=8,xlab=bquote(beta[1]),prob=TRUE,main="b")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
abline(v=beta[2],lty=2,lwd=2)
hist(mcmc.out$p0.save[-(1:1000)],breaks=30,col=8,xlab=bquote(p[0]),xlim=c(0,1),prob=TRUE,main="c")
curve(dbeta(x,1,1),lwd=2,add=TRUE)
abline(v=p0,lty=2,lwd=2)
hist(mcmc.out$p1.save[-(1:1000)],breaks=40,col=8,xlab=bquote(p[1]),xlim=c(0,1),prob=TRUE,main="d")
curve(dbeta(x,1,1),lwd=2,add=TRUE)
abline(v=p1,lty=2,lwd=2)
dev.off()

mean(mcmc.out$N.save[-(1:1000)])
quantile(mcmc.out$N.save[-(1:1000)],c(0.025,0.975))
sum(z)

###
###  Code Box 25.6
###
###  Compare Predictions of BDR with probit reg 
###

n.mcmc=20000
source("bdr.mcmc.R") # Code Box 25.1
set.seed(1)
mcmc.out=bdr.mcmc(y=y,z.obs=z.obs,z.idx=z.idx,z.true=z,X=X,n.mcmc=n.mcmc)
mean(mcmc.out$pred.acc.save[-(1:1000)])
quantile(mcmc.out$pred.acc.save[-(1:1000)],c(0.025,0.975))

source("probit.reg.mcmc.R") # Code Box 25.4
set.seed(1)
mcmc.z.out=probit.reg.mcmc(z=z.obs,X=X[z.idx,],X.pred=X[-z.idx,],z.true=z[-z.idx],n.mcmc=n.mcmc)
mean(mcmc.z.out$pred.acc.save[-(1:1000)])
quantile(mcmc.z.out$pred.acc.save[-(1:1000)],c(0.025,0.975))

source("occ.aux.p.mcmc.R") # Code Box 25.5
set.seed(1)
mcmc.y.out=occ.aux.p.mcmc(y=y,J=1,X=X,z.true=z[-z.idx],z.idx=z.idx,n.mcmc=n.mcmc)
mean(mcmc.y.out$pred.acc.save[-(1:1000)])
quantile(mcmc.y.out$pred.acc.save[-(1:1000)],c(0.025,0.975))

###
###  Code Box 25.8
###
###  False Positive Occupancy Model Data Simulation
###

n=200
J=4
M0=1000
M1=1000
p=.75
p1=.5
p0=.25
beta=c(-.5,.5)

set.seed(101)
X=matrix(1,n,2)
X[,2]=rnorm(n)
psi=pnorm(X%*%beta)
z=rbinom(n,1,psi)
y=rbinom(n,J,z*p*p1+(1-z)*p0)

c1=rbinom(1,M1,p1)
c0=rbinom(1,M0,p0)

###
###  Code Box 25.9
###
###  Fit False Positive Occupancy Model to Simulated Data 
###

n.mcmc=100000
source("occ.fp.aux.mcmc.R") # Code Box 25.7
set.seed(1)
mcmc.out=occ.fp.aux.mcmc(y=y,J=J,X=X,z.true=z,c1=c1,M1=M1,c0=c0,M0=M0,n.mcmc=n.mcmc)

#layout(matrix(1:4,4,1))
#matplot(t(mcmc.out$beta.save),type="l",lty=1)
#abline(h=beta,col=8)
#plot(mcmc.out$p0.save,type="l",ylim=c(0,1))
#abline(h=p0,col=8)
#plot(mcmc.out$p1.save,type="l",ylim=c(0,1))
#abline(h=p1,col=8)
#plot(mcmc.out$p.save,type="l",ylim=c(0,1))
#abline(h=p,col=8)

pdf(file="fp_post.pdf",width=8,height=12)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:6,3,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,-(1:1000)],breaks=60,col=8,xlab=bquote(beta[0]),prob=TRUE,main="a")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
abline(v=beta[1],lty=2,lwd=2)
hist(mcmc.out$beta.save[2,-(1:1000)],breaks=50,col=8,xlab=bquote(beta[1]),prob=TRUE,main="b")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
abline(v=beta[2],lty=2,lwd=2)
hist(mcmc.out$p0.save[-(1:1000)],breaks=6,col=8,xlab=bquote(p[0]),xlim=c(0,1),prob=TRUE,main="c")
curve(dbeta(x,1,1),lwd=2,add=TRUE)
abline(v=p0,lty=2,lwd=2)
hist(mcmc.out$p1.save[-(1:1000)],breaks=6,col=8,xlab=bquote(p[1]),xlim=c(0,1),prob=TRUE,main="d")
curve(dbeta(x,1,1),lwd=2,add=TRUE)
abline(v=p1,lty=2,lwd=2)
hist(mcmc.out$p.save[-(1:1000)],breaks=40,col=8,xlab="p",xlim=c(0,1),prob=TRUE,main="e")
curve(dbeta(x,2,1),lwd=2,add=TRUE)
abline(v=p,lty=2,lwd=2)
hist(mcmc.out$N.save[-(1:1000)],breaks=seq(0,200,1),col=8,xlab="N",ylab="Probability",prob=TRUE,main="f")
abline(v=sum(z),lty=2,lwd=2)
dev.off()

mean(mcmc.out$pred.acc.save[-(1:1000)])
quantile(mcmc.out$pred.acc.save[-(1:1000)],c(0.025,0.975))

mean(mcmc.out$N.save[-(1:1000)]<sum(y>0))
mean(mcmc.out$N.save[-(1:1000)])
quantile(mcmc.out$N.save[-(1:1000)],c(0.025,0.975))

###
###  Code Box 25.11
###
###  Simulate IPM Data 
###

n=20
Ty=40
Tw=10

r=1.1
phi=.9
p=.5

Z=matrix(1,n,Tw)
W=matrix(1,n,Tw)
set.seed(101)
for(tau in 2:Tw){
  Z[,tau]=rbinom(n,1,phi*Z[,tau-1])
  W[,tau]=rbinom(n,1,p*Z[,tau])
}

N=rep(100,Ty+1)
y=rep(0,Ty)
for(t in 1:Ty){
  N[t+1]=rpois(1,r*phi*N[t])
  y[t]=rpois(1,N[t+1])
}

###
###  Code Box 25.12
###
###  Fit IPM to Simulated Data 
###

source("ipm.mcmc.R") # Code Box 25.10
n.mcmc=100000
set.seed(1)
mcmc.out=ipm.mcmc(y=y,W=W,n.mcmc=n.mcmc)

#layout(matrix(1:3,3,1))
#plot(mcmc.out$p.save,type="l",ylim=c(0,1))
#abline(h=p,col=8)
#plot(mcmc.out$phi.save,type="l",ylim=c(0,1))
#abline(h=phi,col=8)
#plot(mcmc.out$r.save,type="l",ylim=c(0,3))
#abline(h=r,col=8)

pdf(file="ipm_post.pdf",width=10,height=10)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$r.save[-(1:1000)],breaks=20,col=8,xlab="r",xlim=c(0,2),prob=TRUE,main="a")
curve(dgamma(x,1,1),lwd=2,add=TRUE)
abline(v=r,lty=2,lwd=2)
hist(mcmc.out$phi.save[-(1:1000)],breaks=20,col=8,xlab=bquote(phi),xlim=c(0,1),prob=TRUE,main="b")
curve(dbeta(x,1,1),lwd=2,add=TRUE)
abline(v=phi,lty=2,lwd=2)
hist(mcmc.out$p.save[-(1:1000)],breaks=40,col=8,xlab="p",xlim=c(0,1),prob=TRUE,main="c")
curve(dbeta(x,1,1),lwd=2,add=TRUE)
abline(v=p,lty=2,lwd=2)
hist(mcmc.out$N.save[1,-(1:1000)],breaks=seq(0,155,1),col=8,xlab=bquote(N[0]),ylab="Probability",prob=TRUE,main="d")
curve(dgamma(x,10,.1),lwd=2,add=TRUE)
abline(v=N[1],lty=2,lwd=2)
dev.off()

###
###  Code Box 25.13
###
###  Calculate posterior population abundance 
###

N.l=apply(mcmc.out$N.save[,-(1:1000)],1,quantile,0.025)
N.u=apply(mcmc.out$N.save[,-(1:1000)],1,quantile,0.975)
N.mn=apply(mcmc.out$N.save[,-(1:1000)],1,mean)
pdf(file="ipm_N.pdf",width=10,height=6)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
plot(1:Ty,y,xlim=c(0,Ty),ylim=range(c(N.u,N.l)),type="p",lwd=2,xlab="t",ylab="Abundance")
polygon(c(0:Ty,Ty:0),c(N.u,rev(N.l)),col=rgb(0,0,0,.2),border=NA)
lines(0:Ty,N,type="o",cex=.25,lwd=2,lty=1)
points(1:Ty,y,lwd=2)
legend("bottomright",lty=c(1,NA),pch=c(NA,1),lwd=2,legend=c("N","y"),bty="n")
dev.off()

