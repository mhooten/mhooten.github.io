ipm.mcmc <- function(y,W,n.mcmc){

####
####  Code Box 25.10
####

####
####  Setup Variables 
####

Ty=length(y)
n=dim(W)[1]
Tw=dim(W)[2]

p.save=rep(0,n.mcmc)
phi.save=rep(0,n.mcmc)
r.save=rep(0,n.mcmc)
N.save=matrix(0,Ty+1,n.mcmc)

####
####  Priors 
####

alpha.p=1
beta.p=1

alpha.phi=1
beta.phi=1

alpha.r=1
beta.r=1

alpha.0=10
beta.0=.1

####
####  Starting Values 
####

p=0.5
phi=0.9
r=1.1

Z=matrix(0,n,Tw)
Z[,1]=1
Z[W==1]=1
for(i in 1:n){
  if(sum(W[i,])>0){
    idx.tmp=max((1:Tw)[W[i,]==1])
    Z[i,1:idx.tmp]=1
  }
}

N=c(y[1],y) # Note: add 1 when indexing N
const=.1

####
####  Begin MCMC Loop 
####

for(k in 1:n.mcmc){
  if((k %% 1000)==0)  cat(k," ")

  ####
  ####  Sample N_0 
  ####

  N[1]=rgamma(1,N[2]+alpha.0,r*phi+beta.0)

  ####
  ####  Sample N_t 
  ####

  for(t in 1:(Ty-1)){
    Nt.star=rpois(1,N[t+1]+const)
    mh.1=dpois(y[t],Nt.star,log=TRUE)+dpois(N[t+1+1],r*phi*Nt.star,log=TRUE)+dpois(Nt.star,r*phi*N[t],log=TRUE)+dpois(N[t+1],Nt.star+const,log=TRUE)
    mh.2=dpois(y[t],N[t+1],log=TRUE)+dpois(N[t+1+1],r*phi*N[t+1],log=TRUE)+dpois(N[t+1],r*phi*N[t],log=TRUE)+dpois(Nt.star,N[t+1]+const,log=TRUE)
    mh=exp(mh.1-mh.2)
    if(mh>runif(1)){ 
      N[t+1]=Nt.star
    } 
  }

  ####
  ####  Sample N_Ty 
  ####

  NTy.star=rpois(1,N[Ty+1]+const)
  mh.1=dpois(y[Ty],NTy.star,log=TRUE)+dpois(NTy.star,r*phi*N[Ty],log=TRUE)+dpois(N[Ty+1],NTy.star+const,log=TRUE)
  mh.2=dpois(y[Ty],N[Ty+1],log=TRUE)+dpois(N[Ty+1],r*phi*N[Ty],log=TRUE)+dpois(NTy.star,N[Ty+1]+const,log=TRUE)
  mh=exp(mh.1-mh.2)
  if(mh>runif(1)){ 
    N[Ty+1]=NTy.star
  } 

  ####
  ####  Sample r 
  ####

  r=rgamma(1,sum(N[-1])+alpha.r,sum(phi*N[1:Ty])+beta.r)

  ####
  ####  Sample z 
  ####

  for(i in 1:n){
    for(tau in 2:(Tw-1)){
      if(sum(W[i,tau:Tw])==0){
        if(Z[i,tau-1]==1 & Z[i,tau+1]==0){
          psi.tmp=phi*(1-p)
          psi.tmp=psi.tmp/(psi.tmp+1)
          Z[i,tau]=rbinom(1,1,psi.tmp)
        }
        if(Z[i,tau-1]==0){
          Z[i,tau]=0
        }
        if(Z[i,tau+1]==1){
          Z[i,tau]=1
        }
      }
    }
    if(Z[i,Tw-1]==1 & W[i,Tw]==0){
      psi.tmp=phi*(1-p)
      psi.tmp=psi.tmp/(psi.tmp+1-phi)
      Z[i,Tw]=rbinom(1,1,psi.tmp)
    }
    if(Z[i,Tw-1]==0 & W[i,Tw]==0){
      Z[i,Tw]=0
    }
    if(W[i,Tw]==1){
      Z[i,Tw]=1
    }
  }

  ####
  ####  Sample p 
  ####

  p=rbeta(1,sum(W[,-1][Z[,-1]==1])+alpha.p,sum(1-W[,-1][Z[,-1]==1])+beta.p)

  ####
  ####  Sample phi 
  ####

  phi.star=rbeta(1,alpha.phi,beta.phi)
  mh.1=sum(dpois(N[-1],r*phi.star*N[-(Ty+1)],log=TRUE))+sum(dbinom(Z[,-1][Z[,-Tw]==1],1,phi.star,log=TRUE))
  mh.2=sum(dpois(N[-1],r*phi*N[-(Ty+1)],log=TRUE))+sum(dbinom(Z[,-1][Z[,-Tw]==1],1,phi,log=TRUE))
  mh=exp(mh.1-mh.2)
  if(mh>runif(1)){ 
    phi=phi.star
  }

  ####
  ####  Save Samples 
  ####

  p.save[k]=p
  phi.save[k]=phi
  r.save[k]=r
  N.save[,k]=N

}
cat("\n")

####
####  Write Output 
####

list(p.save=p.save,phi.save=phi.save,r.save=r.save,N.save=N.save,n.mcmc=n.mcmc)

}
