occ.fp.aux.mcmc <- function(y,J,X,z.true,c1,M1,c0,M0,n.mcmc){

####
####  Code Box 25.7
####

####
####  Libraries and Subroutines
####

rtn <- function(n,mu,sig2,low,high){
  flow=pnorm(low,mu,sqrt(sig2)) 
  fhigh=pnorm(high,mu,sqrt(sig2)) 
  u=runif(n) 
  tmp=flow+u*(fhigh-flow)
  x=qnorm(tmp,mu,sqrt(sig2))
  x
}

####
####  Setup Variables 
####

n=length(y)
p.X=dim(X)[2]
n.burn=round(0.25*n.mcmc)

z.mean=rep(0,n)
beta.save=matrix(0,p.X,n.mcmc)
N.save=rep(0,n.mcmc)
p.save=rep(0,n.mcmc)
p1.save=rep(0,n.mcmc)
p0.save=rep(0,n.mcmc)
pred.acc.save=rep(0,n.mcmc)

####
####  Hyperparameters and Starting Values 
####

p=.5
p1=.5
p0=.5
beta=rep(0,p.X)
Xbeta=X%*%beta
psi=pnorm(Xbeta)
z=rep(0,n)
z[y==0]=0
n0=sum(z==0)
n1=sum(z==1)

v=rep(0,n)
ny0=sum(y==0)
ny1=sum(y==1)

alpha.p=2
beta.p=1
alpha.1=1
beta.1=1
alpha.0=1
beta.0=1

mu.beta=rep(0,p.X)
Sig.beta=diag(p.X)
Sig.beta.inv=solve(Sig.beta)

XprimeX=t(X)%*%X
A.beta=XprimeX+Sig.beta.inv
A.beta.chol=chol(A.beta)
Sig.beta.inv.times.mu.beta=Sig.beta.inv%*%mu.beta

####
####  Begin MCMC Loop 
####

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ####
  ####  Sample v 
  ####
 
  v[z==0]=rtn(n0,Xbeta[z==0],1,-Inf,0)
  v[z==1]=rtn(n1,Xbeta[z==1],1,0,Inf)

  ####
  ####  Sample beta 
  ####

  b.beta=t(X)%*%v+Sig.beta.inv.times.mu.beta
  beta=backsolve(A.beta.chol, backsolve(A.beta.chol, b.beta, transpose = TRUE) + rnorm(p.X))
  Xbeta=X%*%beta
  psi=pnorm(Xbeta)

  ####
  ####  Sample z 
  ####

  psi.numer=psi*dbinom(y,J,p*p1)
  psi.tmp=psi.numer/(psi.numer+(1-psi)*dbinom(y,J,p0))
  z=rbinom(n,1,psi.tmp)
  n0=sum(z==0)
  n1=sum(z==1)

  ####
  ####  Sample p0
  ####

  p0=rbeta(1,sum(y[z==0])+c0+alpha.0,sum(J-y[z==0])+M0-c0+beta.0)

  ####
  ####  Sample p1
  ####

  p1.star=rbeta(1,alpha.1,beta.1)
  mh.1=sum(dbinom(y[z==1],J,p*p1.star,log=TRUE))+dbinom(c1,M1,p1.star,log=TRUE)
  mh.2=sum(dbinom(y[z==1],J,p*p1,log=TRUE))+dbinom(c1,M1,p1,log=TRUE)
  mh=exp(mh.1-mh.2)
  if(mh > runif(1)){
    p1=p1.star
  }

  ####
  ####  Sample p
  ####

  p.star=rbeta(1,alpha.p,beta.p)
  mh.1=sum(dbinom(y[z==1],J,p.star*p1,log=TRUE))
  mh.2=sum(dbinom(y[z==1],J,p*p1,log=TRUE))
  mh=exp(mh.1-mh.2)
  if(mh > runif(1)){
    p=p.star
  }

  ####
  ####  Calculate Pred Accuracy 
  ####

  pred.acc.save[k]=sum((z.true-z)==0)/n

  ####
  ####  Save Samples 
  ####

  beta.save[,k]=beta
  if(k > n.burn){
    z.mean=z.mean+z/(n.mcmc-n.burn)
  }
  N.save[k]=sum(z)
  p.save[k]=p
  p1.save[k]=p1
  p0.save[k]=p0

}
cat("\n")

####
####  Write Output 
####

list(beta.save=beta.save,p.save=p.save,p1.save=p1.save,p0.save=p0.save,z.mean=z.mean,N.save=N.save,pred.acc.save=pred.acc.save,n.mcmc=n.mcmc)

}
