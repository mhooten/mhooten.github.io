###
###  Chapter 4 Code
###

###
###  Code Box 4.1
###
###  Simple first MCMC algorithm w/ M-H updates 
###

y=0
K=1000
theta=0.5  # initial value
theta.save=rep(0,K)
theta.save[1]=theta

set.seed(1)
for(k in 2:K){
  theta.star=runif(1)
  mh=dbinom(y,1,theta.star)/dbinom(y,1,theta)
  if(rbinom(1,1,min(mh,1))==1){
    theta=theta.star 
  }
  theta.save[k]=theta
}

pdf(file="theta_trace.pdf",width=8,height=3)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(c(1,1,2),1,3))
plot(theta.save,type="l",xlab="k",ylab=bquote(theta),lwd=1,ylim=c(0,1),main="a")
hist(theta.save,prob=TRUE,col=8,xlab=bquote(theta),main="b",asp=TRUE)
segments(0,2,1,0,lty=2)
dev.off()

###
###  Code Box 4.2
###
###  Posterior mean and variance of theta
###

mean(theta.save)
var(theta.save)

###
###  Code Boxes 4.3-4.4, alternative syntax not shown
###


###
###  Code Box 4.5
###
###  ACF of Markov chain  
###

pdf(file="theta_acf.pdf",width=8,height=4)
acf(theta.save,main="")
dev.off()

###
###  Code Box 4.6
###
###  Monitor sample length of theta  
###

theta.mean=rep(0,K)
theta.var=rep(0,K)
for(k in 1:K){
  theta.mean[k]=mean(theta.save[1:k])
  theta.var[k]=var(theta.save[1:k])
}

pdf(file="theta_length.pdf",width=8,height=4)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
matplot(cbind(theta.mean,theta.var),type="l",lty=1,col=c(1,8),xlab="k",ylab="value")
legend("topright",legend=c("mean","variance"),lty=1,col=c(1,8),lwd=2)
abline(h=c(1/3,1/18),col=c(1,8),lty=2)
dev.off()

