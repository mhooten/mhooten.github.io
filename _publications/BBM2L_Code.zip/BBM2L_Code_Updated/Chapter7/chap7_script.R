###
###  Chapter 7 R Script
###

###
###  Code Box 7.1
###
###  Normal-Normal Posterior
###

n=10
mu=2
s2=1
set.seed(1)
y=rnorm(n,mu,sqrt(s2))

mu0=0
s20=10

mu.var=1/(n/s2+1/s20)
mu.mean=mu.var*(sum(y)/s2+mu0/s20)
pdf(file="mu_post.pdf",width=8,height=5)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
curve(dnorm(x,mu.mean,sqrt(mu.var)),n=1000,from=-2,to=6,lwd=1.5,xlab=bquote(mu),ylab="Density")
curve(dnorm(x,mu0,sqrt(s20)),n=1000,from=-2,to=6,lwd=1.5,lty=2,add=TRUE)
rug(y,col=1)
dev.off()

