scr.mcmc <- function(Y,J,X,n.mcmc){

####
####  Code Box 27.1
####

####
####  Libraries and Subroutines
####

cloglog.inv <- function(x){
  1-exp(-exp(x))
}

crossdist <- function(S1,S2) { 
    c1 <- complex(real=S1[,1], imaginary=S1[,2]) 
    c2 <- complex(real=S2[,1], imaginary=S2[,2]) 
    dist <- outer(c1, c2, function(z1, z2) Mod(z1-z2)) 
    dist 
} 

####
####  Setup Variables 
####

M=dim(Y)[1]
L=dim(Y)[2]
idx.0=(apply(Y,1,sum)==0)
n=sum(!idx.0)
n.burn=round(.1*n.mcmc)

alpha.save=rep(0,n.mcmc)
beta.save=rep(0,n.mcmc)
psi.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)
D.save=rep(0,n.mcmc)
z.mean=rep(0,M)
S.mean=matrix(0,M,2)
S1.save=matrix(0,n.mcmc,2)
S2.save=matrix(0,n.mcmc,2)

y.lims=c(-1,1)
x.lims=c(-1,1)

A=(x.lims[2]-x.lims[1])*(y.lims[2]-y.lims[1])

####
####  Priors and Starting Values 
####

mu.alpha=-2
s2.alpha=1.5^2

mu.beta=-40
s2.beta=10

z=as.numeric(!idx.0)
S=matrix(0,M,2)
S[-(1:n),1]=runif(M-n,x.lims[1],x.lims[2])
S[-(1:n),2]=runif(M-n,y.lims[1],y.lims[2])

for(i in 1:n){
  tmp.idx=(Y[!idx.0,][i,]>0)
  S[i,]=apply(X[tmp.idx,],2,mean)
}

psi=.1
g.1=.001  #  scale prior
g.2=1
alpha=-2
beta=-40
D2=crossdist(S,X)^2	# M x L matrix of pairwise distances squared between S and X
P=cloglog.inv(alpha+beta*D2)
N=sum(z)

alpha.tune=.1
beta.tune=2
s.tune=.1

####
####  Begin MCMC Loop
####

for(k in 1:n.mcmc){
  if(k%%100==0) cat(k," ")

  ####
  ####  Sample psi 
  ####

  psi=rbeta(1,sum(z)+g.1,sum(1-z)+g.2)

  ####
  ####  Sample alpha
  ####

  alpha.star=rnorm(1,alpha,alpha.tune)
  P.star=cloglog.inv(alpha.star+beta*D2)
  mh1=sum(dbinom(Y[z==1,],J,P.star[z==1,],log=TRUE))+dnorm(alpha.star,mu.alpha,sqrt(s2.alpha),log=TRUE)
  mh2=sum(dbinom(Y[z==1,],J,P[z==1,],log=TRUE))+dnorm(alpha,mu.alpha,sqrt(s2.alpha),log=TRUE)
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    alpha=alpha.star
    P=P.star
  }

  ####
  ####  Sample beta  
  ####

  beta.star=rnorm(1,beta,beta.tune)
  P.star=cloglog.inv(alpha+beta.star*D2)
  mh1=sum(dbinom(Y[z==1,],J,P.star[z==1,],log=TRUE))+dnorm(beta.star,mu.beta,sqrt(s2.beta),log=TRUE)
  mh2=sum(dbinom(Y[z==1,],J,P[z==1,],log=TRUE))+dnorm(beta,mu.beta,sqrt(s2.beta),log=TRUE)
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    beta=beta.star
    P=P.star
  }

  ####
  ####  Sample z  
  ####
  
  tmp.prod=psi*apply((1-P)^J,1,prod)
  psi.tmp=tmp.prod/(tmp.prod+1-psi)
  z[idx.0]=rbinom(sum(idx.0),1,psi.tmp[idx.0])
  N=sum(z)

  ####
  ####  Sample s  
  ####

  for(i in 1:M){
    s.star=rnorm(2,S[i,],s.tune)
    if((s.star[1] >  x.lims[1]) & (s.star[1] < x.lims[2]) & (s.star[2] > y.lims[1]) & (s.star[2] < y.lims[2])){
      d.star=apply((s.star-t(X))^2,2,sum)
      p.star=cloglog.inv(alpha+beta*d.star)      
      mh1=z[i]*sum(dbinom(Y[i,],J,p.star,log=TRUE))
      mh2=z[i]*sum(dbinom(Y[i,],J,P[i,],log=TRUE))
      mh=exp(mh1-mh2)  
      if(mh > runif(1)){
        S[i,]=s.star
        P[i,]=p.star
      }
    }
  }       

  D2=crossdist(S,X)^2
  
  ####
  ####  Save Samples  
  ####

  alpha.save[k]=alpha 
  beta.save[k]=beta
  psi.save[k]=psi
  N.save[k]=N
  D.save[k]=N/A
  S1.save[k,]=S[19,]
  S2.save[k,]=S[36,]

  if(k > n.burn){
    z.mean=z.mean+z/(n.mcmc-n.burn)
    S.mean=S.mean+S/(n.mcmc-n.burn)
  }

}
cat("\n")

####
####  Write Output 
####

list(n.mcmc=n.mcmc,alpha.save=alpha.save,beta.save=beta.save,psi.save=psi.save,z.mean=z.mean,S.mean=S.mean,N.save=N.save,D.save=D.save,S1.save=S1.save,S2.save=S2.save)

}
