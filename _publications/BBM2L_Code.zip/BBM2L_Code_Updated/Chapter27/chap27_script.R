###
###  Spatial Capture-Recapture Models (Chapter 27)
###

###
### Code Box 27.2
###
### Simulate Data
###

N=100
L=100
J=5
A=4
alpha=-2
beta=-40

cloglog.inv <- function(x){
  1-exp(-exp(x))
}

x1=seq(-.5,.5,,sqrt(L))
x2=seq(-.5,.5,,sqrt(L))
x.mat=expand.grid(x1,x2)

set.seed(10)
s.mat=matrix(runif(N*2,-1,1),N,2)
p.mat=matrix(0,N,L)
y.mat=matrix(0,N,L)
for(i in 1:N){
  for(l in 1:L){
    p.mat[i,l]=cloglog.inv(alpha+beta*sum((s.mat[i,]-x.mat[l,])^2))
    y.mat[i,l]=rbinom(1,J,p.mat[i,l])
  }
}

idx.0=(apply(y.mat,1,sum)==0)
n=sum(!idx.0)
S.tmp=s.mat[!idx.0,]
S.avg=matrix(0,n,2)

for(i in 1:n){
  tmp.idx=(y.mat[!idx.0,][i,]>0)
  S.avg[i,]=apply(as.matrix(x.mat[!idx.0,][tmp.idx,]),2,mean)
}

pdf(file="scr_sim.pdf",width=10,height=10)
par(cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
plot(s.mat,xlim=c(-1,1),ylim=c(-1,1),asp=TRUE,xlab="",ylab="",type="n")
symbols(0,0,squares=1,add=TRUE,inches=FALSE)
symbols(0,0,squares=2,lty=2,add=TRUE,inches=FALSE)
text(S.tmp,labels=1:n,cex=1,pos=1)
points(x.mat,lwd=1.5,pch=4,col=8,cex=.75)
points(s.mat,pch=20,cex=.4,col=rgb(0,0,0,.8))
points(S.tmp,pch=20,cex=1,col=rgb(0,0,0,.8))
dev.off()

###
### Code Box 27.3
###
### Augment Data and Fit SCR Trap Array Model 
###

y.idx=(apply(y.mat,1,sum)>0)
Y=y.mat[y.idx,]
S=s.mat[y.idx,]
n=dim(Y)[1]
M=n+500
Y.aug=matrix(0,M,L)
Y.aug[1:n,]=Y

###
### Code Box 27.4
###
### Fit SCR Trap Array Model 
###

source("scr.mcmc.R") #  Code Box 27.1
n.mcmc=20000
set.seed(1)
mcmc.out=scr.mcmc(Y=Y.aug,J=J,X=x.mat,n.mcmc=n.mcmc)

pdf(file="scr_post.pdf",width=10,height=8)
par(cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$alpha.save,breaks=40,prob=TRUE,col=8,xlab=bquote(alpha),main="a")
curve(dnorm(x,-2,1.5),lwd=2,add=TRUE)
abline(v=alpha,col=1,lwd=2,lty=2)
hist(mcmc.out$beta.save,breaks=40,prob=TRUE,col=8,xlab=bquote(beta),main="b")
curve(dnorm(x,-40,10),lwd=2,add=TRUE)
abline(v=beta,col=1,lwd=2,lty=2)
hist(mcmc.out$N.save,breaks=seq(60,200,1),prob=TRUE,col=8,main="c",xlab="N",ylab="Probability")
abline(v=N,col=1,lwd=2,lty=2)
hist(mcmc.out$D.save,breaks=seq(10,50,1),prob=TRUE,col=8,main="d",xlab="D",ylab="Probability")
abline(v=N/4,col=1,lwd=2,lty=2)
dev.off()

#layout(matrix(1:6,3,2))
#plot(mcmc.out$alpha.save,type="l",ylab="alpha")
#abline(h=alpha,col=8,lwd=2)
#plot(mcmc.out$beta.save,type="l",ylab="beta")
#abline(h=beta,col=8,lwd=2)
#plot(mcmc.out$psi.save,type="l",ylab="psi")
#plot(mcmc.out$N.save,type="l",ylab="N")
#abline(h=N,col=8,lwd=2)
#plot(mcmc.out$D.save,type="l",ylab="D")
#abline(h=N/A,col=8,lwd=2)

###
### Code Box 27.5
###

mean(2*sqrt(-1/mcmc.out$beta.save))
quantile(2*sqrt(-1/mcmc.out$beta.save),c(0.025,0.975))

###
### Code Box 27.6
###

mean(exp(mcmc.out$alpha.save))
quantile(exp(mcmc.out$alpha.save),c(0.025,0.975))

#quantile(mcmc.out$N.save,c(0.025,0.975))

###
### Code Box 27.7
###

pt.col=rgb(0,0,0,.1)
pt.seq=seq(1,n.mcmc,,1000)
pdf(file="scr_actcent.pdf",width=10,height=10)
par(cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
plot(S,xlim=c(-1,1),ylim=c(-1,1),asp=TRUE,type="n",xlab="",ylab="")
points(mcmc.out$S1.save[pt.seq,],bg=pt.col,col=0,cex=1,pch=21)
points(mcmc.out$S2.save[pt.seq,],bg=pt.col,col=0,cex=1,pch=21)
points(x.mat,lwd=1.5,pch=4,col=8,cex=.75)
points(S[c(19,36),],pch=20,lwd=4,cex=1.5,col=1)
text(S[c(19,36),],labels=c(19,36),cex=1.5,pos=1)
symbols(0,0,squares=1,add=TRUE,inches=FALSE)
symbols(0,0,squares=2,lty=2,add=TRUE,inches=FALSE)
dev.off()


