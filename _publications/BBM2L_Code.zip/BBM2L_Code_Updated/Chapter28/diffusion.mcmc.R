diffusion.mcmc <- function(y,x,t.sample,dt,beta.mn,beta.var,c.lwr,c.upr,t0.lwr,t0.upr,theta.q,theta.r,beta.tune,c.tune,t0.tune,theta.tune,beta.start,c.start,t0.start,theta.start,n.mcmc){
  
  ###
  ###  Code Box 28.6
  ###

  ###
  ### Libraries and Subroutines 
  ###
  
  library(raster)
  library(sp)
  library(matrixcalc)
  
  neighborhood <- function(raster){
    nn=matrix(,length(raster[]),4)
    for(i in 1:dim(nn)[1]){
      loc=adjacent(raster,i)[,2] 
      ln=loc[which((loc+1)==i)] 
      rn=loc[which((loc-1)==i)] 
      bn=loc[which((loc-dim(raster)[2])==i)] 
      tn=loc[which((loc+dim(raster)[2])==i)] 
      nn[i,1]=if(length(ln)>0){ln}else{0}
      nn[i,2]=if(length(rn)>0){rn}else{0}
      nn[i,3]=if(length(bn)>0){bn}else{0}
      nn[i,4]=if(length(tn)>0){tn}else{0}
    }
    nn
  }
  
  propagator <- function(NN,delta,dx,dy,dt){
    H=matrix(0,dim(NN)[1],dim(NN)[1])
    for(i in 1:dim(H)[1]){
      if(length(which(NN[i,]>0))==4){
        H[i,i]=1-2*delta[i]*(dt/dx^2 + dt/dy^2)
        H[i,NN[i,1]]=dt/dx^2*delta[NN[i,1]]
        H[i,NN[i,2]]=dt/dx^2*delta[NN[i,2]]
        H[i,NN[i,3]]=dt/dy^2*delta[NN[i,3]]
        H[i,NN[i,4]]=dt/dy^2*delta[NN[i,4]]}
    }
    H
  }
  
  calc.lam <- function(H,lambda0,t.sample){
    T=max(t.sample)
    lambda=lambda0
    lambda[]=H%*%lambda0[]
    lambda=stack(mget(rep("lambda",T)))
    for(t in 2:T){
      lambda[[t]][]=H%*%lambda[[t-1]][]
    }
    lambda[[t.sample]]
  }
  
  pde.solve <- function(x,beta,c.vec,t0,theta,t.sample,dt,NN){
    delta=exp(beta[1] + beta[2]*x)
    H=propagator(NN,delta[],res(delta)[1],res(delta)[2],dt)
    lambda0=x
    lambda0[]=0
    lambda0[extract(lambda0,SpatialPoints(t(c.vec)),cell=TRUE)[1]]=theta
    lambda=calc.lam(H,lambda0,t.sample-round(t0))
    lambda
  }
  
  ####
  #### Setup Variables
  ####
  
  beta.save=matrix(,2,n.mcmc)
  c.save=matrix(,2,n.mcmc)
  t0.save=matrix(,1,n.mcmc)
  theta.save=matrix(,1,n.mcmc)
  NN=neighborhood(x)
  
  ###
  ### Starting Values
  ###
  
  beta=beta.start
  c.vec=c.start
  t0=t0.start
  theta=theta.start
  
  ###
  ### MCMC Loop
  ###
  
  for(k in 1:n.mcmc){
    if(k%%100==0) cat(k," ")
    
    ###
    ### Sample beta
    ###
    
    beta.star=rnorm(2,beta,beta.tune)
    lambda.star=pde.solve(x,beta.star,c.vec,t0,theta,t.sample,dt,NN)
    mh1=sum(dpois(vec(y[]),vec(lambda.star[]),log=TRUE)) + sum(dnorm(beta.star,beta.mn,sqrt(beta.var),log=TRUE))
    lambda=pde.solve(x,beta,c.vec,t0,theta,t.sample,dt,NN) 
    mh2=sum(dpois(vec(y[]),vec(lambda[]),log=TRUE)) + sum(dnorm(beta,beta.mn,sqrt(beta.var),log=TRUE))
    mh=exp(mh1-mh2)
    if(mh > runif(1)){
      beta=beta.star
      lambda=lambda.star
    }
    
    ###
    ### Sample c 
    ###
    
    c.star=rnorm(2,c.vec,c.tune)
    if((min(c.star) > c.lwr) & (max(c.star) < c.upr)){
      lambda.star=pde.solve(x,beta,c.star,t0,theta,t.sample,dt,NN)
      mh1=sum(dpois(vec(y[]),vec(lambda.star[]),log=TRUE)) + sum(dunif(c.star,c.lwr,c.upr,log=TRUE))
      mh2=sum(dpois(vec(y[]),vec(lambda[]),log=TRUE)) + sum(dunif(c.vec,c.lwr,c.upr,log=TRUE))
      mh=exp(mh1-mh2)
      if(mh > runif(1)){
        c.vec=c.star
        lambda=lambda.star
      }
    }  
    
    ###
    ### Sample t0
    ###
    
    t0.star=rnorm(1,t0,t0.tune)
    if((t0.star > t0.lwr) & (t0.star < t0.upr)){
      lambda.star=pde.solve(x,beta,c.vec,t0.star,theta,t.sample,dt,NN)
      mh1=sum(dpois(vec(y[]),vec(lambda.star[]),log=TRUE)) + dunif(t0.star,t0.lwr,t0.upr,log=TRUE)
      mh2=sum(dpois(vec(y[]),vec(lambda[]),log=TRUE)) + dunif(t0,t0.lwr,t0.upr,log=TRUE)
      mh=exp(mh1-mh2)
      if(mh > runif(1)){
        t0=t0.star
        lambda=lambda.star
      }
    }  
    
    ###
    ### Sample theta
    ###
    
    theta.star=rnorm(1,theta,theta.tune)
    if(theta.star > 0){
      lambda.star=pde.solve(x,beta,c.vec,t0,theta.star,t.sample,dt,NN)
      mh1=sum(dpois(vec(y[]),vec(lambda.star[]),log=TRUE)) + dgamma(theta.star,theta.q,,theta.r,log=TRUE)
      mh2=sum(dpois(vec(y[]),vec(lambda[]),log=TRUE)) + dgamma(theta,theta.q,,theta.r,log=TRUE)
      mh=exp(mh1-mh2)
      if(mh > runif(1)){
        theta=theta.star
        lambda=lambda.star
      }
    }
    
    ###
    ### Save Samples
    ###
    
    beta.save[,k]=beta
    c.save[,k]=c.vec
    t0.save[,k]=t0
    theta.save[,k]=theta
    
  }
  cat("\n")
  
  ###
  ###  Write Output
  ###
  
  list(beta.save=beta.save,c.save=c.save,t0.save=t0.save,theta.save=theta.save)
  
}


