###
###  Chapter 28 R Script
###

####
####  Phenomenological S-T Model:  Hierarchical VAR Model 
####

###
###  Code Box 28.2
###
###  Simulate Spatio-Temporal Data 
###

T=50
n=16
m=4
s2y=1
s2z=1
alpha.diag=c(-.75,0,.5,.9)
A=diag(alpha.diag)
alpha=c(A)
eigen(A)$values

K=matrix(0,n,m)
for(j in 1:m){
  K[(j*m-m+1):(j*m),j]=1
}
K

Z=matrix(0,T,m)
Y=matrix(0,T,n)

set.seed(101)
Z[1,]=rnorm(m)
Y[1,]=rnorm(n,K%*%Z[1,],sqrt(s2z))
for(t in 2:T){
  Z[t,]=rnorm(m,A%*%Z[t-1,],sqrt(s2z))
  Y[t,]=rnorm(n,K%*%Z[t,],sqrt(s2y))
}

###
###  Code Box 28.3
###
###  Fit Spatio-Temporal Model to Simulated Data 
###

source("st.mcmc.R") #  Code Box 28.1
n.mcmc=50000
set.seed(1)
mcmc.out=st.mcmc(Y=Y,K=K,n.mcmc=n.mcmc)

#layout(matrix(1:3,3,1))
#matplot(t(mcmc.out$alpha.save),type="l",lty=1)
#abline(h=alpha,col=8)
#plot(mcmc.out$s2y.save,type="l")
#abline(h=s2y,col=8)
#plot(mcmc.out$s2z.save,type="l")
#abline(h=s2z,col=8)

pdf(file="st_A_post.pdf",width=10,height=10)
par(cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:(m^2),m,m))
for(i in 1:4){
  hist(mcmc.out$alpha.save[i,],breaks=seq(-4,4,,200),col=8,prob=TRUE,xlab=bquote(alpha[.(i)]),main="",xlim=c(-1,1))
  curve(dnorm(x,0,10),lwd=2,add=TRUE)
  abline(v=alpha[i],lwd=2,lty=2)
}
for(i in 5:(m^2)){
  hist(mcmc.out$alpha.save[i,],breaks=seq(-4,4,,200),col=8,prob=TRUE,xlab=bquote(alpha[.(i)]),main="",ylab="",xlim=c(-1,1))
  curve(dnorm(x,0,10),lwd=2,add=TRUE)
  abline(v=alpha[i],lwd=2,lty=2)
}
dev.off()

###
###  Code Box 28.4
###

n.burn=mcmc.out$n.burn
mean(mcmc.out$s2y.save[-(1:n.burn)])
quantile(mcmc.out$s2y.save[-(1:n.burn)],c(0.025,0.975))
mean(mcmc.out$s2z.save[-(1:n.burn)])
quantile(mcmc.out$s2z.save[-(1:n.burn)],c(0.025,0.975))

###
###  Code Box 28.5
###

pdf(file="st_z_post.pdf",width=10,height=10)
par(cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:m,m,1))
for(j in 1:m){
  matplot(1:T,Y[,(j*m-m+1):(j*m)],type="p",pch=20,cex=1.5,col=rgb(0,0,0,.4),xlab="t",ylab=bquote(z[.(j)]))
  lines(1:T,Z[,j],lty=1,lwd=2,col=rgb(0,0,0,.4))
  lines(0:T,mcmc.out$Z.mean[,j],lty=1,lwd=2,col=1)
}
dev.off()

####
####  Mechanistic S-T Model:  Ecological Diffusion  
####

###
### Code Box 28.7
###
### Simulate Data
###

library(raster)
library(sp)
library(matrixcalc)
library(rasterVis)
library(grDevices)
source("required.functions.R")

beta=c(-8.5,-1) 
c.vec=c(0.5,0.5)
t0=-10
theta=1000

T=20
dt=1
t.sample=seq(1,T,by=1*dt)
m=625

x=raster(vals=0,nrows=m^0.5,ncols=m^0.5,xmn=0,xmx=1,ymn=0,ymx=1,crs=NA)
set.seed(1244)
x[]=rbinom(m,1,pnorm(-1.5+3*xyFromCell(x,1:m)[,1]))
levelplot(x, margin=FALSE,scales=list(draw=FALSE),cuts=1,col.regions=c("white","gray40"))

delta=raster(vals=0,nrows=m^0.5,ncols=m^0.5,xmn=0, xmx=1, ymn=0,ymx=1,crs=NA)
delta[]=exp(model.matrix(~x[])%*%beta)
ramp.gray=colorRampPalette(c("white","gray30"))(2000)
levelplot(delta,margin=FALSE,scales=list(draw=FALSE),cuts=2000,col.regions=ramp.gray)

NN=neighborhood(x)
lambda=pde.solve(x,beta,c.vec,t0,theta,t.sample,dt,NN)
#levelplot(lambda, margin=FALSE,scales=list(draw=FALSE),names.attr=paste("t =",t.sample),cuts=2000,col.regions=ramp.gray)

y=raster(vals=0,nrows=m^0.5,ncols=m^0.5,xmn=0,xmx=1,ymn=0,ymx=1,crs=NA)
y=stack(mget(rep("y",length(t.sample))))
set.seed(9533)
y[]=rpois(prod(dim(lambda)),vec(lambda[]))

pdf(file="diff_data.pdf",width=10,height=10)
par(cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
levelplot(y, margin=FALSE,scales=list(draw=FALSE),names.attr=paste("t =",t.sample),cuts=2000,col.regions=ramp.gray)
dev.off()

####
#### Code Box 28.8
####
#### Fit Ecological Diffusion Model 
####

source("diffusion.mcmc.R") # Code Box 28.6
set.seed(3204)
mcmc.out=diffusion.mcmc(y=y,x=x,t.sample=t.sample,dt=dt,beta.mn=0,beta.var=100,c.lwr=0,c.upr=1,t0.lwr=-100,t0.upr=0,theta.q=1,theta.r=1000,beta.tune=0.025,c.tune=0.025,t0.tune=1.5,theta.tune=25,beta.start=beta,c.start=c(0.25,0.25),t0.start=-25,theta.start=theta,n.mcmc=20000)

#layout(matrix(1:4,4,1))
#plot(mcmc.out$beta.save[1,],typ="l",ylab="")
#lines(mcmc.out$beta.save[2,],typ="l",ylab="")
#plot(mcmc.out$c.save[1,],typ="l",ylab="")
#lines(mcmc.out$c.save[1,],typ="l",ylab="")
#plot(mcmc.out$t0.save[1,],typ="l",ylab="")
#plot(mcmc.out$theta.save[1,],typ="l",ylab="")

pdf(file="diff_post.pdf",height=10,width=10)
par(cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
n.burn=5000
layout(matrix(c(1,3,5,2,4,6),3,2))
hist(mcmc.out$beta.save[1,-(1:n.burn)],xlab=bquote(beta[1]),main="",prob=TRUE,col=8,breaks=30,las=1)
abline(v=beta[1],lwd=2,lty=2)
hist(mcmc.out$beta.save[2,-(1:n.burn)],xlab=bquote(beta[2]),main="",prob=TRUE,col=8,breaks=30,las=1)
abline(v=beta[2],lwd=2,lty=2)
hist(mcmc.out$c.save[1,-(1:n.burn)],xlab=bquote(c[1]),main="",prob=TRUE,col=8,breaks=seq(0.4,0.6,by=0.006),las=1)
abline(v=c.vec[1],lwd=2,lty=2)
hist(mcmc.out$c.save[2,-(1:n.burn)],xlab=bquote(c[2]),main="",prob=TRUE,col=8,breaks=seq(0.4,0.6,by=0.006),las=1)
abline(v=c.vec[2],lwd=2,lty=2)
hist(mcmc.out$t0.save[1,-(1:n.burn)],xlab=bquote(t[0]),main="",prob=TRUE,col=8,breaks=seq(-11,-9,by=0.05),las=1)
abline(v=t0,lwd=2,lty=2)
hist(mcmc.out$theta.save[1,-(1:n.burn)],xlab=bquote(theta),main="",prob=TRUE,col=8,breaks=30,las=1)
abline(v=theta,lwd=2,lty=2)
dev.off()  

