# Load required packages
library(raster)
library(sp)
library(matrixcalc)
library(rasterVis)
library(grDevices)


setwd("~/Dropbox/Computational book/Spatio-temporal chapter/R code")
source("required.functions.R")
####
#### Set parameters for simulated data
####

# Intercept and coefficient for diffusion rate
beta <- c(-8.5,-1) 

# Location of initial release
omega <- c(0.5,0.5)

# time of initial release (before first data colleciton)
t0 <- -10

# Expected number of individuals released
theta <- 1000



####
#### Simulate data
####

# Number of time steps to collect data
T <- 20
dt <- 1
t.sample <- seq(1,T,by=1*dt)

# Number of spatial grid cells
m <- 625

# Simulate covariate for space/time varying diffusion rate
x <- raster(vals=0,nrows=m^0.5,ncols=m^0.5,xmn=0, xmx=1, ymn=0, ymx=1,crs=NA)
set.seed(1244)
x[] <-    rbinom(m,1,pnorm(-1.5+3*xyFromCell(x,1:m)[,1]))
levelplot(x, margin=FALSE,scales=list(draw=FALSE),cuts=1,col.regions = c("white","gray40"))


# Simulate space/time varying diffusion rate
delta <- raster(vals=0,nrows=m^0.5,ncols=m^0.5,xmn=0, xmx=1, ymn=0, ymx=1,crs=NA)
delta[] <- exp(model.matrix(~x[])%*%beta)
ramp.gray <- colorRampPalette(c("white","gray30"))(2000)
levelplot(delta, margin=FALSE,scales=list(draw=FALSE),cuts=2000,col.regions = ramp.gray)

# Solve PDE and get lambda(s,t)
NN <- neighborhood(x)
lambda <- pde.solve(x,beta,omega,t0,theta,t.sample,dt,NN)

# Plot spatial time series of u(s,t) diffusion PDE 
levelplot(lambda, margin=FALSE,scales=list(draw=FALSE),names.attr=paste("t =",t.sample),cuts=2000,col.regions = ramp.gray)

# Simulate count data and plot
y <- raster(vals=0,nrows=m^0.5,ncols=m^0.5,xmn=0, xmx=1, ymn=0, ymx=1,crs=NA)
y <- stack(mget(rep("y",length(t.sample))))
set.seed(9533)
y[] <- rpois(prod(dim(lambda)),vec(lambda[]))

#pdf(file="Fig_1.pdf",height=5,width=4)
# Plot spatial time series of simulated data (counts within grid cells)
levelplot(y, margin=FALSE,scales=list(draw=FALSE),names.attr=paste("t =",t.sample),cuts=2000,col.regions = ramp.gray)
#dev.off()

####
#### MCMC
####

setwd("~/Dropbox/Computational book/Spatio-temporal chapter/R code")
source("diffusion.mcmc.R")
ptm <- proc.time()
set.seed(3204)
mcmc.out=diffusion.mcmc(y=y,x=x,t.sample=t.sample,dt=dt,
                        beta.mn=0,beta.var=100,omega.lwr=0,omega.upr=1,t0.lwr=-100,t0.upr=0,theta.q=1,theta.r=1000,
                        beta.tune=0.025,omega.tune=0.025,t0.tune=1.5,theta.tune=25,
                        beta.start=beta,omega.start=c(0.25,0.25),t0.start=-25,theta.start=theta,n.mcmc=20000)
proc.time() - ptm

# Trace plots
plot(mcmc.out$beta[1,],typ="l",xlab="k",ylab="")
plot(mcmc.out$beta[2,],typ="l",xlab="k",ylab="")
plot(mcmc.out$omega[1,],typ="l",xlab="k",ylab="")
plot(mcmc.out$omega[1,],typ="l",xlab="k",ylab="")
plot(mcmc.out$t0[1,],typ="l",xlab="k",ylab="")
plot(mcmc.out$theta[1,],typ="l",xlab="k",ylab="")

#Acceptance rate
length(which(abs(diff(mcmc.out$beta[1,]))>0))/dim(mcmc.out$beta)[2]
length(which(abs(diff(mcmc.out$omega[1,]))>0))/dim(mcmc.out$omega)[2]
length(which(abs(diff(mcmc.out$t0[1,]))>0))/dim(mcmc.out$t0)[2]
length(which(abs(diff(mcmc.out$theta[1,]))>0))/dim(mcmc.out$theta)[2]

# Plot posteriors
#pdf(file="Fig_2.pdf",height=6,width=4)
burn.in <- 5000
layout(matrix(c(1,3,5,2,4,6),3,2))
hist(mcmc.out$beta[1,-c(1:burn.in)],xlab=expression(beta[0]*"|"*bold(y)),ylab=expression("["*beta[0]*"|"*bold(y)*"]"),main="",freq=FALSE,col="grey",breaks=10,las=1)
abline(v=beta[1],lwd=1,lty=2)

hist(mcmc.out$beta[2,-c(1:burn.in)],xlab=expression(beta[1]*"|"*bold(y)),ylab=expression("["*beta[1]*"|"*bold(y)*"]"),main="",freq=FALSE,col="grey",breaks=10,las=1)
abline(v=beta[2],lwd=1,lty=2)

hist(mcmc.out$omega[1,-c(1:burn.in)],xlab=expression(omega[1]*"|"*bold(y)),ylab=expression("["*omega[1]*"|"*bold(y)*"]"),main="",freq=FALSE,col="grey",breaks=seq(0.4,0.6,by=0.008),las=1)
abline(v=omega[1],lwd=1,lty=2)

hist(mcmc.out$omega[2,-c(1:burn.in)],xlab=expression(omega[2]*"|"*bold(y)),ylab=expression("["*omega[2]*"|"*bold(y)*"]"),main="",freq=FALSE,col="grey",breaks=seq(0.4,0.6,by=0.008),las=1)
abline(v=omega[2],lwd=1,lty=2)

hist(mcmc.out$t0[1,-c(1:burn.in)],xlab=expression(t[0]*"|"*bold(y)),ylab=expression("["*t[0]*"|"*bold(y)*"]"),main="",freq=FALSE,col="grey",breaks=seq(-11,-9,by=0.13),las=1)
abline(v=t0,lwd=1,lty=2)
 
hist(mcmc.out$theta[1,-c(1:burn.in)],xlab=expression(theta*"|"*bold(y)),ylab=expression("["*theta*"|"*bold(y)*"]"),main="",freq=FALSE,col="grey",breaks=10,las=1)
abline(v=theta,lwd=1,lty=2)
#dev.off()  
  