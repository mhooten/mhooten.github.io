####
#### Required functions
####

# First-order neighborhood matrix from a raster layer
neighborhood <- function(raster){
  nn=matrix(,length(raster[]),4)
  for(i in 1:dim(nn)[1]){
    loc=adjacent(raster,i)[,2] 
    ln=loc[which((loc+1)==i)] 
    rn=loc[which((loc-1)==i)] 
    bn=loc[which((loc-dim(raster)[2])==i)] 
    tn=loc[which((loc+dim(raster)[2])==i)] 
    nn[i,1]=if(length(ln)>0){ln}else{0}
    nn[i,2]=if(length(rn)>0){rn}else{0}
    nn[i,3]=if(length(bn)>0){bn}else{0}
    nn[i,4]=if(length(tn)>0){tn}else{0}
  }
  nn
}

# Propagator matrix
propagator <- function(NN,delta,dx,dy,dt){
  H=matrix(0,dim(NN)[1],dim(NN)[1])
  for(i in 1:dim(H)[1]){
    if(length(which(NN[i,]>0))==4){
      H[i,i]=1-2*delta[i]*(dt/dx^2 + dt/dy^2)
      H[i,NN[i,1]]=dt/dx^2*delta[NN[i,1]]
      H[i,NN[i,2]]=dt/dx^2*delta[NN[i,2]]
      H[i,NN[i,3]]=dt/dy^2*delta[NN[i,3]]
      H[i,NN[i,4]]=dt/dy^2*delta[NN[i,4]]}
  }
  H
}

# RasterStack of lambda(s,t)
calc.lam <- function(H,lambda0,t.sample){
  T=max(t.sample)
  lambda=lambda0
  lambda[]=H%*%lambda0[]
  lambda=stack(mget(rep("lambda",T)))
  for(t in 2:T){
    lambda[[t]][]=H%*%lambda[[t-1]][]
  }
  lambda[[t.sample]]
}

# Get samples of u(s,t)
pde.solve <- function(x,beta,omega,t0,theta,t.sample,dt,NN){
  delta=exp(beta[1] + beta[2]*x)
  H=propagator(NN,delta[],res(delta)[1],res(delta)[2],dt)
  lambda0=x
  lambda0[]=0
  lambda0[extract(lambda0,SpatialPoints(t(omega)),cell=TRUE)[1]]=theta
  lambda=calc.lam(H,lambda0,t.sample-round(t0))
  lambda
}
