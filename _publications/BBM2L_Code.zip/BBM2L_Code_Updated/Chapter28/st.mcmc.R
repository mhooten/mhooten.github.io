st.mcmc <- function(Y,K,n.mcmc){

###
### Code Box 28.1
###

###
### Set up variables
###

n.burn=round(.2*n.mcmc)
T=dim(Y)[1]
n=dim(Y)[2]
m=dim(K)[2]

s2y.save=rep(0,n.mcmc)
s2z.save=rep(0,n.mcmc)
alpha.save=matrix(0,m^2,n.mcmc)

Z=matrix(0,T+1,m)

###
### Hyperparameters and starting values
###

r=1000
q=0.001
mu.alpha=rep(0,m^2)
Sig.alpha.inv=diag(m^2)/100

Z=matrix(0,T+1,m)
Z[-1,]=t(solve(t(K)%*%K)%*%t(K)%*%(t(Y)))
Z[1,]=Z[2,]
 
s2y=.1
s2z=.1

mu.0=rep(0,m)
Sig.0.inv=diag(m)/100

Im=diag(m)
Z.mean=matrix(0,T+1,m)

###
### Begin MCMC Loop 
###

for(k in 1:n.mcmc){
  if(k%%1000==0){cat(k," ")}

  ###
  ### Sample alpha 
  ###

  tmp.chol=chol(t(Z[1:T,]%x%Im)%*%(Z[1:T,]%x%Im)/s2z + Sig.alpha.inv) 
  alpha=backsolve(tmp.chol,backsolve(tmp.chol,(t(Z[1:T,]%x%Im)%*%c(t(Z[-1,])))/s2z + Sig.alpha.inv%*%mu.alpha,transpose=TRUE)+rnorm(m^2))
  A=matrix(alpha,m,m)

  ###
  ### Sample s2y 
  ###
  
  tmp.sum=sum(apply((Y-Z[-1,]%*%t(K))^2,1,sum))
  r.tmp=1/(tmp.sum/2+1/r)
  q.tmp=n*T/2+q
  s2y=1/rgamma(1,q.tmp,,r.tmp)

  ###
  ### Sample s2z 
  ###

  tmp.sum=sum(apply((Z[-1,]-Z[1:T,]%*%t(A))^2,1,sum))
  r.tmp=1/(tmp.sum/2+1/r)
  q.tmp=m*T/2+q
  s2z=1/rgamma(1,q.tmp,,r.tmp)

  ###
  ### Sample z_t 
  ###

  tmp.chol=chol(t(K)%*%K/s2y+t(A)%*%A/s2z+Im/s2z) 
  for(t in 1:(T-1)){
    Z[t+1,]=backsolve(tmp.chol,backsolve(tmp.chol,t(K)%*%Y[t,]/s2y+t(A)%*%Z[t+1+1,]/s2z+A%*%Z[t-1+1,]/s2z,transpose=TRUE)+rnorm(m))
  }

  ###
  ### Sample z_T
  ###

  tmp.chol=chol(t(K)%*%K/s2y+Im/s2z) 
  Z[T+1,]=backsolve(tmp.chol,backsolve(tmp.chol,t(K)%*%Y[T,]/s2y+A%*%Z[T-1+1,]/s2z,transpose=TRUE)+rnorm(m))

  ###
  ### Sample z_0
  ###

  tmp.chol=chol(t(A)%*%A/s2z+Sig.0.inv) 
  Z[1,]=backsolve(tmp.chol,backsolve(tmp.chol,t(A)%*%Z[1+1,]/s2z+Sig.0.inv%*%mu.0,transpose=TRUE)+rnorm(m))

  ###
  ### Save Samples
  ###
  
  alpha.save[,k]=alpha
  s2y.save[k]=s2y
  s2z.save[k]=s2z
  if(k > n.burn){
    Z.mean=Z.mean+Z/(n.mcmc-n.burn)
  }

};cat("\n")

###
### Write Output 
###

list(alpha.save=alpha.save,s2y.save=s2y.save,s2z.save=s2z.save,Z.mean=Z.mean,n.mcmc=n.mcmc,n.burn=n.burn)

}
