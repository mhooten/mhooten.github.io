occ.sp.aux.mcmc <- function(y,J,X,W,n.mcmc){

####
####  Code Box 26.1
####

####
####  Libraries and Subroutines
####

rtn <- function(n,mu,sig2,low,high){
  flow=pnorm(low,mu,sqrt(sig2)) 
  fhigh=pnorm(high,mu,sqrt(sig2)) 
  u=runif(n) 
  tmp=flow+u*(fhigh-flow)
  x=qnorm(tmp,mu,sqrt(sig2))
  x
}

####
####  Setup Variables 
####

n=length(y)
p.X=dim(X)[2]
n.burn=round(0.25*n.mcmc)

z.mean=rep(0,n)
eta.mean=rep(0,n)
psi.mean=rep(0,n)
beta.save=matrix(0,p.X,n.mcmc)
p.save=rep(0,n.mcmc)
s2.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)

####
####  Hyperparameters and Starting Values 
####

beta=c(-.5,.5)
p=.25
Xbeta=X%*%beta
psi=pnorm(Xbeta)
z=rep(0,n)
z[y==0]=0
n0=sum(z==0)
n1=sum(z==1)

v=rep(0,n)

ny0=sum(y==0)
ny1=sum(y==1)

alpha.p=1
beta.p=1

r=1000
q=0.001

Sig.beta=diag(p.X)
Sig.beta.inv=solve(Sig.beta)
mu.beta=rep(0,p.X)

XprimeX=t(X)%*%X
A.beta=XprimeX+Sig.beta.inv
A.beta.chol=chol(A.beta)
Sig.beta.inv.times.mu.beta=Sig.beta.inv%*%mu.beta

rho=0.99
R.inv=diag(apply(W,1,sum))-rho*W
s2=5
Sigma.inv=R.inv/s2
eta=rep(0,n)

####
####  Begin Gibbs Loop 
####

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ####
  ####  Sample v 
  ####

  v[z==0]=rtn(n0,(Xbeta+eta)[z==0],1,-Inf,0)
  v[z==1]=rtn(n1,(Xbeta+eta)[z==1],1,0,Inf)

  ####
  ####  Sample beta 
  ####

  b.beta=t(X)%*%(v-eta)+Sig.beta.inv.times.mu.beta
  beta=backsolve(A.beta.chol,backsolve(A.beta.chol,b.beta,transpose=TRUE)+rnorm(p.X))
  Xbeta=X%*%beta
  psi=pnorm(Xbeta+eta)

  ####
  ####  Sample p 
  ####

  sum.1=sum(y[z==1])+alpha.p 
  sum.2=sum(J-y[z==1])+beta.p 
  p=rbeta(1,sum.1,sum.2)

  ####
  ####  Sample z 
  ####

  psi.numer=psi*(1-p)^J
  psi.tmp=psi.numer/(psi.numer+1-psi)
  psi.tmp[psi.tmp>1]=1
  z[y==0]=rbinom(sum(y==0),1,psi.tmp[y==0])
  z[y>0]=1
  n0=sum(z==0)
  n1=sum(z==1)

  ####
  ####  Sample eta
  ####

  b.eta=v-Xbeta  
  A.eta.chol=chol(diag(n)+Sigma.inv)  
  eta=backsolve(A.eta.chol,backsolve(A.eta.chol,b.eta,transpose=TRUE)+rnorm(n))
  psi=pnorm(Xbeta+eta)

  ####
  ####  Sample s2 
  ####

  q.tmp=n/2+q
  r.tmp=1/(t(eta)%*%R.inv%*%eta/2+1/r)
  s2=1/rgamma(1,q.tmp,,r.tmp)
  Sigma.inv=R.inv/s2
  
  ####
  ####  Save Samples 
  ####

  beta.save[,k]=beta
  p.save[k]=p
  s2.save[k]=s2
  if(k > n.burn){
    z.mean=z.mean+z/(n.mcmc-n.burn)
    eta.mean=eta.mean+eta/(n.mcmc-n.burn)
    psi.mean=psi.mean+psi/(n.mcmc-n.burn)
  }
  N.save[k]=sum(z)

}
cat("\n")

####
####  Write Output 
####

list(p.save=p.save,beta.save=beta.save,s2.save=s2.save,z.mean=z.mean,eta.mean=eta.mean,psi.mean=psi.mean,N.save=N.save,n.mcmc=n.mcmc,r=r,q=q)

}
