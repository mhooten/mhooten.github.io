###
###  Chapter 26 R Script 
###

###
###  Code Box 26.2
###
###  Simulate Spatial Occupancy Data
###

library(mvtnorm)

n.1=20
n.2=20
n=n.1*n.2
J=3
p=.6
s.1.vals=seq(0,1,,n.1)
s.2.vals=seq(0,1,,n.2)
S=expand.grid(s.1.vals,s.2.vals)
D=as.matrix(dist(S))
d.thresh=.05*max(D)
W=ifelse(D>d.thresh,0,1)
diag(W)=0
table(apply(W,1,sum))
rho=.99
s2=3
Sigma=s2*solve(diag(apply(W,1,sum))-rho*W)
set.seed(2)
eta=c(rmvnorm(1,rep(0,n),Sigma,method="chol"))

X=matrix(1,n,2)
X[,2]=rnorm(n)
beta=c(-.5,.5)

psi=pnorm(X%*%beta+eta)
z=rbinom(n,1,psi)
y=rbinom(n,J,z*p)

sq.cex=2.95
pdf(file="occ_sp_sim.pdf",width=10.5,height=10.5)
par(cex.lab=1.5,cex.main=1.5,xaxt="n",yaxt="n",bty="n",mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
plot(S,type="n",xlab="",ylab="",asp=TRUE,main="a")
points(S,pch=15,cex=sq.cex,col=rgb(0,0,0,(X[,2]-min(X[,2]))/diff(range(X[,2]))))
plot(S,type="n",xlab="",ylab="",asp=TRUE,main="b")
points(S,pch=15,cex=sq.cex,col=rgb(0,0,0,(eta-min(eta))/diff(range(eta))))
plot(S,type="n",xlab="",ylab="",asp=TRUE,main="c")
points(S,pch=15,cex=sq.cex,col=rgb(0,0,0,psi))
plot(S,type="n",xlab="",ylab="",asp=TRUE,main="d")
points(S,pch=15,cex=sq.cex,col=rgb(0,0,0,y/J))
dev.off()

###
###  Code Box 26.3
###
###  Fit Spatial Occupancy Model using Auxiliary Variables 
###

source("occ.sp.aux.mcmc.R") # Code Box 26.1
n.mcmc=40000
set.seed(1)
mcmc.out=occ.sp.aux.mcmc(y=y,J=J,X=X,W=W,n.mcmc=n.mcmc)

#layout(matrix(1:3,3,1))
#matplot(t(mcmc.out$beta.save),type="l",lty=1)
#abline(h=beta,col=8)
#plot(mcmc.out$p.save,type="l")
#abline(h=p,col=8)
#plot(mcmc.out$s2.save,type="l")
#abline(h=s2,col=8)

dIG <- function(x,r,q){x^(-(q+1))*exp(-1/r/x)/(r^q)/gamma(q)}
pdf(file="occ_sp_post.pdf",width=10,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,-(1:1000)],breaks=50,col=8,xlab=bquote(beta[0]),prob=TRUE,main="a")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
abline(v=beta[1],lty=2,lwd=2)
hist(mcmc.out$beta.save[2,-(1:1000)],breaks=70,col=8,xlab=bquote(beta[1]),prob=TRUE,main="b")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
abline(v=beta[2],lty=2,lwd=2)
hist(mcmc.out$p.save[-(1:1000)],breaks=8,col=8,xlab="p",xlim=c(0,1),prob=TRUE,main="c")
curve(dbeta(x,1,1),lwd=2,add=TRUE)
abline(v=p,lty=2,lwd=2)
hist(mcmc.out$s2.save[-(1:1000)],breaks=50,col=8,xlab=bquote(sigma^2),prob=TRUE,main="d")
curve(dIG(x,mcmc.out$r,mcmc.out$q),n=1000,from=0,to=14,lwd=2,add=TRUE)
abline(v=s2,lty=2,lwd=2)
dev.off()

mean(mcmc.out$N.save[-(1:1000)])
quantile(mcmc.out$N.save[-(1:1000)],c(0.025,0.975))

###
###  Code Box 26.4
###

eta.mn=mcmc.out$eta.mean
sq.cex=2.1
pdf(file="occ_sp_eta.pdf",width=10,height=5)
par(cex.lab=1.5,cex.main=1.5,xaxt="n",yaxt="n",bty="n",mar=c(5,5,4,2))
layout(matrix(1:2,1,2))
plot(S,type="n",xlab="",ylab="",asp=TRUE,main="a")
points(S,pch=15,cex=sq.cex,col=rgb(0,0,0,(eta-min(eta))/diff(range(eta))))
plot(S,type="n",xlab="",ylab="",asp=TRUE,main="b")
points(S,pch=15,cex=sq.cex,col=rgb(0,0,0,(eta.mn-min(eta.mn))/diff(range(eta.mn))))
points(S[y>0,],cex=.1,col=8)
dev.off()

