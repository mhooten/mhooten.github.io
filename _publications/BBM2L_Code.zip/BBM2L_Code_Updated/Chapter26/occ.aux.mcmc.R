occ.aux.mcmc <- function(Y,J,W,X,n.mcmc){

####
####  Libraries and Subroutines
####

rtn <- function(n,mu,sig2,low,high){
  flow=pnorm(low,mu,sqrt(sig2)) 
  fhigh=pnorm(high,mu,sqrt(sig2)) 
  u=runif(n) 
  tmp=flow+u*(fhigh-flow)
  x=qnorm(tmp,mu,sqrt(sig2))
  x
}

####
####  Setup Variables 
####

n=dim(Y)[1]
p.X=dim(X)[2]
p.W=dim(W)[2]
n.burn=round(0.25*n.mcmc)

z.mean=rep(0,n)
beta.save=matrix(0,p.X,n.mcmc)
alpha.save=matrix(0,p.W,n.mcmc)
N.save=rep(0,n.mcmc)

####
####  Hyperparameters and Starting Values 
####

beta=rep(0,p.X)
alpha=rep(0,p.W)
Xbeta=X%*%beta
Walpha=W%*%alpha
psi=pnorm(Xbeta)
p=pnorm(Walpha)
Y.sum=apply(Y,1,sum)
z=rep(0,n)
z[Y.sum==0]=0
n0=sum(z==0)
n1=sum(z==1)
z.1.big=rep(z==1,J)

v=rep(0,n)
u=rep(0,n*J)

y=as.vector(Y)
ny0=sum(y==0)
ny1=sum(y==1)

Sig.beta=1.5*diag(p.X)
Sig.alpha=1.5*diag(p.W)
Sig.beta.inv=solve(Sig.beta)
Sig.alpha.inv=solve(Sig.alpha)

mu.beta=rep(0,p.X)
mu.alpha=rep(0,p.W)

XprimeX=t(X)%*%X
A.beta=XprimeX+Sig.beta.inv
A.beta.chol=chol(A.beta)
Sig.beta.inv.times.mu.beta=Sig.beta.inv%*%mu.beta
Sig.alpha.inv.times.mu.alpha=Sig.alpha.inv%*%mu.alpha

####
####  Begin Gibbs Loop 
####

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ####
  ####  Sample v 
  ####
 
  v[z==0]=rtn(n0,Xbeta[z==0],1,-Inf,0)
  v[z==1]=rtn(n1,Xbeta[z==1],1,0,Inf)

  ####
  ####  Sample U 
  ####
  ####  Note: sampling the `extra' u where z=0 is wasteful, but ok to do.
  ####

  u[y==0]=rtn(ny0,Walpha[y==0],1,-Inf,0)
  u[y==1]=rtn(ny1,Walpha[y==1],1,0,Inf)

  ####
  ####  Sample beta 
  ####

  b.beta=t(X)%*%v+Sig.beta.inv.times.mu.beta
  beta=backsolve(A.beta.chol, backsolve(A.beta.chol, b.beta, transpose = TRUE) + rnorm(p.X))
  Xbeta=X%*%beta
  psi=pnorm(Xbeta)

  ####
  ####  Sample alpha 
  ####
 
  W.tmp=W[z.1.big,]
  A.alpha=t(W.tmp)%*%W.tmp+Sig.alpha.inv
  A.alpha.chol=chol(A.alpha)
  b.alpha=t(W.tmp)%*%u[z.1.big]+Sig.alpha.inv.times.mu.alpha
  alpha=backsolve(A.alpha.chol, backsolve(A.alpha.chol, b.alpha, transpose = TRUE) + rnorm(p.W))
  Walpha=W%*%alpha
  p=pnorm(Walpha)

  ####
  ####  Sample z 
  ####

  psi.numer=psi*apply(1-matrix(p,n,J),1,prod)
  psi.tmp=psi.numer/(psi.numer+1-psi)
  z[Y.sum==0]=rbinom(sum(Y.sum==0),1,psi.tmp[Y.sum==0])
  z[Y.sum>0]=1
  n0=sum(z==0)
  n1=sum(z==1)
  z.1.big=rep(z==1,J)

  ####
  ####  Save Samples 
  ####

  beta.save[,k]=beta
  alpha.save[,k]=alpha
  if(k > n.burn){
    z.mean=z.mean+z/(n.mcmc-n.burn)
  }
  N.save[k]=sum(z)


}
cat("\n")

####
####  Write Output 
####

list(alpha.save=alpha.save,beta.save=beta.save,z.mean=z.mean,N.save=N.save,n.mcmc=n.mcmc)

}
