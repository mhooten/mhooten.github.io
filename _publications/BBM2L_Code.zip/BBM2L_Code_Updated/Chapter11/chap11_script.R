###
###  Chapter 11 R Code
###

###
### Hefley Deer Data  
###
### Original Data
### https://datadryad.org/bitstream/handle/10255/dryad.44854/Deer%20Body%20Mass%20Data.xlsx?sequence=1
###
### Paper
### http://fwspubs.org/doi/pdf/10.3996/022012-JFWM-015
###

###
###  Code Box 11.2
###
###  Deer Analysis
###

load("deer.RData")
n=dim(deer.df)[1]
y=deer.df$y
X=cbind(rep(1,n),as.matrix(deer.df[,-1]))
X[,2]=ifelse(X[,2]==599,0,1)
n=dim(X)[1]
p=dim(X)[2]

source("norm.reg.mcmc.R") # Code Box 11.1
set.seed(1)
mcmc.out=norm.reg.mcmc(y=y,X=X,beta.mn=rep(0,p),beta.var=10000,s2.mn=50,s2.sd=1000,n.mcmc=10000)

####
####  Make Trace Plots 
####

layout(matrix(1:6,3,2))
plot(mcmc.out$beta.save[1,],type="l",lty=1) # intercept
plot(mcmc.out$beta.save[2,],type="l",lty=1) # crop
plot(mcmc.out$beta.save[3,],type="l",lty=1) # sex (male=1)
plot(mcmc.out$beta.save[4,],type="l",lty=1) # age
plot(mcmc.out$beta.save[5,],type="l",lty=1) # age^2
plot(mcmc.out$s2.save,type="l")

####
####  Make Posterior Histograms 
####

dIG <- function(x,igmn,igvar){
  q <- 2+(igmn^2)/igvar
  r <- 1/(igmn*(q-1))
  x^(-q-1) * exp(-1/r/x) / (r^q) / gamma(q)
}

pdf(file="normreg_post.pdf",width=7,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:6,3,2))
hist(mcmc.out$beta.save[1,],prob=TRUE,col=8,breaks=40,main="a",xlab=bquote(beta[0]))
curve(dnorm(x,0,10000),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,],prob=TRUE,col=8,breaks=40,main="b",xlab=bquote(beta[1]))
curve(dnorm(x,0,10000),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,],prob=TRUE,col=8,breaks=40,main="c",xlab=bquote(beta[2]))
curve(dnorm(x,0,10000),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[4,],prob=TRUE,col=8,breaks=40,main="d",xlab=bquote(beta[3]))
curve(dnorm(x,0,10000),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[5,],prob=TRUE,col=8,breaks=40,main="e",xlab=bquote(beta[4]))
curve(dnorm(x,0,10000),lwd=2,add=TRUE)
hist(mcmc.out$s2.save,prob=TRUE,col=8,breaks=40,main="f",xlab=bquote(sigma^2))
curve(dIG(x,50,1000),lwd=2,add=TRUE)
dev.off()

quantile(mcmc.out$beta.save[2,],c(0.025,0.975))

####
####  Code Box 11.3 
####

x.mean.1=apply(X,2,mean)
x.mean.1[2]=1
x.mean.1[3]=1
x.mean.0=apply(X,2,mean)
x.mean.0[2]=1
x.mean.0[3]=0
quantile(x.mean.1%*%mcmc.out$beta.save,c(0.025,0.975))
quantile(x.mean.0%*%mcmc.out$beta.save,c(0.025,0.975))


