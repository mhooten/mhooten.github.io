mixnorm.mcmc <- function(y,n.mcmc,s.tune=0.5){

#####
#####  Code Box 10.2 
#####

#####
#####  Setup Variables
#####

n=length(y)
mu.mat=matrix(0,n.mcmc,2)
s.mat=matrix(0,n.mcmc,2)
p.vec=rep(0,n.mcmc)
z.mean=rep(0,n)
n.burn=round(.2*n.mcmc)
y.sim=rep(0,n.mcmc)

#####
#####  Priors 
#####

alpha=1
beta=1
mu01=14
mu02=18
s01=2
s02=2
u=2 # upper bound on sigma

#####
#####  Starting Values 
#####

p=.5
tmp.mn=mean(y)
z=rep(0,n)
z[y<tmp.mn]=1
mu1=mu01
mu2=mu02
s1=1
s2=1
s12=s1^2
s22=s2^2

#####
#####  Begin Gibbs Loop
#####

for(k in 1:n.mcmc){
  cat(k," ")

  #####
  #####  Sample z
  #####

  p.tmp=p*dnorm(y,mu1,s1)/(p*dnorm(y,mu1,s1)+(1-p)*dnorm(y,mu2,s2))
  z=rbinom(n,1,p.tmp)

  #####
  #####  Sample mu1 
  #####

  s2.tmp=(sum(z==1)/s12 + 1/s01)^(-1)
  mu.tmp=s2.tmp*(sum(y[z==1])/s12 + mu01/s01)
  mu1=rnorm(1,mu.tmp,sqrt(s2.tmp))

  #####
  #####  Sample mu2
  #####

  s2.tmp=(sum(z==0)/s22 + 1/s02)^(-1)
  mu.tmp=s2.tmp*(sum(y[z==0])/s22+mu02/s02)
  mu2=rnorm(1,mu.tmp,sqrt(s2.tmp))

  #####
  #####  Sample s1 
  #####

  s1.star=rnorm(1,s1,s.tune)
  if((s1.star > 0) & (s1.star < u)){  
    mh1=sum(z*dnorm(y,mu1,s1.star,log=TRUE))
    mh2=sum(z*dnorm(y,mu1,s1,log=TRUE))
    mh=exp(mh1-mh2)
    if(mh > runif(1)){
      s1=s1.star
      s12=s1^2
    }
  }

  #####
  #####  Sample s2
  #####

  s2.star=rnorm(1,s2,s.tune)
  if((s2.star > 0) & (s2.star < u)){  
    mh1=sum((1-z)*dnorm(y,mu2,s2.star,log=TRUE))
    mh2=sum((1-z)*dnorm(y,mu2,s2,log=TRUE))
    mh=exp(mh1-mh2)
    if(mh > runif(1)){
      s2=s2.star
      s22=s2^2
    }
  }

  #####
  #####  Sample p 
  #####
 
  p=rbeta(1,sum(z)+alpha,sum(1-z)+beta)
 
  #####
  #####  Save Samples 
  #####

  mu.mat[k,]=c(mu1,mu2)
  s.mat[k,]=c(s1,s2)
  p.vec[k]=p
  z.sim=rbinom(1,1,p)
  y.sim[k]=z.sim*rnorm(1,mu1,s1)+(1-z.sim)*rnorm(1,mu2,s2)

  if(k>n.burn){
    z.mean=z.mean+z/(n.mcmc-n.burn) 
  }

}
cat("\n")

#####
#####  Write Output 
#####

list(mu.mat=mu.mat,p.vec=p.vec,s.mat=s.mat,z.mean=z.mean,y.sim=y.sim,n.burn=n.burn)

}
