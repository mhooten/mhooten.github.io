##### 
#####  Chapter 10 R Code
##### 

##### 
#####  Code Box 10.1
##### 
#####  Creating mixture normal figure 
##### 

pdf(file="mixnorm.pdf",width=10,height=3.5)
layout(matrix(1:3,1,3))
p=.25
curve(dnorm(x,-2,1),col=8,lty=1,lwd=2,xlim=c(-5,7),ylab="Density",xlab=bquote(theta),main="a")
mtext("p = 0.25",,.25)
curve(dnorm(x,1,2),col=8,lty=2,lwd=2,add=TRUE)
curve(p*dnorm(x,-2,1)+(1-p)*dnorm(x,1,2),col=1,lwd=2,add=TRUE)
p=.5
curve(dnorm(x,-2,1),col=8,lty=1,lwd=2,xlim=c(-5,7),ylab="Density",xlab=bquote(theta),main="b")
mtext("p = 0.5",,.25)
curve(dnorm(x,1,2),col=8,lty=2,lwd=2,add=TRUE)
curve(p*dnorm(x,-2,1)+(1-p)*dnorm(x,1,2),col=1,lwd=2,add=TRUE)
p=.9
curve(dnorm(x,-2,1),col=8,lty=1,lwd=2,xlim=c(-5,7),ylab="Density",xlab=bquote(theta),main="c")
mtext("p = 0.9",,.25)
curve(dnorm(x,1,2),col=8,lty=2,lwd=2,add=TRUE)
curve(p*dnorm(x,-2,1)+(1-p)*dnorm(x,1,2),col=1,lwd=2,add=TRUE)
dev.off()

##### 
#####  Code Box 10.3
##### 
#####  Finch Data 
##### 
#####  https://nabt.org/files/galleries/ABT_Online_May_2014.pdf 
##### 
#####  Using David Lack's Observations of Finch Beak Size to Teach Natural
#####  Selection & the Nature of Science
##### 
#####  G.fortis from Daphne and James Island beak depths in mm
##### 

y=c(12.3,12.8,13.5,13.6,13.7,13.9,13.9,13.9,14.3,14.4,14.5,14.7,14.7,15.5,15.8,15.8,15.8,16.7,16.7,17.1,17.4,18.0,18.3,18.7)
n=length(y)
hist(y,breaks=20,col=8,prob=TRUE)

source("mixnorm.mcmc.R") # Code Box 10.2
n.mcmc=20000
set.seed(1)
mcmc.out=mixnorm.mcmc(y=y,n.mcmc=n.mcmc)

layout(matrix(1:3,3,1))
matplot(mcmc.out$mu.mat,type="l",col=c(1,8),lty=1,xlab="Iteration",ylab=bquote(mu))
matplot(mcmc.out$s.mat,type="l",col=c(1,8),lty=1,xlab="Iteration",ylab="s")
plot(mcmc.out$p.vec,type="l",xlab="Iteration",ylab="p")

n.burn=mcmc.out$n.mcmc
mu.mn=apply(mcmc.out$mu.mat[n.burn:n.mcmc,],2,mean)
s.mn=apply(mcmc.out$s.mat[n.burn:n.mcmc,],2,mean)
p.mn=mean(mcmc.out$p.vec[n.burn:n.mcmc])

pdf(file="mixnorm_post.pdf",width=8,height=8)
layout(matrix(1:2,2,1))
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
hist(y,breaks=20,border=0,prob=TRUE,main="a",xlab="y (mm)",ylim=c(0,.8))
lines(density(mcmc.out$mu.mat[n.burn:n.mcmc,1],from=10,to=20,adjust=5),col=8,lty=1,lwd=2)
lines(density(mcmc.out$mu.mat[n.burn:n.mcmc,2],from=10,to=20,adjust=5),col=8,lty=2,lwd=2)
rug(y,lwd=3)
curve(p.mn*dnorm(x,mu.mn[1],s.mn[1])+(1-p.mn)*dnorm(x,mu.mn[2],s.mn[2]),col=1,lwd=2,from=10,to=20,add=TRUE)
plot(y,mcmc.out$z.mean,type="o",lwd=2,ylim=c(0,1),xlim=c(12,19),ylab="E(z|y)",xlab="y (mm)",main="b")
dev.off()



