###
###  Chapter 17 Script
###

###
###  Code Box 17.2
###
###  Read in SNOTEL Temperature Data (20171014)
###

temp.df=read.csv("20171014_Temp.csv")

y=temp.df$Temp
n=length(y)

locs=as.matrix(temp.df[,2:1])
n.lat=75
n.lon=round(n.lat*diff(range(locs[,1]))/diff(range(locs[,2])))
n.pred=n.lat*n.lon
lon.vals=seq(min(locs[,1]),max(locs[,1]),,n.lon)
lat.vals=seq(min(locs[,2]),max(locs[,2]),,n.lat)
locs.pred=as.matrix(expand.grid(lon.vals,lat.vals))
locs.full=rbind(locs,locs.pred)
locs.full.sc=locs.full
locs.full.sc=scale(locs.full)

X.full=cbind(rep(1,n.pred+n),locs.full.sc,locs.full.sc[,1]^2)
X=X.full[1:n,]
X.pred=X.full[-(1:n),]
p=dim(X)[2]

library(maps)
data(us.cities)
CO.cities=us.cities[c(322,247,360,728,192),]
CO.cities$name=c("Fort Collins","Denver","Grand Junction","Pueblo","Colorado Springs")

pdf(file="geostat_data.pdf",width=8,height=7)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
map("state","Colorado",xlim=c(-110,-101),ylim=c(36.5,41.5))
points(locs,pch=20,cex=3*(.25+(y-min(y))/diff(range(y))),col=rgb(0,0,0,.4))
map("state",add=TRUE)
map.axes()
map.cities(CO.cities, country="CO",pch=17,cex=1.5,label=TRUE)
map.cities(CO.cities, country="CO",pch=17,cex=1.5,label=TRUE,capitals=2)
dev.off()

###
###  Code Box 17.3
###
###  Fit Geostat Model to SNOTEL Data 
###

source("norm.geostat.mcmc.R") # Code Box 17.1
n.mcmc=10000
set.seed(1)
mcmc.out=norm.geostat.mcmc(y=y,X=X,locs=locs,beta.mn=rep(0,p),beta.var=1000,n.mcmc=n.mcmc)

layout(matrix(1:3,3,1))
matplot(t(mcmc.out$beta.save),type="l",lty=1)
plot(mcmc.out$s2.save,type="l")
plot(mcmc.out$phi.save,type="l")

dIG <- function(x,r,q){
  x^(-(q+1))*exp(-1/r/x)/(r^q)/gamma(q)
}

pdf(file="geostat_post.pdf",width=7,height=10)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:6,3,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,],prob=TRUE,col=8,breaks=40,xlab=bquote(beta[0]),main="a")
curve(dnorm(x,0,sqrt(1000)),lwd=1.5,add=TRUE)
hist(mcmc.out$beta.save[2,],prob=TRUE,col=8,breaks=40,xlab=bquote(beta[1]),main="b")
curve(dnorm(x,0,sqrt(1000)),lwd=1.5,add=TRUE)
hist(mcmc.out$beta.save[3,],prob=TRUE,col=8,breaks=40,xlab=bquote(beta[2]),main="c")
curve(dnorm(x,0,sqrt(1000)),lwd=1.5,add=TRUE)
hist(mcmc.out$beta.save[4,],prob=TRUE,col=8,breaks=40,xlab=bquote(beta[3]),main="d")
curve(dnorm(x,0,sqrt(1000)),lwd=1.5,add=TRUE)
hist(mcmc.out$s2.save,prob=TRUE,col=8,breaks=40,xlab=bquote(sigma^2),main="e")
curve(dIG(x,mcmc.out$r,mcmc.out$q),add=TRUE,lwd=1.5)
hist(mcmc.out$phi.save,prob=TRUE,col=8,breaks=40,xlab=bquote(phi),main="f")
curve(dgamma(x,mcmc.out$gamma.1,mcmc.out$gamma.2),from=0.001,add=TRUE,lwd=1.5)
dev.off()

###
###  Code Box 17.4
###
###  Bayesian Kriging for SNOTEL Data 
###

library(mvtnorm)
library(fields)
library(maps)

n.mcmc=100
D=rdist.earth(locs,locs)
D.full=rdist.earth(locs.full,locs.full)
D.pred=rdist.earth(locs.pred,locs.pred)
D.uo=D.full[-(1:n),1:n]
n.pred=n.lat*n.lon
y.pred.save=matrix(0,n.pred,n.mcmc)
set.seed(1)
for(k in 1:n.mcmc){
  if((k%%2)==0) cat(k," ")
  s2.tmp=mcmc.out$s2.save[k]
  phi.tmp=mcmc.out$phi.save[k]  
  beta.tmp=mcmc.out$beta.save[,k]
  Sig.inv.tmp=solve(s2.tmp*exp(-D/phi.tmp))
  tmp.mn=X.pred%*%beta.tmp+s2.tmp*exp(-D.uo/phi.tmp)%*%Sig.inv.tmp%*%(y-X%*%beta.tmp)
  tmp.var=s2.tmp*exp(-D.pred/phi.tmp)-s2.tmp*exp(-D.uo/phi.tmp)%*%solve(s2.tmp*exp(-D/phi.tmp))%*%t(s2.tmp*exp(-D.uo/phi.tmp))
  y.pred.save[,k]=as.vector(rmvnorm(1,tmp.mn,tmp.var,method="chol"))
};cat("\n")

y.pred.mn=apply(y.pred.save,1,mean)
y.pred.sd=apply(y.pred.save,1,sd)

gray.colors.rev <- function (n, start = .2, end = 1, gamma = 1){ 
  gray(seq.int(to= start^gamma, from = end^gamma, length.out = n)^(1/gamma))
}

data(us.cities)
CO.cities=us.cities[c(322,247,360,728,192),]
CO.cities$name=c("Fort Collins","Denver","Grand Junction","Pueblo","Colorado Springs")

pdf(file="geostat_pred.pdf",width=6,height=12)
par(cex.lab=1.25,cex.main=1.5,mar=c(2,5,2,2))
layout(matrix(1:2,2,1))
map("state","Colorado",xlim=c(-110,-101),ylim=c(36.5,41.5))
title("a")
image(matrix(y.pred.mn,n.lon,n.lat),y=lat.vals,x=lon.vals,col=gray.colors.rev(100),asp=TRUE,add=TRUE)
points(locs,pch=20,cex=.5)
map("state",add=TRUE)
map.axes()
map.cities(CO.cities, country="CO",pch=17,cex=1.5,label=TRUE)
map.cities(CO.cities, country="CO",pch=17,cex=1.5,label=TRUE,capitals=2)
map("state","Colorado",xlim=c(-110,-101),ylim=c(36.5,41.5))
title("b")
image(matrix(y.pred.sd,n.lon,n.lat),y=lat.vals,x=lon.vals,col=gray.colors.rev(100),asp=TRUE,add=TRUE)
points(locs,pch=20,cex=.5)
map("state",add=TRUE)
map.axes()
map.cities(CO.cities, country="CO",pch=17,cex=1.5,label=TRUE)
map.cities(CO.cities, country="CO",pch=17,cex=1.5,label=TRUE,capitals=2)
dev.off()

###
###  Code Box 17.6 
###
###  Read in Aerial Data and Fit CAR Model 
###

library(maps)
library(rgeos)
library(rgdal)

co=readOGR("Colorado/","COUNTIES")
co.cents=gCentroid(co,byid=TRUE)
counties=as.character(co$COUNTY)
locs=co.cents@coords
n=dim(locs)[1]

birds.df=read.csv("co_birds.csv")
tmp=birds.df
for(i in 1:n){
  tmp.idx=(1:n)[birds.df$county==counties[i]]
  tmp[i,]=birds.df[tmp.idx,]
}
birds.df=tmp

D=as.matrix(dist(locs))

y=log(birds.df$richness)
x1=log(birds.df$minelev)
x2=log(birds.df$pop)
x3=birds.df$total
X=cbind(rep(1,n),scale(cbind(x1,x2,x3)))
p=dim(X)[2]

y.cols=gray(1-(y-min(y))/diff(range(y)))
x1.cols=gray(1-(x1-min(x1))/diff(range(x1)))
x2.cols=gray(1-(x2-min(x2))/diff(range(x2)))
x3.cols=gray(1-(x3-min(x3))/diff(range(x3)))

pdf(file="car_data.pdf",width=12,height=8)
layout(matrix(c(1,1,1,1,1,1,1,1,1,2,3,4),3,4))
plot(co,col=y.cols,border=gray(.5),axes=FALSE,main="a",cex.main=1.5)
plot(co,col=x1.cols,border=gray(.5),axes=FALSE,main="b",cex.main=1.5)
plot(co,col=x2.cols,border=gray(.5),axes=FALSE,main="c",cex.main=1.5)
plot(co,col=x3.cols,border=gray(.5),axes=FALSE,main="d",cex.main=1.5)
dev.off()

thresh=.15*max(D)
W=ifelse(D>thresh,0,1)
diag(W)=0

source("norm.car.mcmc.R")  # Code Box 17.5
n.mcmc=10000
set.seed(1)
mcmc.out=norm.car.mcmc(y=y,X=X,W=W,beta.mn=rep(0,p),beta.var=1000,n.mcmc=n.mcmc)

layout(matrix(1:3,3,1))
matplot(t(mcmc.out$beta.save),type="l",lty=1)
plot(mcmc.out$s2.save,type="l")
plot(mcmc.out$rho.save,type="l")

dIG <- function(x,r,q){
  x^(-(q+1))*exp(-1/r/x)/(r^q)/gamma(q)
}

pdf(file="car_post.pdf",width=7,height=10)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:6,3,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,],prob=TRUE,col=8,breaks=40,xlab=bquote(beta[0]),main="a")
curve(dnorm(x,0,sqrt(1000)),lwd=1.5,add=TRUE)
hist(mcmc.out$beta.save[2,],prob=TRUE,col=8,breaks=40,xlab=bquote(beta[1]),main="b")
curve(dnorm(x,0,sqrt(1000)),lwd=1.5,add=TRUE)
hist(mcmc.out$beta.save[3,],prob=TRUE,col=8,breaks=40,xlab=bquote(beta[2]),main="c")
curve(dnorm(x,0,sqrt(1000)),lwd=1.5,add=TRUE)
hist(mcmc.out$beta.save[4,],prob=TRUE,col=8,breaks=40,xlab=bquote(beta[3]),main="d")
curve(dnorm(x,0,sqrt(1000)),lwd=1.5,add=TRUE)
hist(mcmc.out$s2.save,prob=TRUE,col=8,breaks=40,xlab=bquote(sigma^2),main="e")
curve(dIG(x,mcmc.out$r,mcmc.out$q),add=TRUE,lwd=1.5)
hist(mcmc.out$rho.save,prob=TRUE,col=8,breaks=40,xlab=bquote(rho),main="f")
curve(dbeta(x,mcmc.out$alpha.1,mcmc.out$alpha.2),add=TRUE,lwd=1.5)
dev.off()




