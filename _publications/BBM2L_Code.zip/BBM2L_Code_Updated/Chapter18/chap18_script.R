###
###  Chapter 18 R Code
###

###
###  Code Box 18.2
###
###  Read in Deer Data and Fit Quantile Regression to Deer Data for Set of Quantiles
###

load("deer.RData")
n=dim(deer.df)[1]
y=deer.df$y
X=cbind(rep(1,n),as.matrix(deer.df[,4:5]))
n=dim(X)[1]
p=dim(X)[2]

tau.vec=c(.1,.25,.5,.75,.9)
n.tau=length(tau.vec)
out.list=vector("list",n.tau)
DIC.vec=rep(0,n.tau)
beta.mat=matrix(0,p,n.tau)
s.vec=rep(0,n.tau)
source("reg.qr.mcmc.R")  #  Code Box 18.1
n.mcmc=50000
set.seed(1)
for(j in 1:n.tau){
  out.list[[j]]=reg.qr.mcmc(y=y,X=X,tau=tau.vec[j],beta.mn=rep(0,p),beta.var=1000,s.u=100,n.mcmc=n.mcmc)
  n.burn=out.list[[j]]$n.burn
  DIC.vec[j]=out.list[[j]]$DIC
  beta.mat[,j]=apply(out.list[[j]]$beta.save[,n.burn:n.mcmc],1,mean)
  s.vec[j]=mean(sqrt(out.list[[j]]$s2.save[n.burn:n.mcmc]))
}
cbind(tau.vec,DIC.vec,t(beta.mat),s.vec)

###
###  Code Box 18.3
###
###  Plot Estimated Quantile Functions
###

n.pred=100
X.pred=matrix(1,n.pred,p)
X.pred[,2]=seq(min(X[,2]),max(X[,2]),,n.pred)
X.pred[,3]=X.pred[,2]^2

pdf(file="qr_fit.pdf",width=8,height=6)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
plot(X[,2],y,xlab="age",ylab="body mass (kg)")
for(j in 1:n.tau){
  n.burn=out.list[[j]]$n.burn
  y.q=apply(X.pred%*%out.list[[j]]$beta.save[,n.burn:n.mcmc],1,mean) 
  lines(X.pred[,2],y.q,type="l")
}
dev.off()

###
###  Code Box 18.5
###
###  Estimate Quantile 
###

source("reg.qr.tau.mcmc.R") # Code Box 18.4
n.mcmc=50000
set.seed(1)
mcmc.out=reg.qr.tau.mcmc(y=y,X=X,beta.mn=rep(0,p),beta.var=1000,u=100,n.mcmc=n.mcmc)
keep.idx=mcmc.out$n.burn:n.mcmc

pdf(file="qr_tau_post.pdf",width=8,height=8)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$beta.save[2,keep.idx],prob=TRUE,col=8,breaks=40,main="a",xlab=bquote(beta[1]))
curve(dnorm(x,0,sqrt(10000)),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,keep.idx],prob=TRUE,col=8,breaks=40,main="b",xlab=bquote(beta[2]))
curve(dnorm(x,0,sqrt(10000)),lwd=2,add=TRUE)
hist(sqrt(mcmc.out$s2.save[keep.idx]),prob=TRUE,col=8,breaks=40,main="c",xlab=bquote(sigma))
abline(h=1/100,lwd=2)
hist(mcmc.out$tau.save[keep.idx],prob=TRUE,col=8,breaks=10,xlim=c(0,1),main="d",xlab=bquote(tau))
abline(h=1,lwd=2)
abline(v=0.25,lwd=2,lty=2)
dev.off()


