reg.qr.mcmc <- function(y,X,tau,beta.mn,beta.var,s.u,n.mcmc){

###
### Code Box 18.1 
###

###
### Subroutines 
###

ldasymlap <- function(y,tau,mu,sig){
  rho <- function(z,tau){z*(tau-(z<0))}
  ld=log(tau)+log(1-tau)-log(sig)-rho((y-mu)/sig,tau)
  ld
}

###
### Setup Variables 
###

n=dim(X)[1]
p=dim(X)[2]
n.burn=round(.1*n.mcmc)

beta.save=matrix(0,p,n.mcmc)
s2.save=rep(0,n.mcmc)
D.bar=0

###
### Starting Values and Priors
###

beta=solve(t(X)%*%X)%*%t(X)%*%y
XpX=t(X)%*%X

s.tune=.1
beta.tune=.1

s2=mean((y-X%*%beta)^2)
sig=sqrt(s2)

###
### MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ### Sample s2
  ###

  s.star=rnorm(1,sig,s.tune)
  if((s.star < s.u) & (s.star > 0)){
    mh.1=sum(ldasymlap(y,tau,X%*%beta,s.star))
    mh.2=sum(ldasymlap(y,tau,X%*%beta,sig))
    mh=exp(mh.1-mh.2)
 
    if(mh > runif(1)){
      sig=s.star
    }
  }

  ###
  ### Sample beta
  ###

  beta.star=rnorm(p,beta,beta.tune)
  mh.1=sum(ldasymlap(y,tau,X%*%beta.star,sig))+sum(dnorm(beta.star,beta.mn,sqrt(beta.var),log=TRUE))
  mh.2=sum(ldasymlap(y,tau,X%*%beta,sig))+sum(dnorm(beta,beta.mn,sqrt(beta.var),log=TRUE))
  mh=exp(mh.1-mh.2)
  
  if(mh > runif(1)){
    beta=beta.star
  } 

  ###
  ### Posterior Predictive Calculations 
  ###
  
  if(k > n.burn){
    D.bar=D.bar-2*sum(ldasymlap(y,tau,X%*%beta,sig))/(n.mcmc-n.burn)
  }

  ###
  ### Save Samples
  ###
  
  beta.save[,k]=beta
  s2.save[k]=sig^2

}
cat("\n")

###
###  DIC Calculations 
###

beta.mean=as.vector(apply(beta.save[,n.burn:n.mcmc],1,mean))
sig.mean=mean(sqrt(s2.save[n.burn:n.mcmc]))
D.hat=-2*sum(ldasymlap(y,tau,X%*%beta.mean,sig.mean))
pD=D.bar-D.hat
DIC=D.hat+2*pD

###
###  Write Output
###

list(beta.save=beta.save,s2.save=s2.save,y=y,X=X,n.mcmc=n.mcmc,n.burn=n.burn,n=n,p=p,tau=tau,D.bar=D.bar,D.hat=D.hat,pD=pD,DIC=DIC)

}
