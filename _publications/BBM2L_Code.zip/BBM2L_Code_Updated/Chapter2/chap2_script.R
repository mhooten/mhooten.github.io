###
###  Quadrature
###

###
###  Code Box: 2.1
###
###  Expectation of a 
###

m=100
a=seq(0,1,,m)
Delta.a=a[2]-a[1]
Delta.a*sum(a*dunif(a,0,1))

m=1000
a=seq(0,1,,m)
Delta.a=a[2]-a[1]
Delta.a*sum(a*dunif(a,0,1))

m=10000
a=seq(0,1,,m)
Delta.a=a[2]-a[1]
Delta.a*sum(a*dunif(a,0,1))

###
###  Code Box: 2.2
###
###  Marginal of b 
###

m=100
a=seq(0,1,,m)
b=0
Delta.a=a[2]-a[1]
Delta.a*sum(dbinom(b,1,a))

m=1000
a=seq(0,1,,m)
b=0
Delta.a=a[2]-a[1]
Delta.a*sum(dbinom(b,1,a))

m=10000
a=seq(0,1,,m)
b=0
Delta.a=a[2]-a[1]
Delta.a*sum(dbinom(b,1,a))


