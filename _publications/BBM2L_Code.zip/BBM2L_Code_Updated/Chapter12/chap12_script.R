###
###  Chapter 12 R Code
###

###
###  Deer Analysis from Chapter 11
###

load("deer.RData")
n=dim(deer.df)[1]
y=deer.df$y
X=cbind(rep(1,n),as.matrix(deer.df[,-1]))
X[,2]=ifelse(X[,2]==599,0,1)
p=dim(X)[2]

source("norm.reg.mcmc.R")
set.seed(1)
mcmc.out=norm.reg.mcmc(y=y,X=X,beta.mn=rep(0,p),beta.var=10000,s2.mn=50,s2.sd=1000,n.mcmc=10000)

###
###  Code Box 12.1
###
###  Obtain Predictions for Age 6
###

x.m=c(1,1,0,6,6^2)
y.m.pred=rep(0,mcmc.out$n.mcmc)
set.seed(1)
for(k in 1:mcmc.out$n.mcmc){
  y.m.pred[k]=rnorm(1,x.m%*%mcmc.out$beta.save[,k],sqrt(mcmc.out$s2.save[k])) 
}
mean(y.m.pred) # mean mass for age six female deer at average cropland
quantile(y.m.pred,c(0.025,0.975)) # 95% CI for age six female deer in large cropland

###
###  Code Box 12.2
###
###  Obtain Range of Predictions
###

n.pred=100
x.mean=apply(X,2,mean)
X.pred=matrix(0,n.pred,p)
X.pred[,1]=1
X.pred[,2]=1
X.pred[,4]=seq(min(X[,4]),max(X[,4]),,n.pred)
X.pred[,5]=X.pred[,4]^2
Y.pred=matrix(0,n.pred,mcmc.out$n.mcmc)
set.seed(1)
for(k in 1:mcmc.out$n.mcmc){
  Y.pred[,k]=rnorm(n.pred,X.pred%*%mcmc.out$beta.save[,k],sqrt(mcmc.out$s2.save[k])) 
}
y.pred.mean=apply(Y.pred,1,mean)
y.pred.l=apply(Y.pred,1,quantile,0.025)
y.pred.u=apply(Y.pred,1,quantile,0.975)

###
###  Make PPD Plot 
###

pdf(file="normreg_ppd.pdf",width=8,height=6)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
plot(X[,4],y,xlab="age",ylab=bquote(tilde(y)))
polygon(c(X.pred[,4],rev(X.pred[,4])),c(y.pred.u,rev(y.pred.l)),border=NA,col=rgb(0,0,0,.25))
lines(X.pred[,4],y.pred.mean,lwd=2)
points(X[,4],y,lwd=1.25)
dev.off()


