###
###  Chapter 20 R Script
###

###
###  Code Box 20.2 
###
###  Read in desglut data and fit logistic regression model
###

load("desglut.RData")
y=desglut.df$present
n=length(y)
X=as.matrix(cbind(rep(1,n),desglut.df[,2:4]))
p=dim(X)[2]

summary(glm(y~0+X,family=binomial(link="logit")))

source("logit.reg.mcmc.R")  # Code Box 20.1
n.mcmc=100000
set.seed(1)
mcmc.out=logit.reg.mcmc(y=y,X=X,beta.mn=rep(0,p),beta.var=2.25,beta.tune=.1,n.mcmc=n.mcmc)

#matplot(t(mcmc.out$beta.save),type="l",lty=1)

pdf(file="logitreg_post.pdf",width=8,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,],prob=TRUE,col=8,breaks=40,main="a",xlab=bquote(beta[0]))
curve(dnorm(x,0,2.25),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,],prob=TRUE,col=8,breaks=40,main="b",xlab=bquote(beta[1]))
curve(dnorm(x,0,2.25),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,],prob=TRUE,col=8,breaks=40,main="c",xlab=bquote(beta[2]))
curve(dnorm(x,0,2.25),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[4,],prob=TRUE,col=8,breaks=40,main="d",xlab=bquote(beta[3]))
curve(dnorm(x,0,2.25),lwd=2,add=TRUE)
dev.off()

###
###  Code Box 20.4
###
###  Fit Probit Regression Model 
###

source("probit.reg.mcmc.R") # Code Box 20.3
set.seed(1)
mcmc.out=probit.reg.mcmc(y=y,X=X,beta.mn=rep(0,p),beta.var=1,n.mcmc=n.mcmc)

#matplot(t(mcmc.out$beta.save),type="l",lty=1)

pdf(file="probitreg_post.pdf",width=8,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,],prob=TRUE,col=8,breaks=40,main="a",xlab=bquote(beta[0]))
curve(dnorm(x,0,1),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,],prob=TRUE,col=8,breaks=40,main="b",xlab=bquote(beta[1]))
curve(dnorm(x,0,1),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,],prob=TRUE,col=8,breaks=40,main="c",xlab=bquote(beta[2]))
curve(dnorm(x,0,1),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[4,],prob=TRUE,col=8,breaks=40,main="d",xlab=bquote(beta[3]))
curve(dnorm(x,0,1),lwd=2,add=TRUE)
dev.off()

###
###  Code Box 20.5
###

mean(pnorm(apply(X,2,mean)%*%mcmc.out$beta.save))

###
###  Code Box 20.7
###
###  Fit Binary ALD Regression Model (w/ different quantiles) 
###

tau.vec=c(.1,.25,.5,.75,.9)
n.tau=length(tau.vec)
out.list=vector("list",n.tau)
DIC.vec=rep(0,n.tau)
beta.mat=matrix(0,p,n.tau)
s.vec=rep(0,n.tau)
source("binary.qr.mcmc.R") # Code Box 20.6
n.mcmc=50000
set.seed(1)
for(j in 1:n.tau){
  out.list[[j]]=binary.qr.mcmc(y=y,X=X,tau=tau.vec[j],beta.mn=rep(0,p),beta.var=1000,beta.tune=1,n.mcmc=n.mcmc)
  DIC.vec[j]=out.list[[j]]$DIC
  beta.mat[,j]=apply(out.list[[j]]$beta.save,1,mean)
}
cbind(tau.vec,DIC.vec,t(beta.mat))
#matplot(t(out.list[[j]]$beta.save),type="l",lty=1)


