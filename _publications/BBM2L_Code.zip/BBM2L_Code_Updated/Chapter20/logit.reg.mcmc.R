logit.reg.mcmc <- function(y,X,beta.mn,beta.var,beta.tune,n.mcmc){

###
###  Code Box 20.1
###

###
###  Libraries and Subroutines 
###

logit <- function(p){
  log(p/(1-p))
}

logit.inv <- function(z){
  exp(z)/(1+exp(z))
}

###
###  Preliminary Variables
###

n.burn=round(n.mcmc/10)
n=length(y)
p=dim(X)[2]

beta.save=matrix(0,p,n.mcmc)
Davg=0

###
###  Starting Values
###

Sig.beta.inv=solve(beta.var*diag(p))
beta=beta.mn
pp=logit.inv(X%*%beta)

###
###  MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ### Sample beta
  ###

  beta.star=rnorm(p,beta,beta.tune)
  pp.star=logit.inv(X%*%beta.star)
  mh1=sum(dbinom(y,1,pp.star,log=TRUE))-0.5*t(beta.star-beta.mn)%*%Sig.beta.inv%*%(beta.star-beta.mn)
  mh2=sum(dbinom(y,1,pp,log=TRUE))-0.5*t(beta-beta.mn)%*%Sig.beta.inv%*%(beta-beta.mn)
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    beta=beta.star
    pp=pp.star
  }

  ###
  ### DIC Calculations 
  ###
  
  if(k>n.burn){
    Davg=Davg-2*(sum(dbinom(y,1,pp,log=TRUE)))/(n.mcmc-n.burn)
  }

  ###
  ### Save Samples 
  ###

  beta.save[,k]=beta

}
cat("\n")

###k
###  Calculate DIC 
###

postbeta.mn=apply(beta.save[,-(1:n.burn)],1,mean)
Dhat=-2*(sum(dbinom(y,1,logit.inv(X%*%postbeta.mn),log=TRUE)))
pD=Davg-Dhat
DIC=2*Davg-Dhat

cat("Dhat:",Dhat,"Davg:",Davg,"pD:",pD,"DIC:",DIC,"\n")
 
###
###  Write output 
###

list(y=y,X=X,n.mcmc=n.mcmc,beta.save=beta.save,DIC=DIC)

}
