ds.mcmc <- function(y,x,d,u.x,u.s,n.mcmc){

####
#### Code Box 24.3
####

####
#### Setup Variables 
#### 

M=length(y)

s.save=rep(0,n.mcmc)
psi.save=rep(0,n.mcmc)
N.save=rep(sum(y),n.mcmc)
D.save=rep(0,n.mcmc)
z.mean=rep(0,M)

n.burn=round(.2*n.mcmc)

####
#### Priors, Starting Values, and Tuning Parameters
#### 

alpha=1
beta=1

z=y

n.0=sum(y==0)
x[y==0]=runif(n.0,0,u.x)
s=mean(x[y==1])/2
psi=(M-n.0)/M

p=exp(-(x^2)/(s^2))

s.tune=.1*u.s
x.tune=.1*u.x

####
#### Begin MCMC Loop 
#### 
  
for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ####
  ####  Sample z 
  #### 

  psi.tmp=psi*(1-p)/(psi*(1-p)+1-psi) 
  z[y==0]=rbinom(n.0,1,psi.tmp[y==0])

  ####
  ####  Sample psi 
  #### 

  psi=rbeta(1,sum(z)+alpha,sum(1-z)+beta)

  ####
  ####  Sample s 
  #### 

  s.star=rnorm(1,s,s.tune)
  if((s.star > 0) & (s.star < u.s)){
    p.star=exp(-(x^2)/(s.star^2))
    mh1=sum(dbinom(y[z==1],1,p.star[z==1],log=TRUE))
    mh2=sum(dbinom(y[z==1],1,p[z==1],log=TRUE))
    mh=exp(mh1-mh2)
    if(mh > runif(1)){
      s=s.star
      p=p.star
    }
  }

  ####
  ####  Sample x
  #### 

  x.star=rnorm(n.0,x[y==0],x.tune)
  tmp.idx=((x.star > 0) & (x.star < u.x))
  p.star=p
  p.star[y==0][tmp.idx]=exp(-(x.star[tmp.idx]^2)/(s^2)) 
  mh1=z*log(1-p.star)
  mh2=z*log(1-p)
  keep.idx=(exp(mh1-mh2)>runif(M))
  comb.idx=(tmp.idx & keep.idx[y==0])
  x[y==0][comb.idx]=x.star[comb.idx]  
  p[y==0][comb.idx]=p.star[y==0][comb.idx]  

  ####
  ####  Save Samples 
  #### 

  s.save[k]=s
  psi.save[k]=psi
  N.save[k]=sum(z)
  D.save[k]=sum(z)/(d*2*u.x)
  if(k > n.burn){
    z.mean=z.mean+z/(n.mcmc-n.burn)
  }

}
cat("\n")

####
#### Write Output 
#### 

list(s.save=s.save,z.mean=z.mean,psi.save=psi.save,N.save=N.save,D.save=D.save)

}
