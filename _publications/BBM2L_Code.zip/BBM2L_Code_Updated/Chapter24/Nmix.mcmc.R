Nmix.mcmc <- function(Y,X,n.mcmc){

###
###  Code Box 24.8
###

###
### Setup Variables
###

n=dim(Y)[1]
J=dim(Y)[2]
pp=dim(X)[2]

p.save=rep(0,n.mcmc)
beta.save=matrix(0,pp,n.mcmc)
N.save=matrix(0,n,n.mcmc)

###
### Priors and Starting Values 
###

beta.mn=rep(0,pp)
beta.sd=sqrt(1000)
alpha.p=1
beta.p=1

p=.9
N=round((apply(Y,1,max)+1)/p)
beta=solve(t(X)%*%X)%*%t(X)%*%log(N)
lam=exp(X%*%beta)
beta.tune=.05
sum.1=sum(Y)+alpha.p
const=1
y.max=apply(Y,1,max)

###
### Begin MCMC Loop 
###

for(k in 1:n.mcmc){
  if((k%%1000)==0) cat(k," ")

  ###
  ### Sample N 
  ###

  N.star=rpois(n,N+const)
  mh.1=apply(dbinom(Y,N.star,p,log=TRUE),1,sum)+dpois(N.star,lam,log=TRUE)+dpois(N,N.star+const,log=TRUE)
  mh.2=apply(dbinom(Y,N,p,log=TRUE),1,sum)+dpois(N,lam,log=TRUE)+dpois(N.star,N+const,log=TRUE)
  mh=exp(mh.1-mh.2)
  keep.idx=((mh>runif(n)) & (N.star>=y.max))
  N[keep.idx]=N.star[keep.idx]

  ###
  ### Sample beta 
  ###

  beta.star=rnorm(pp,beta,beta.tune)
  lam.star=exp(X%*%beta.star)
  mh1=sum(dpois(N,lam.star,log=TRUE))+sum(dnorm(beta.star,beta.mn,beta.sd,log=TRUE))
  mh2=sum(dpois(N,lam,log=TRUE))+sum(dnorm(beta,beta.mn,beta.sd,log=TRUE))
  mh=exp(mh1-mh2)

  if(mh > runif(1)){
    beta=beta.star   
    lam=lam.star   
  }

  ###
  ### Sample p 
  ###

  sum.2=sum(matrix(N,n,J)-Y)+beta.p
  p=rbeta(1,sum.1,sum.2)

  ###
  ### Save Samples
  ###
 
  p.save[k]=p
  N.save[,k]=N
  beta.save[,k]=beta

};cat("\n")

###
### Write Output 
###

list(beta.save=beta.save,N.save=N.save,p.save=p.save)

}
