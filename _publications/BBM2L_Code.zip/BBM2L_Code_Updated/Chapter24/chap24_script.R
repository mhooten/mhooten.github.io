###
###  Chapter 24 R Script
###

###
###  Code Box 24.2
###
###  Read in C-R Data and Fit C-R model
###

sal.df=read.table("sal_data.txt",header=TRUE)
y.0=apply(sal.df[sal.df$spp==0,1:4],1,sum) # P. jordani
y.1=apply(sal.df[sal.df$spp==1,1:4],1,sum) # D. wrighti

J=4
M=1500
n.0=length(y.0)
n.1=length(y.1)
y.0.aug=c(y.0,rep(0,M-n.0))
y.1.aug=c(y.1,rep(0,M-n.1))

source("cr.scale.mcmc.R")  #  Code Box 24.1
n.mcmc=50000
set.seed(1)
mcmc.0.out=cr.scale.mcmc(y=y.0.aug,J=rep(J,M),n.mcmc=n.mcmc)
mcmc.1.out=cr.scale.mcmc(y=y.1.aug,J=rep(J,M),n.mcmc=n.mcmc)

pdf(file="cr_post.pdf",width=10,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.0.out$p.save,prob=TRUE,col=8,breaks=20,xlim=c(0,1),xlab="p",main="a")
text(.5,10,labels="P. jordani",pos=4)
hist(mcmc.0.out$N.save,prob=TRUE,breaks=seq(0,1500,1),xlim=c(0,M),border=gray(.5),ylab="Probability",xlab="N",main="b")
text(800,.15,labels="P. jordani",pos=4)
hist(mcmc.1.out$p.save,prob=TRUE,col=8,breaks=20,xlim=c(0,1),xlab="p",main="c")
text(.5,13,labels="D. wrighti",pos=4)
hist(mcmc.1.out$N.save,prob=TRUE,breaks=seq(0,1500,1),xlim=c(0,M),border=gray(.5),ylab="Probability",xlab="N",main="d")
text(750,.07,labels="D. wrighti",pos=4)
dev.off()

mean(mcmc.0.out$N.save)
quantile(mcmc.0.out$N.save,c(0.025,0.975))
mean(mcmc.1.out$N.save)
quantile(mcmc.1.out$N.save,c(0.025,0.975))

mean(mcmc.0.out$N.save<mcmc.1.out$N.save)

###
###  Code Box 24.4
###
###  Read in Hemingway Impala Data and Fit Distance Sampling Model
###

x=c(71.933980, 26.047227, 58.474341, 92.349221, 163.830409, 84.523652
  ,163.830409, 157.330098, 22.267696, 72.105330, 86.986979, 50.795047
  ,0.000000, 73.135370,  0.000000, 128.557522, 163.830409,  71.845104
  ,30.467336, 71.073909, 150.960702, 68.829172, 90.000000, 64.983827
  ,165.690874, 38.008322, 378.207430, 78.146226, 42.127052, 0.000000
  ,400.000000, 175.386612, 30.467336, 35.069692, 86.036465, 31.686029
  ,200.000000, 271.892336, 26.047227, 76.604444, 41.042417, 200.000000
  ,86.036465, 0.000000, 93.969262, 55.127471, 10.458689, 84.523652
  ,0.000000, 77.645714, 0.000000, 96.418141, 0.000000, 64.278761
  ,187.938524, 0.000000, 160.696902, 150.453756, 63.603607, 193.185165
  ,106.066017, 114.906666, 143.394109, 128.557522, 245.745613, 123.127252
  ,123.127252, 153.208889, 143.394109, 34.202014, 96.418141, 259.807621
  ,8.715574)

n=length(x)

d=60000
u.x=400
u.s=400
M=1000
imp.aug.df=data.frame(y=rep(0,M),x=rep(0,M))
imp.aug.df[1:n,1]=1
imp.aug.df[1:n,2]=x

source("ds.mcmc.R") # Code Box 24.3
n.mcmc=50000
set.seed(1)
mcmc.out=ds.mcmc(y=imp.aug.df$y,x=imp.aug.df$x,d=d,u.x=u.x,u.s=u.s,n.mcmc=n.mcmc)

#layout(matrix(1:3,3,1))
#plot(mcmc.out$s.save,type="l")
#plot(mcmc.out$psi.save,type="l")
#plot(mcmc.out$N.save,type="l")

pdf(file="ds_post.pdf",width=10,height=5)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:2,1,2,byrow=TRUE))
hist(mcmc.out$s.save,prob=TRUE,col=8,breaks=40,xlab=bquote(sigma),main="a")
hist(mcmc.out$N.save,prob=TRUE,breaks=seq(0,1000,1),xlim=c(0,M),border=gray(.5),ylab="Probability",xlab="N",main="b")
dev.off()

mean(mcmc.out$N.save[-(1:1000)])
quantile(mcmc.out$N.save[-(1:1000)],c(0.025,0.975))
mean(2*mcmc.out$s.save[-(1:1000)])
quantile(2*mcmc.out$s.save[-(1:1000)],c(0.025,0.975))

###
###  Code Box 24.5
###

n.seq=100
x.seq=seq(0,u.x,,n.seq)
p.save=matrix(0,n.seq,n.mcmc)
for(k in 1:n.mcmc){
  p.save[,k]=exp(-(x.seq^2)/(mcmc.out$s.save[k]^2))
}
p.l=apply(p.save,1,quantile,0.025)
p.u=apply(p.save,1,quantile,0.975)
p.mn=apply(p.save,1,mean)

pdf(file="ds_p_post.pdf",width=10,height=6)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
plot(x.seq,p.mn,type="n",main="",ylim=c(0,1),xlab="x",ylab="p")
polygon(c(x.seq,rev(x.seq)),c(p.u,rev(p.l)),border=NA,col=8)
lines(x.seq,p.mn,lwd=1.5)
dev.off()

###
###  Code Box 24.7
###
###  Read in Yellow Warbler Data and Fit CJS Model
###

warb=matrix(c(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 
0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0),10)

source("cjs.mcmc.R")  # Code Box 24.6
n.mcmc=50000
set.seed(1)
mcmc.out=cjs.mcmc(Y=warb,n.mcmc=n.mcmc)

#matplot(cbind(mcmc.out$p.save,mcmc.out$phi.save),type="l",lty=1)

pdf(file="cjs_post.pdf",width=10,height=5)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:2,1,2))
hist(mcmc.out$p.save,breaks=50,col=8,xlim=c(0,1),main="",xlab="p",prob=TRUE)
hist(mcmc.out$phi.save,breaks=50,col=8,xlim=c(0,1),main="",xlab=bquote(phi),prob=TRUE)
dev.off()

apply(cbind(mcmc.out$p.save,mcmc.out$phi.save)[-(1:2000),],2,mean)
apply(cbind(mcmc.out$p.save,mcmc.out$phi.save)[-(1:2000),],2,quantile,c(0.025,0.975))

###
###  Code Box 24.9
###
###  Read in N-mixture Data and Fit N-mixture Model
###

amph.df=read.csv("amphibian.csv")
n=dim(amph.df)[1]
Y=as.matrix(amph.df[,2:3])
X=matrix(1,n,5)
X[,2]=scale(amph.df$elevation)
X[,3]=scale(amph.df$surface)
X[,4]=amph.df$fish
X[,5]=amph.df$cover

source("Nmix.mcmc.R")  # Code Box 24.8
n.mcmc=50000
set.seed(1)
mcmc.out=Nmix.mcmc(Y=Y,X=X,n.mcmc=n.mcmc)

#layout(matrix(1:2,2,1))
#matplot(t(mcmc.out$beta.save),type="l",lty=1)
#plot(mcmc.out$p.save,type="l")
#abline(h=mean(mcmc.out$p.save),col=8)

apply(mcmc.out$beta.save[,-(1:10000)],1,mean)
apply(mcmc.out$beta.save[,-(1:10000)],1,quantile,c(0.025,0.975))
mean(mcmc.out$p.save[-(1:10000)])
quantile(mcmc.out$p.save[-(1:10000)],c(0.025,0.975))
mean(apply(mcmc.out$N.save,2,sum)[-(1:10000)])
quantile(apply(mcmc.out$N.save,2,sum)[-(1:10000)],c(0.025,0.975))


