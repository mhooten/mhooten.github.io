cr.scale.mcmc <- function(y,J,n.mcmc){

#####
#####  Code Box 24.1
#####

#####
#####  Setup Variables 
#####

n=length(y)

psi.save=rep(0,n.mcmc)
p.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)
z.mean=rep(0,n)

#####
#####  Priors and Starting Values 
#####

p=mean(y[y>0]/J[y>0])
psi=sum(y>0)/n+p*sum(y==0)/n
z=rep(0,n)
z[y>0]=1
alpha=.001
beta=1

#####
#####  Begin MCMC Loop 
#####

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  #####
  #####  Sample z 
  #####

  psi.temp=(psi*(1-p)^J)/(psi*(1-p)^J + 1-psi) 
  z[y==0]=rbinom(sum(y==0),1,psi.temp[y==0])

  #####
  #####  Sample p 
  #####
  
  alpha.tmp=sum(y[z==1])+1
  beta.tmp=sum((J-y)[z==1])+1
  p=rbeta(1,alpha.tmp,beta.tmp)

  #####
  #####  Sample psi 
  #####

  alpha.tmp=sum(z)+alpha
  beta.tmp=n-sum(z)+beta
  psi=rbeta(1,alpha.tmp,beta.tmp)

  #####
  #####  Save Samples 
  #####
 
  z.mean=z.mean+z/n.mcmc
  p.save[k]=p
  psi.save[k]=psi
  N.save[k]=sum(z)

}
cat("\n")

#####
#####  Write Output 
#####

list(z.mean=z.mean,N.save=N.save,p.save=p.save,psi.save=psi.save,n.mcmc=n.mcmc)

}
