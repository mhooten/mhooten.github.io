###
###  Chapter 6 Script
###

###
###  Code Box 6.1
###
###  Posterior for theta and mean, var, CI 
###

n=216
y.sum=69
oneminusy.sum=147
alpha=2
beta=5

pdf(file="theta_post.pdf",width=8,height=5)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
curve(dbeta(x,y.sum+alpha,oneminusy.sum+beta),from=0,to=1,n=1000,xlab=bquote(theta),ylab="Density",lwd=1.5)
curve(dbeta(x,alpha,beta),from=0,to=1,n=1000,lty=2,add=TRUE,lwd=1.5)
dev.off()

###
###  Code Box 6.2
###

alpha.new=y.sum+alpha
beta.new=oneminusy.sum+beta
(alpha.new)/(alpha.new+beta.new)
(alpha.new*beta.new)/((alpha.new+beta.new)^2*(alpha.new+beta.new+1))
qbeta(c(0.025,0.975),alpha.new,beta.new)

y.sum/n  # MLE 

###
###  Code Box 6.3
###
###  MCMC algorithm for theta w/ symmetric proposal
###

y=c(rep(1,y.sum),rep(0,oneminusy.sum))
K=1000
theta=0.5  # initial value
theta.save=rep(0,K)
theta.save[1]=theta
s2.tune=.1

set.seed(1)
theta.acc=1
for(k in 2:K){
  theta.star=rnorm(1,theta,sqrt(s2.tune))
  if((theta.star > 0) & (theta.star < 1)){
    mh.1=sum(dbinom(y,1,theta.star,log=TRUE))+dbeta(theta.star,alpha,beta,log=TRUE)
    mh.2=sum(dbinom(y,1,theta,log=TRUE))+dbeta(theta,alpha,beta,log=TRUE)
    mh=exp(mh.1-mh.2)
    if(mh>runif(1)){
      theta=theta.star 
      theta.acc=theta.acc+1
    }
  }
  theta.save[k]=theta
}

pdf(file="theta_trace_2.pdf",width=8,height=3)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(c(1,1,2),1,3))
plot(theta.save,type="l",xlab="k",ylab=bquote(theta),lwd=1,ylim=c(0,1),main="a")
hist(theta.save,prob=TRUE,col=8,xlab=bquote(theta),main="b",xlim=c(0,1))
curve(dbeta(x,y.sum+alpha,oneminusy.sum+beta),from=0,to=1,n=1000,lwd=1.5,add=TRUE)
curve(dbeta(x,alpha,beta),from=0,to=1,n=1000,lty=2,lwd=1.5,add=TRUE)
dev.off()

###
###  Code to Create Figure 6.3 (not shown in book) 
###
###  Compare traceplots with different tuning 
###

y=c(rep(1,y.sum),rep(0,oneminusy.sum))
K=1000
theta.1=0.5  # initial value chain 1
theta.2=0.5  # initial value chain 2
theta.3=0.5  # initial value chain 3
theta.save.1=rep(0,K)
theta.save.2=rep(0,K)
theta.save.3=rep(0,K)
theta.save.1[1]=theta.1
theta.save.2[1]=theta.2
theta.save.3[1]=theta.3
s2.tune.1=.1
s2.tune.2=.01
s2.tune.3=.0001

set.seed(1)
theta.acc.1=1
theta.acc.2=1
theta.acc.3=1
for(k in 2:K){
  theta.star.1=rnorm(1,theta.1,sqrt(s2.tune.1))
  if((theta.star.1 > 0) & (theta.star.1 < 1)){
    mh.1=sum(dbinom(y,1,theta.star.1,log=TRUE))+dbeta(theta.star.1,alpha,beta,log=TRUE)
    mh.2=sum(dbinom(y,1,theta.1,log=TRUE))+dbeta(theta.1,alpha,beta,log=TRUE)
    mh=exp(mh.1-mh.2)
    if(mh>runif(1)){
      theta.1=theta.star.1
      theta.acc.1=theta.acc.1+1
    }
  }
  theta.save.1[k]=theta.1

  theta.star.2=rnorm(1,theta.2,sqrt(s2.tune.2))
  if((theta.star.2 > 0) & (theta.star.2 < 1)){
    mh.1=sum(dbinom(y,1,theta.star.2,log=TRUE))+dbeta(theta.star.2,alpha,beta,log=TRUE)
    mh.2=sum(dbinom(y,1,theta.2,log=TRUE))+dbeta(theta.2,alpha,beta,log=TRUE)
    mh=exp(mh.1-mh.2)
    if(mh>runif(1)){
      theta.2=theta.star.2
      theta.acc.2=theta.acc.2+1
    }
  }
  theta.save.2[k]=theta.2

  theta.star.3=rnorm(1,theta.3,sqrt(s2.tune.3))
  if((theta.star.3 > 0) & (theta.star.3 < 1)){
    mh.1=sum(dbinom(y,1,theta.star.3,log=TRUE))+dbeta(theta.star.3,alpha,beta,log=TRUE)
    mh.2=sum(dbinom(y,1,theta.3,log=TRUE))+dbeta(theta.3,alpha,beta,log=TRUE)
    mh=exp(mh.1-mh.2)
    if(mh>runif(1)){
      theta.3=theta.star.3
      theta.acc.3=theta.acc.3+1
    }
  }
  theta.save.3[k]=theta.3
}

pdf(file="theta_trace_3.pdf",width=6,height=9)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:3,3,1))
plot(theta.save.1,type="l",xlab="k",ylab=bquote(theta),lwd=1,ylim=c(0,1),main="a")
plot(theta.save.2,type="l",xlab="k",ylab=bquote(theta),lwd=1,ylim=c(0,1),main="b")
plot(theta.save.3,type="l",xlab="k",ylab=bquote(theta),lwd=1,ylim=c(0,1),main="c")
dev.off()

###
###  Code Box 6.4
###
###  MCMC algorithm for theta w/ logit(theta) proposal 
###

y=c(rep(1,y.sum),rep(0,oneminusy.sum))
K=1000
theta=0.5  # initial value
theta.save=rep(0,K)
theta.save[1]=theta
s2.tune=.1

logit<-function(p){log(p/(1-p))}
logit.inv<-function(x){exp(x)/(1+exp(x))}

set.seed(1)
theta.acc=1
for(k in 2:K){
  theta.star=logit.inv(rnorm(1,logit(theta),sqrt(s2.tune)))
  mh.1=sum(dbinom(y,1,theta.star,log=TRUE))+dbeta(theta.star,alpha,beta,log=TRUE)-log(theta)-log(1-theta)
  mh.2=sum(dbinom(y,1,theta,log=TRUE))+dbeta(theta,alpha,beta,log=TRUE)-log(theta.star)-log(1-theta.star)
  mh=exp(mh.1-mh.2)
  if(mh>runif(1)){
    theta=theta.star 
    theta.acc=theta.acc+1
  }
  theta.save[k]=theta
}

pdf(file="theta_trace_4.pdf",width=8,height=3)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(c(1,1,2),1,3))
plot(theta.save,type="l",xlab="k",ylab=bquote(theta),lwd=1,ylim=c(0,1),main="a")
hist(theta.save,prob=TRUE,col=8,xlab=bquote(theta),main="b",xlim=c(0,1))
curve(dbeta(x,y.sum+alpha,oneminusy.sum+beta),from=0,to=1,n=1000,lwd=1.5,add=TRUE)
curve(dbeta(x,alpha,beta),from=0,to=1,n=1000,lty=2,lwd=1.5,add=TRUE)
dev.off()

###
###  Code note shown in book
###
###  Match logit N prior to beta(2,5)
###

mu.theta=-1
s2.theta=.9^2
curve(dbeta(x,alpha,beta),from=0,to=1,n=1000,lty=1,lwd=1.5,xlim=c(0,1))
curve(dnorm(logit(x),mu.theta,sqrt(s2.theta))/x/(1-x),from=0,to=1,n=1000,lty=2,lwd=1.5,add=TRUE)

###
###  Code Box 6.5
###
###  MCMC algorithm for logit(theta) w/ normal prior 
###

y=c(rep(1,y.sum),rep(0,oneminusy.sum))
K=1000
theta=0.5  # initial value
theta.save=rep(0,K)
theta.save[1]=theta
s2.tune=.1
mu.theta=-1
s2.theta=.9^2

logit<-function(p){log(p/(1-p))}
logit.inv<-function(x){exp(x)/(1+exp(x))}

set.seed(1)
theta.acc=1
for(k in 2:K){
  theta.star=logit.inv(rnorm(1,logit(theta),sqrt(s2.tune)))
  mh.1=sum(dbinom(y,1,theta.star,log=TRUE))+dnorm(logit(theta.star),mu.theta,sqrt(s2.theta),log=TRUE)
  mh.2=sum(dbinom(y,1,theta,log=TRUE))+dnorm(logit(theta),mu.theta,sqrt(s2.theta),log=TRUE)
  mh=exp(mh.1-mh.2)
  if(mh>runif(1)){
    theta=theta.star 
    theta.acc=theta.acc+1
  }
  theta.save[k]=theta
}

pdf(file="theta_trace_5.pdf",width=8,height=3)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(c(1,1,2),1,3))
plot(theta.save,type="l",xlab="k",ylab=bquote(theta),lwd=1,ylim=c(0,1),main="a")
hist(theta.save,prob=TRUE,col=8,xlab=bquote(theta),main="b",xlim=c(0,1))
curve(dbeta(x,y.sum+alpha,oneminusy.sum+beta),from=0,to=1,n=1000,lwd=1.5,add=TRUE)
curve(dnorm(logit(x),mu.theta,sqrt(s2.theta))/x/(1-x),from=0,to=1,n=1000,lty=2,lwd=1.5,add=TRUE)
dev.off()





