norm.reg.mcmc <- function(y,X,beta.mn,beta.var,s2.mn,s2.sd,n.mcmc,no.print=FALSE){

###
### Subroutines 
###

invgammastrt <- function(igmn,igvar){
  q <- 2+(igmn^2)/igvar
  r <- 1/(igmn*(q-1))
  list(r=r,q=q)
}

###
### Hyperpriors
###

n=dim(X)[1]
p=dim(X)[2]
n.burn=round(.1*n.mcmc)
r=invgammastrt(s2.mn,s2.sd^2)$r
q=invgammastrt(s2.mn,s2.sd^2)$q
Sig.beta=beta.var*diag(p)
Sig.beta.inv=solve(Sig.beta)

beta.save=matrix(0,p,n.mcmc)
s2.save=rep(0,n.mcmc)

###
### Starting Values
###

beta=solve(t(X)%*%X)%*%t(X)%*%y

###
### MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%10000==0) cat(k," ")

  ###
  ### Sample s2
  ###

  Xbeta=X%*%beta
  tmp.r=(1/r+.5*t(y-Xbeta)%*%(y-Xbeta))^(-1)
  tmp.q=n/2+q
  s2=1/rgamma(1,tmp.q,,tmp.r) 

  ###
  ### Sample beta
  ###

  tmp.chol=chol(t(X)%*%X/s2 + Sig.beta.inv)
  beta=backsolve(tmp.chol,backsolve(tmp.chol,t(X)%*%y/s2 + Sig.beta.inv%*%beta.mn,transpose=TRUE)+rnorm(p))
 
  ###
  ### Save Samples
  ###
  
  beta.save[,k]=beta
  s2.save[k]=s2

}
cat("\n")

###
###  Write Output
###

list(beta.save=beta.save,s2.save=s2.save,y=y,X=X,n.mcmc=n.mcmc,n=n,r=r,q=q,p=p)

}
