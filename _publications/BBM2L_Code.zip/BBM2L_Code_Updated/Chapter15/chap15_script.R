###
###  Code Box 15.1
###
###  Load Deer Data, Make Design Matrices, Fit models
###

load("deer.RData")
n=dim(deer.df)[1]
y=deer.df$y
n=length(y)

L=11
X.list=vector("list",L)
X.list[[11]]=cbind(rep(1,n),as.matrix(deer.df[,c(2:5)]))
X.list[[11]][,2]=ifelse(X.list[[11]][,2]==599,0,1)

X.list[[1]]=X.list[[11]][,c(1,2)]
X.list[[2]]=X.list[[11]][,c(1,3)]
X.list[[3]]=X.list[[11]][,c(1,4)]
X.list[[4]]=X.list[[11]][,c(1,4:5)]
X.list[[5]]=X.list[[11]][,c(1,2:3)]
X.list[[6]]=X.list[[11]][,c(1,2,4)]
X.list[[7]]=X.list[[11]][,c(1,2,4,5)]
X.list[[8]]=X.list[[11]][,c(1,2,3,4)]
X.list[[9]]=X.list[[11]][,c(1,3,4)]
X.list[[10]]=X.list[[11]][,c(1,3,4,5)]

mcmc.out.list=vector("list",L)
p.vec=rep(0,L)
n.mcmc=100000
source("norm.reg.mcmc.R")
set.seed(1)
for(l in 1:L){
  p.vec[l]=dim(X.list[[l]])[2]
  mcmc.out.list[[l]]=norm.reg.mcmc(y=y,X=X.list[[l]],beta.mn=rep(0,p.vec[l]),beta.var=10000,s2.mn=50,s2.sd=1000,n.mcmc=n.mcmc)
}
p.max=max(p.vec)

###
###  Code Box 15.2
###
###  Second stage RJMCMC
###

RNGkind(sample.kind = "Rounding")
mod.mat=matrix(0,L,5)
mod.mat[1,]=c(1,1,0,0,0)
mod.mat[2,]=c(1,0,1,0,0)
mod.mat[3,]=c(1,0,0,1,0)
mod.mat[4,]=c(1,0,0,1,1)
mod.mat[5,]=c(1,1,1,0,0)
mod.mat[6,]=c(1,1,0,1,0)
mod.mat[7,]=c(1,1,0,1,1)
mod.mat[8,]=c(1,1,1,1,0)
mod.mat[9,]=c(1,0,1,1,0)
mod.mat[10,]=c(1,0,1,1,1)
mod.mat[11,]=c(1,1,1,1,1)

p.M=rep(1/L,L) # prior model probs
M=L # initial model index
M.save=rep(M,n.mcmc)
q=mcmc.out.list[[1]]$q
r=mcmc.out.list[[1]]$r
set.seed(1)
k.rand.seq=sample(2:n.mcmc,n.mcmc-1)
k.rand.idx=1
for(k in k.rand.seq){
  if(k.rand.idx%%1000==0) cat(k.rand.idx," ")
  beta=mcmc.out.list[[M]]$beta.save[,k]
  s=sqrt(mcmc.out.list[[M]]$s2.save[k])
  p.u=p.max-p.vec[M] 
  u=rnorm(p.u)
  theta=rep(0,5)
  theta[mod.mat[M,]==1]=beta
  theta[mod.mat[M,]==0]=u
  tmp.sum=rep(0,L)
  for(l in 1:L){
    tmp.sum[l]=sum(dnorm(y,X.list[[l]]%*%theta[mod.mat[l,]==1],s,log=TRUE))+sum(dnorm(theta[mod.mat[l,]==1],0,100,log=TRUE))+sum(dnorm(theta[mod.mat[l,]==0],log=TRUE))+dgamma(s^(-2),q,,r,log=TRUE)+log(p.M[M])
  }
  P.M=exp(tmp.sum-max(tmp.sum)-log(sum(exp(tmp.sum-max(tmp.sum)))))
  M=sample(1:L,1,prob=P.M)
  M.save[k]=M
  k.rand.idx=k.rand.idx+1
};cat("\n")

table(M.save)/n.mcmc

###
###  Code Box 15.3
###
###  Third stage predictions  
###

y.pred.save=matrix(0,n.mcmc,2)
for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")
  beta=mcmc.out.list[[M.save[k]]]$beta.save[,k]
  s=sqrt(mcmc.out.list[[M.save[k]]]$s2.save[k])
  y.pred.save[k,]=rnorm(2,X.list[[M.save[k]]][c(1,n),]%*%beta,s)
};cat("\n")

pdf(file="normreg_bma.pdf",width=8,height=6)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
boxplot(data.frame(y.pred.save),col=8,outline=FALSE,ylab="y",names=c("a","b"))
mtext("Individual",1,3,cex=1.25)
dev.off()

