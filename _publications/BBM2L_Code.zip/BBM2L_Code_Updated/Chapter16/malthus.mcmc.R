malthus.mcmc <- function(z,n.mcmc){

###
###  Code Box 16.5
###

###
###  Variables, Priors, Starting Values 
###

T=length(z) 
s2.save=rep(1,n.mcmc)
theta.save=rep(0,n.mcmc)

theta=0.1
mu.theta=0
s2.theta=1
beta=1000
alpha=0.001

###
###  MCMC Loop 
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ###  Sample s2
  ###

  beta.tmp=1/(sum((z[-1]-theta-z[-T])^2)/2 + 1/beta)
  alpha.tmp=(T-1)/2 + alpha 
  s2=1/rgamma(1,alpha.tmp,,beta.tmp)

  ###
  ###  Sample theta 
  ###

  tmp.var=1/((T-1)/s2 + 1/s2.theta)
  tmp.mn=tmp.var*(sum(z[-1]-z[-T])/s2 + mu.theta/s2.theta)
  theta=rnorm(1,tmp.mn,sqrt(tmp.var))

  ###
  ###  Save Samples 
  ###
  
  theta.save[k]=theta
  s2.save[k]=s2

}
cat("\n")

###
###  Write Output
###

list(z=z,s2.save=s2.save,theta.save=theta.save,n.mcmc=n.mcmc,mu.theta=mu.theta,s2.theta=s2.theta,alpha=alpha,beta=beta)

}
