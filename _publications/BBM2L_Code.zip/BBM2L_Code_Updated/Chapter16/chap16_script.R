###
###  Chapter 16 Script
###

###
###  Code Box 16.1
###
###  Simulate AR(1) data
###

T=100
y.1=rep(0,T)
y.2=rep(0,T)
y.3=rep(0,T)
alpha.1=.99
alpha.2=0
alpha.3=-.8
sig=1

set.seed(1)
for(t in 2:T){
  y.1[t]=rnorm(1,alpha.1*y.1[t-1],sig)
  y.2[t]=rnorm(1,alpha.2*y.2[t-1],sig)
  y.3[t]=rnorm(1,alpha.3*y.3[t-1],sig)
}

pdf(file="ar1_sim.pdf",width=7,height=10)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:3,3,1))
plot(1:T,y.1,type="l",lwd=1.5,xlab="t",main="a")
abline(h=0,col=8)
plot(1:T,y.2,type="l",lwd=1.5,xlab="t",main="b")
abline(h=0,col=8)
plot(1:T,y.3,type="l",lwd=1.5,xlab="t",main="c")
abline(h=0,col=8)
dev.off()

###
###  Code Box 16.2
###
###  Plot Time Series Data   
###

load("soil.RData")
T=length(y)
y.c=y-mean(y)

pdf(file="soil_data.pdf",width=8,height=6)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
plot(y,type="l",lwd=2,ylab="Soil Moisture (y)",xlab="Days Since Aug. 11, 2017",main="")
abline(h=0,col=8)
dev.off()

###
###  Code Box 16.4
###
###  Fit AR(1) Model 
###

source("ar1.mcmc.R")
set.seed(1)
mcmc.out=ar1.mcmc(y=y.c,n.mcmc=10000) # Code Box 16.3

dIG <- function(x,r,q){
  x^(-(q+1))*exp(-1/r/x)/(r^q)/gamma(q)
}

pdf(file="ar1_post.pdf",width=8,height=5)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:2,1,2))
hist(mcmc.out$alpha.save,breaks=20,col=8,xlab=bquote(alpha),main="a",xlim=c(-1,1),prob=TRUE)
curve(dnorm(x,mcmc.out$mu.alpha,sqrt(mcmc.out$s2.alpha)),add=TRUE,lwd=1.5,from=-2,to=2)
hist(mcmc.out$s2.save,breaks=40,col=8,xlab=bquote(sigma^2),main="b",prob=TRUE)
curve(dIG(x,mcmc.out$r,mcmc.out$q),add=TRUE,lwd=1.5)
dev.off()

###
###  Code Box 16.6
###
###  Load in Scaup Data (stratum 46, 1980-2009) and fit Malthusian model
###

y=c(13,14,40,84,113,53,71,42,80,57,45,20,47,24,49,199,173,185,133,204,308,368,185,234,618,177,353,193,206,152)
years=1980:2009
plot(years,y,type="o")
z=log(y)

source("malthus.mcmc.R")  # Code Box 16.5
set.seed(1)
mcmc.out=malthus.mcmc(z=z,n.mcmc=10000)

layout(matrix(1:2,2,1))
plot(mcmc.out$theta.save,type="l")
plot(mcmc.out$s2.save,type="l")

dIG <- function(x,r,q){
  x^(-(q+1))*exp(-1/r/x)/(r^q)/gamma(q)
}

pdf(file="malthus_post.pdf",width=12,height=5)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:3,1,3))
hist(mcmc.out$theta.save,col=8,breaks=30,xlab=bquote(theta),main="a",xlim=c(-1,1),prob=TRUE)
curve(dnorm(x,mcmc.out$mu.theta,sqrt(mcmc.out$s2.theta)),add=TRUE,lwd=1.5,from=-2,to=2)
abline(v=0,lty=2,lwd=2)
hist(exp(mcmc.out$theta.save)-1,col=8,breaks=30,xlab="r",main="b",xlim=c(-1,1),prob=TRUE)
lines(density(exp(rnorm(10000))-1,from=-2,to=2),lwd=1.5)
abline(v=0,lwd=2,lty=2)
hist(mcmc.out$s2.save,col=8,breaks=40,xlab=bquote(sigma^2),main="c",xlim=c(0,2),prob=TRUE)
curve(dIG(x,mcmc.out$beta,mcmc.out$alpha),add=TRUE,lwd=1.5)
dev.off()

###
###  Code Box 16.7
###

mean(exp(mcmc.out$theta.save)-1>0)

###
###  Code Box 16.8
###
###  Obtain Predictions and Forecasts for Scaup Data
###

n.mcmc=10000
T=length(z)
z.pred.mat=matrix(0,n.mcmc,T+3)
set.seed(1)
z.pred.mat[,1]=rnorm(n.mcmc,z[2]-mcmc.out$theta.save,sqrt(mcmc.out$s2.save))
for(t in 2:(T-1)){
  z.pred.mat[,t]=rnorm(n.mcmc,(z[t-1]+z[t+1])/2,sqrt(mcmc.out$s2.save))
}
z.pred.mat[,T]=rnorm(n.mcmc,mcmc.out$theta.save+z[T-1],sqrt(mcmc.out$s2.save))
z.pred.mat[,T+1]=rnorm(n.mcmc,mcmc.out$theta.save+z[T],sqrt(mcmc.out$s2.save))
z.pred.mat[,T+2]=rnorm(n.mcmc,mcmc.out$theta.save+z.pred.mat[,T+1],sqrt(mcmc.out$s2.save))
z.pred.mat[,T+3]=rnorm(n.mcmc,mcmc.out$theta.save+z.pred.mat[,T+2],sqrt(mcmc.out$s2.save))

z.pred.mn=apply(z.pred.mat,2,mean)
z.pred.l=apply(z.pred.mat,2,quantile,0.025)
z.pred.u=apply(z.pred.mat,2,quantile,0.975)

y.pred.mn=apply(exp(z.pred.mat),2,mean)
y.pred.l=apply(exp(z.pred.mat),2,quantile,0.025)
y.pred.u=apply(exp(z.pred.mat),2,quantile,0.975)

pdf(file="malthus_pred.pdf",width=10,height=10)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:2,2,1))
matplot(1980:2012,cbind(z.pred.l,z.pred.u),type="n",ylab="z",xlab="year",main="a")
points(1980:2009,z,lwd=1.5)
polygon(c(1980:2012,2012:1980),c(z.pred.u,rev(z.pred.l)),col=rgb(0,0,0,.2),border=NA)
lines(1980:2012,z.pred.mn,lwd=1.5)
points(1980:2009,z,lwd=1.5)
abline(v=2009,lty=2)
matplot(1980:2012,cbind(y.pred.l,y.pred.u),type="n",ylab="y",xlab="year",main="b")
points(1980:2009,y,lwd=1.5)
polygon(c(1980:2012,2012:1980),c(y.pred.u,rev(y.pred.l)),col=rgb(0,0,0,.2),border=NA)
lines(1980:2012,y.pred.mn,lwd=1.5)
points(1980:2009,y,lwd=1.5)
abline(v=2009,lty=2)
dev.off()

###
###  Code Box 16.10 
###
###  Read in Sandhill Crane Data and fit CRW model
###

load("sacr.RData")

pdf(file="sacr_data.pdf",width=10,height=4)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,2,2))
layout(matrix(c(rep(1,4),rep(2:3,3)),2,5))
plot(S.sm,type="o",cex=.5,asp=TRUE,xlab="easting",ylab="northing",main="a")
plot(times.sm,S.sm[,1],type="o",cex=.5,xlab="date",ylab="easting",main="b")
plot(times.sm,S.sm[,2],type="o",cex=.5,xlab="date",ylab="northing",main="c")
dev.off()

set.seed(1)
source("crw.mcmc.R") # Code Box 16.9
mcmc.out=crw.mcmc(S=S.sm,n.mcmc=100000)

layout(matrix(1:3,3,1))
plot(mcmc.out$gamma,type="l",ylab=bquote(gamma),xlab="iteration",ylim=c(0,1),main="a")
plot(mcmc.out$theta,type="l",ylab=bquote(theta),xlab="iteration",ylim=c(-pi,pi),main="b")
plot(mcmc.out$s2,type="l",ylab=bquote(sigma^2),xlab="iteration",main="c")

dIG <- function(x,r,q){
  x^(-(q+1))*exp(-1/r/x)/(r^q)/gamma(q)
}

pdf(file="sacr_post.pdf",width=10,height=4)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:3,1,3))
hist(mcmc.out$gamma.save[-(1:100)],breaks=40,col=8,xlab=bquote(gamma),main="a",xlim=c(0,1),prob=TRUE)
curve(dunif(x,0,1),lwd=2,add=TRUE)
hist(mcmc.out$theta.save[-(1:100)],breaks=40,col=8,xlab=bquote(theta),main="b",xlim=c(-pi,pi),prob=TRUE)
curve(dunif(x,-pi,pi),lwd=2,add=TRUE)
abline(v=0,lty=2,col=1)
hist(mcmc.out$s2.save[-(1:100)],breaks=40,col=8,xlab=bquote(sigma^2),main="c",prob=TRUE)
curve(dIG(x,mcmc.out$r,mcmc.out$q),add=TRUE,lwd=2)
dev.off()

###
###  Code Box 16.11
###

mean(mcmc.out$theta.save[-(1:100)]>0)


