crw.mcmc <- function(S,n.mcmc){

###
###  Code Box 16.9 
###

####
####  Libraries and Subroutines  
####

library(msm)

make.Theta <- function(theta){
  Theta=matrix(0,2,2) 
  Theta[1,1]=cos(theta)
  Theta[1,2]=-sin(theta)
  Theta[2,1]=sin(theta)
  Theta[2,2]=cos(theta)
  Theta 
}

make.M <- function(gamma,theta){
  Theta=make.Theta(theta) 
  M=gamma*Theta
  M
}

####
####  Set Up Variables
####

Delta=apply(S,2,diff)
T=dim(Delta)[1]

theta.save=rep(0,n.mcmc)
gamma.save=rep(0,n.mcmc)
s2.save=rep(0,n.mcmc)

####
####  Priors and Starting Values
####

theta=0
gamma=.9
Theta=make.Theta(theta)
M=make.M(gamma,theta)
s2=.01
Sig=s2*diag(2)
Sig.inv=solve(Sig)

q=.0001
r=1000

####
####  Begin MCMC Loop
####

for(k in 1:n.mcmc){
  if(k%%100==0) cat(k," ")

  ####
  ####  Sample theta 
  ####

  theta.star=runif(1,-pi,pi)
  M.star=make.M(gamma,theta.star)
  tmp.theta.sum.1=0
  tmp.theta.sum.2=0
  for(t in 2:T){
    delta.star=M.star%*%Delta[t-1,]
    delta=M%*%Delta[t-1,]
    tmp.theta.sum.1=tmp.theta.sum.1-t(Delta[t,]-delta.star)%*%Sig.inv%*%(Delta[t,]-delta.star)/2
    tmp.theta.sum.2=tmp.theta.sum.2-t(Delta[t,]-delta)%*%Sig.inv%*%(Delta[t,]-delta)/2
  }
 
  mh1=tmp.theta.sum.1
  mh2=tmp.theta.sum.2
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    theta=theta.star
    Theta=make.Theta(theta)
  } 

  ####
  ####  Sample gamma 
  ####

  tmp.b=0
  tmp.a=0
  for(t in 2:T){
    delta=Theta%*%Delta[t-1,]
    tmp.b=tmp.b+t(Delta[t,])%*%Sig.inv%*%delta
    tmp.a=tmp.a+t(delta)%*%Sig.inv%*%delta
  }
  tmp.var=1/tmp.a
  tmp.mn=tmp.var*tmp.b 
  gamma=rtnorm(1,tmp.mn,sqrt(tmp.var),0,1)
  M=make.M(gamma,theta)

  ####
  ####  Sample s2
  ####

  tmp.diff=Delta[2:T,]-t(M%*%t(Delta[1:(T-1),]))
  tmp.sum=sum(apply(tmp.diff^2,1,sum))
  s2=1/rgamma(1,T-1+q,,1/(tmp.sum/2+1/r))
  Sig=s2*diag(2)
  Sig.inv=diag(2)/s2

  ####
  ####  Save Samples
  ####

  theta.save[k]=theta
  gamma.save[k]=gamma
  s2.save[k]=s2

}
cat("\n")


####
#### Write Output
####

list(s2.save=s2.save,n.mcmc=n.mcmc,S=S,Delta=Delta,theta.save=theta.save,gamma.save=gamma.save,r=r,q=q)

}
