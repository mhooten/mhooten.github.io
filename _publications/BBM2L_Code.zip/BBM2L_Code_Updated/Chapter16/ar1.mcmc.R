ar1.mcmc <- function(y,n.mcmc){

###
###  Code Box 16.3
###
###  Variables, Priors, Starting Values 
###

T=length(y) 
s2.save=rep(1,n.mcmc)
alpha.save=rep(0,n.mcmc)

alpha=0.1
mu.alpha=0
s2.alpha=1
r=1000
q=0.001

###
###  Gibbs Loop 
###
for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ###  Sample s2
  ###

  r.tmp=1/(sum((y[-1]-alpha*y[-T])^2)/2 + 1/r)
  q.tmp=(T-1)/2 + q
  s2=1/rgamma(1,q.tmp,,r.tmp)

  ###
  ###  Sample alpha 
  ###

  tmp.var=1/(sum(y[-T]^2)/s2 + 1/s2.alpha)
  tmp.mn=tmp.var*(sum(y[-1]*y[-T])/s2 + mu.alpha/s2.alpha)
  alpha=rnorm(1,tmp.mn,sqrt(tmp.var))

  ###
  ###  Save Samples 
  ###
  
  alpha.save[k]=alpha 
  s2.save[k]=s2

}
cat("\n")

###
###  Write Output
###

list(y=y,s2.save=s2.save,alpha.save=alpha.save,n.mcmc=n.mcmc,mu.alpha=mu.alpha,s2.alpha=s2.alpha,r=r,q=q)

}
