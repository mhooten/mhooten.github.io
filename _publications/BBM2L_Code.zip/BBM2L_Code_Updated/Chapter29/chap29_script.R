###
###  Chapter 29 R Script
###

###
### Code Box 29.1
###
### Simulate Hamiltonian Trajectories from MVN
###

mu=rep(0,2)
Sig=matrix(c(1,.9,.9,1),2,2)
Sig.inv=solve(Sig)
s2v=1

n.sim=4
T=150
dt=.025
theta.array=array(0,c(T,2,n.sim))
theta.array[T,,1]=c(0.5,0.75)
set.seed(97)
for(k in 2:n.sim){
  if(k%%10==0) cat(k," ")
  theta=theta.array[T,,k-1]
  theta.array[1,,k]=theta
  v=rnorm(2,0,sqrt(s2v))
  for(t in 1:T){
    v=v-(dt/2)*Sig.inv%*%(theta-mu) 
    theta=theta+dt*v/s2v
    v=v-(dt/2)*Sig.inv%*%(theta-mu) 
    theta.array[t,,k]=theta
  }
};cat("\n")

library(mixtools)
labs=c("a","b","c")
pdf(file="hamil_sim.pdf",width=3,height=10)
par(cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:3,3,1))
for(k in 2:n.sim){
  plot(0,0,type="n",xlim=c(-3.5,3.5),ylim=c(-3.5,3.5),xlab=bquote(theta[1]),ylab=bquote(theta[2]),asp=TRUE,main=labs[k-1])
  ellipse(mu,Sig,.5,1000,col=8)
  ellipse(mu,Sig,.25,1000,col=8)
  ellipse(mu,Sig,.05,1000,col=8)
  lines(theta.array[,,k],lwd=1.5)
  points(theta.array[1,1,k],theta.array[1,2,k],pch=20)
  arrows(theta.array[T-2,1,k],theta.array[T-2,2,k],theta.array[T,1,k],theta.array[T,2,k],length=.05,lwd=1.5)
}
dev.off()

###
###  Code Box 29.2
###
###  Simulate linear regression data 
###

set.seed(101)
n=100
x1=rnorm(n)
x2=rnorm(n,.99*x1,.1)
X=cbind(rep(1,n),x1,x2)
beta=c(.5,1,1)
sig=.1
s2=sig^2
y=rnorm(n,X%*%beta,sig)

cor(x1,x2)

###
###  Code Box 29.6
###
###  Fit linear regression using HMC
###

n.mcmc=2000
source("reg.hmc.R") # Code Box 29.5
set.seed(201)
hmc.out=reg.hmc(y=y,X=X,beta.mn=rep(0,3),beta.var=100,n.mcmc=n.mcmc)

source("reg.mh.mcmc.R") # Code Box 29.4
set.seed(201)
mh.out=reg.mh.mcmc(y=y,X=X,beta.mn=rep(0,3),beta.var=100,beta.tune=0.0035,n.mcmc=n.mcmc)

source("reg.mcmc.R") # Code Box 29.3
set.seed(201)
mcmc.out=reg.mcmc(y=y,X=X,beta.mn=rep(0,3),beta.var=100,n.mcmc=n.mcmc)

pdf(file="hamil_post.pdf",width=7,height=10)
par(cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:3,3,1))
plot(hmc.out$beta.save[2,],type="l",ylim=c(.5,1.2),ylab=bquote(beta[1]),xlab="iteration",main="a")
abline(h=beta[2],col=8)
plot(mh.out$beta.save[2,],type="l",ylim=c(.5,1.2),ylab=bquote(beta[1]),xlab="iteration",main="b")
abline(h=beta[2],col=8)
plot(mcmc.out$beta.save[2,],type="l",ylim=c(.5,1.2),ylab=bquote(beta[1]),xlab="iteration",main="c")
abline(h=beta[2],col=8)
dev.off()

apply(hmc.out$beta.save,1,mean)
apply(mh.out$beta.save,1,mean)
apply(mcmc.out$beta.save,1,mean)
apply(hmc.out$beta.save,1,sd)
apply(mh.out$beta.save,1,sd)
apply(mcmc.out$beta.save,1,sd)

hmc.out$beta.acc
mh.out$beta.acc


