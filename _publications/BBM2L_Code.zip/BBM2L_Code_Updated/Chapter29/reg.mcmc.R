reg.mcmc <- function(y,X,beta.mn,beta.var,n.mcmc){

###
### Code Box 29.3
###

###
### Hyperpriors
###

n=dim(X)[1]
p=dim(X)[2]
r=1000
q=.001
Sig.beta=beta.var*diag(p)
Sig.beta.inv=solve(Sig.beta)

beta.save=matrix(0,p,n.mcmc)
s2.save=rep(0,n.mcmc)

###
### Starting Values
###

XpX=t(X)%*%X
beta=solve(XpX)%*%t(X)%*%y

###
### MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%100==0) cat(k," ")

  ###
  ### Sample s2
  ###

  tmp.r=(1/r+.5*t(y-X%*%beta)%*%(y-X%*%beta))^(-1)
  tmp.q=n/2+q

  s2=1/rgamma(1,tmp.q,,tmp.r) 

  ###
  ### Sample beta
  ###

  tmp.chol=chol(XpX/s2 + Sig.beta.inv)
  beta=backsolve(tmp.chol,backsolve(tmp.chol,t(X)%*%y/s2 + Sig.beta.inv%*%beta.mn,transpose=TRUE)+rnorm(p))

  ###
  ### Save Samples
  ###
  
  beta.save[,k]=beta
  s2.save[k]=s2

}
cat("\n")

###
###  Write Output
###

list(beta.save=beta.save,s2.save=s2.save,y=y,X=X,n.mcmc=n.mcmc,n=n,r=r,q=q,p=p)

}
