reg.mh.mcmc <- function(y,X,beta.mn,beta.var,beta.tune,n.mcmc){

###
### Code Box 29.4
###

###
### Hyperpriors
###

n=dim(X)[1]
p=dim(X)[2]
r=1000
q=.001
Sig.beta=beta.var*diag(p)
Sig.beta.inv=solve(Sig.beta)
beta.sd=sqrt(beta.var)

beta.save=matrix(0,p,n.mcmc)
s2.save=rep(0,n.mcmc)

###
### Starting Values
###

XpX=t(X)%*%X
beta=solve(XpX)%*%t(X)%*%y
beta.acc=0

###
### MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%100==0) cat(k," ")

  ###
  ### Sample s2
  ###

  tmp.r=(1/r+.5*t(y-X%*%beta)%*%(y-X%*%beta))^(-1)
  tmp.q=n/2+q

  s2=1/rgamma(1,tmp.q,,tmp.r) 

  ###
  ### Sample beta
  ###

  beta.star=rnorm(p,beta,beta.tune)
  mh.1=sum(dnorm(y,X%*%beta.star,sqrt(s2),log=TRUE))+sum(dnorm(beta.star,beta.mn,beta.sd,log=TRUE))
  mh.2=sum(dnorm(y,X%*%beta,sqrt(s2),log=TRUE))+sum(dnorm(beta,beta.mn,beta.sd,log=TRUE))
  mh=exp(mh.1-mh.2)
  if(mh>runif(1)){
    beta=beta.star
    beta.acc=beta.acc+1
  }

  ###

  ### Save Samples
  ###
  
  beta.save[,k]=beta
  s2.save[k]=s2

}
cat("\n")

###
###  Write Output
###

list(beta.save=beta.save,s2.save=s2.save,y=y,X=X,n.mcmc=n.mcmc,n=n,r=r,q=q,p=p,beta.acc=beta.acc)

}
