###
###  Chapter 3 R Script
###

###
###  Code Box 3.1 
###
###  Histograms from Monte Carlo Samples   
###

set.seed(105)
pdf(file="MC_unif.pdf",width=10,height=4)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5)
layout(matrix(1:3,1,3))
hist(runif(100),col=8,xlab="a",breaks=30,prob=TRUE,main="a",ylim=c(0,2))
abline(h=1,lty=2)
mtext("K=100",line=.25)
hist(runif(1000),col=8,xlab="a",breaks=30,prob=TRUE,main="b",ylim=c(0,2))
abline(h=1,lty=2)
mtext("K=1000",line=.25)
hist(runif(10000),col=8,xlab="a",breaks=30,prob=TRUE,main="c",ylim=c(0,2))
abline(h=1,lty=2)
mtext("K=10000",line=.25)
dev.off()

###
###  Code Box 3.2
###
###  MC integral for mean of uniform 
###

set.seed(1)
a=runif(100)
mean(a)
a=runif(1000)
mean(a)
a=runif(10000)
mean(a)

###
###  Code Box 3.3
###
###  MC integral for mean of uniform squared 
###

set.seed(1)
a=runif(10000)
mean(a^2)

###
###  Code Box 3.4
###
###  MC integral for variance of uniform 
###

set.seed(1)
a=runif(10000)
var(a)

###
###  Code Box 3.5
###
###  MC integral for marginal of [b] 
###

set.seed(1)
a=runif(10000)
b=0
mean(dbinom(b,1,a))
b=1
mean(dbinom(b,1,a))


