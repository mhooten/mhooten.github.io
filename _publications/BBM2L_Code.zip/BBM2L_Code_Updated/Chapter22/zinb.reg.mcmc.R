zinb.reg.mcmc <- function(y,X,beta.mn,beta.var,n.mcmc){

###
###  Code Box 22.4
###

###
###  Preliminary Variables
###

X=as.matrix(X)
y=as.vector(y)
n=length(y)
pp=dim(X)[2]

beta.save=matrix(0,pp,n.mcmc)
mu.save=matrix(0,n,n.mcmc)
z.save=matrix(0,n,n.mcmc)
p.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)

###
###  Starting Values and Priors
###

logN.mn=log(1)
logN.sd=log(3)

N=4
beta.sd=sqrt(beta.var)
beta=beta.mn
z=rep(0,n)
z[y>0]=1
mu=exp(X%*%beta)
p=.9
beta.tune=.1
N.tune=.5

###
###  Gibbs Loop
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ### Sample z 
  ###
  theta=N/(N+mu[y==0])
  p.tmp=p*(theta^N)/(1-p+p*(theta^N))
  z[y==0]=rbinom(sum(y==0),1,p.tmp)

  ###
  ### Sample p 
  ###

  p=rbeta(1,sum(z)+1,n-sum(z)+1)

  ###
  ### Sample beta
  ###

  beta.star=rnorm(pp,beta,beta.tune)
  mu.star=exp(X%*%beta.star)

  mh1=sum(dnbinom(y[z==1],mu=mu.star[z==1],size=N,log=TRUE))+sum(dnorm(beta.star,beta.mn,beta.sd,log=TRUE))
  mh2=sum(dnbinom(y[z==1],mu=mu[z==1],size=N,log=TRUE))+sum(dnorm(beta,beta.mn,beta.sd,log=TRUE))
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    beta=beta.star   
    mu=mu.star   
  }

  ###
  ### Sample N 
  ###

  N.star=exp(rnorm(1,log(N),N.tune))

  mh1=sum(dnbinom(y[z==1],mu=mu[z==1],size=N.star,log=TRUE))+dnorm(log(N.star),logN.mn,logN.sd,log=TRUE)
  mh2=sum(dnbinom(y[z==1],mu=mu[z==1],size=N,log=TRUE))+dnorm(log(N),logN.mn,logN.sd,log=TRUE)
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    N=N.star
  }

  ###
  ### Save Samples 
  ###

  z.save[,k]=z
  p.save[k]=p
  N.save[k]=N
  beta.save[,k]=beta
  mu.save[,k]=mu

}
cat("\n")

###
###  Write output 
###

list(y=y,X=X,n.mcmc=n.mcmc,beta.save=beta.save,mu.save=mu.save,p.save=p.save,z.save=z.save,N.save=N.save)

}
