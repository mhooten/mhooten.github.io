###
###  Chapter 22 R Script
###

####
####  Code Box 22.2
####
####  Create Variables and Scale Covariates 
####

wt.c.df=read.table("wt.1.count.txt",header=TRUE)
y=wt.c.df$y
n=length(y)
X=cbind(rep(1,n),as.matrix(scale(wt.c.df[,-1])))

pdf(file="zip_data.pdf",width=10,height=6)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5)
barplot(table(y),col=8,xlab="Count (y)",ylab="Frequency")
dev.off()

####
####  Code Box 22.3
####
####  Fit ZIP Model 
####

source("zip.reg.mcmc.R")  # Code Box 22.1
n.mcmc=50000
set.seed(1)
mcmc.out=zip.reg.mcmc(y=y,X=X,beta.mn=rep(0,dim(X)[2]),beta.var=1000,n.mcmc=n.mcmc)

#layout(matrix(1:2,2,1))
#matplot(t(mcmc.out$beta.save),type="l",lty=1)
#plot(mcmc.out$p.save,type="l")

pdf(file="zip_post.pdf",width=10,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[0]),prob=TRUE,main="a")
curve(dnorm(x,0,sqrt(1000)),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[1]),prob=TRUE,main="b")
curve(dnorm(x,0,sqrt(1000)),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[2]),prob=TRUE,main="c")
curve(dnorm(x,0,sqrt(1000)),lwd=2,add=TRUE)
hist(mcmc.out$p.save[-(1:1000)],breaks=20,col=8,xlab="p",xlim=c(0,1),prob=TRUE,main="d")
curve(dunif(x),lwd=2,add=TRUE)
dev.off()

mean(mcmc.out$p.save[-(1:1000)])
quantile(mcmc.out$p.save[-(1:1000)],c(0.025,0.975))

####
####  Code Box 22.5
####
####  Fit ZINB Model 
####

source("zinb.reg.mcmc.R")  # Code Box 22.4
set.seed(1)
mcmc.nb.out=zinb.reg.mcmc(y=y,X=X,beta.mn=rep(0,dim(X)[2]),beta.var=1000,n.mcmc=n.mcmc)

#layout(matrix(1:3,3,1))
#matplot(t(mcmc.nb.out$beta.save),type="l",lty=1)
#plot(mcmc.nb.out$N.save,type="l")
#plot(mcmc.nb.out$p.save,type="l")

pdf(file="zinb_post.pdf",width=10,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.nb.out$beta.save[1,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[0]),prob=TRUE,main="a")
curve(dnorm(x,0,sqrt(1000)),lwd=2,add=TRUE)
hist(mcmc.nb.out$beta.save[2,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[1]),prob=TRUE,main="b")
curve(dnorm(x,0,sqrt(1000)),lwd=2,add=TRUE)
hist(mcmc.nb.out$beta.save[3,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[2]),prob=TRUE,main="c")
curve(dnorm(x,0,sqrt(1000)),lwd=2,add=TRUE)
hist(mcmc.nb.out$p.save[-(1:1000)],breaks=30,col=8,xlab="p",xlim=c(0,1),prob=TRUE,main="d")
curve(dunif(x),lwd=2,add=TRUE)
dev.off()

mean(mcmc.nb.out$N.save[-(1:1000)])
quantile(mcmc.nb.out$N.save[-(1:1000)],c(0.025,0.975))

####
####  Code Box 22.6
####
####  Get Posterior Predictions and Post. Pred. P-value for MSE 
####

p.ind=rep(0,n.mcmc)
nb.ind=rep(0,n.mcmc)
set.seed(1)
for(k in 1:n.mcmc){
  y.pred.p=rep(0,n)
  z.1.p.idx=(mcmc.out$z.save[,k]==1)
  lam.p=exp(mcmc.out$X%*%mcmc.out$beta.save[,k])
  y.pred.p[z.1.p.idx]=rpois(sum(z.1.p.idx),lam.p[z.1.p.idx])
  mse.p=mean((y.pred.p-mcmc.out$p.save[k]*lam.p)^2)
  p.ind[k]=(mse.p>mean((y-mcmc.out$p.save[k]*lam.p)^2))

  y.pred.nb=rep(0,n)
  z.1.nb.idx=(mcmc.nb.out$z.save[,k]==1)
  lam.nb=exp(mcmc.nb.out$X%*%mcmc.nb.out$beta.save[,k])
  y.pred.nb[z.1.nb.idx]=rnbinom(sum(z.1.nb.idx),mu=lam.nb[z.1.nb.idx],size=mcmc.nb.out$N.save[k])
  mse.nb=mean((y.pred.nb-mcmc.nb.out$p.save[k]*lam.nb)^2)
  nb.ind[k]=(mse.nb>mean((y-mcmc.nb.out$p.save[k]*lam.nb)^2))
}

pval.p=mean(p.ind[-(1:1000)])
pval.nb=mean(nb.ind[-(1:1000)])
pval.p
pval.nb



