####
####  Read in Willow Tit Count Data (Royle and Dorazio (2008), page 88)
####

wt.c.df=read.table("wt.1.count.txt",header=TRUE)

####
####  Create Variables and Scale Covariates 
####

y=wt.c.df$y
n=length(y)
X1=cbind(rep(1,n),as.matrix(scale(wt.c.df[,-1])))
X2=cbind(X1,X1[,2]^2)

barplot(table(y),col=8)

####
####  Fit ZIP Model with no Quadratic Effect (Note, p-value: 0.03)
####

source("zip.reg.mcmc.R")
wt.1.zip.out=zip.reg.mcmc(y,X1,rep(0,dim(X1)[2]),10,5000,0.1)

#wt.1.zip.out$p.value
wt.1.zip.out$p.value.2

layout(matrix(1:2,2,1))
matplot(t(wt.1.zip.out$betasave),type="l",lty=1)
plot(wt.1.zip.out$psave,type="l")

layout(matrix(1:(dim(X1)[2]+1),1,1+dim(X1)[2]))
hist(wt.1.zip.out$betasave[1,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[0]),prob=TRUE,main="")
hist(wt.1.zip.out$betasave[2,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[1]),prob=TRUE,main="")
hist(wt.1.zip.out$betasave[3,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[2]),prob=TRUE,main="")
hist(wt.1.zip.out$psave[-(1:1000)],breaks=40,col=8,xlab="p",prob=TRUE,main="")

hist(wt.1.zip.out$msediffsave[-(1:1000)],col=8,breaks=50)

####
####  Fit ZIP Model with Quadratic Effect (Note, p-value: approx 0.01)
####

source("zip.reg.mcmc.R")
wt.2.zip.out=zip.reg.mcmc(y,X2,rep(0,dim(X2)[2]),10,10000,0.1)

#wt.2.zip.out$p.value
wt.2.zip.out$p.value.2
hist(wt.2.zip.out$msediffsave[-(1:1000)],col=8,breaks=50)

layout(matrix(1:2,2,1))
matplot(t(wt.2.zip.out$betasave),type="l",lty=1)
plot(wt.2.zip.out$psave,type="l")

layout(matrix(1:(1+dim(X2)[2]),1,1+dim(X2)[2]))
hist(wt.2.zip.out$betasave[1,-(1:1000)],breaks=40,col=8,main=bquote(beta[0]))
hist(wt.2.zip.out$betasave[2,-(1:1000)],breaks=40,col=8,main=bquote(beta[1]))
hist(wt.2.zip.out$betasave[3,-(1:1000)],breaks=40,col=8,main=bquote(beta[2]))
hist(wt.2.zip.out$betasave[4,-(1:1000)],breaks=40,col=8,main=bquote(beta[3]))
hist(wt.2.zip.out$psave[-(1:1000)],breaks=40,col=8,main="p")

####
####  Fit ZINB Model with Quadratic Effect (Note, p-value:  0.628)
####

source("zinb.reg.mcmc.R")
wt.2.zinb.out=zinb.reg.mcmc(y,X2,rep(0,dim(X2)[2]),10,10000,0.1)

wt.2.zinb.out$p.value
wt.2.zinb.out$p.value.2
hist(wt.2.zinb.out$msediffsave[-(1:1000)],col=8,breaks=50)

layout(matrix(1:3,3,1))
matplot(t(wt.2.zinb.out$betasave),type="l",lty=1)
plot(wt.2.zinb.out$Nsave[-(1:2000)],type="l")
plot(wt.2.zinb.out$psave[-(1:2000)],type="l")

####
####  Fit Pois Model with Quadratic Effect (Note, p-value:  0)
####

source("pois.reg.mcmc.R")
wt.2.pois.out=pois.reg.mcmc(y,X2,rep(0,dim(X2)[2]),10,10000,0.1)

wt.2.pois.out$p.value

####
####  Fit NB Model with Quadratic Effect (Note, p-value:  0.65)
####

source("nb.reg.mcmc.R")
wt.2.nb.out=nb.reg.mcmc(y,X2,rep(0,dim(X2)[2]),10,10000,0.1)

wt.2.nb.out$p.value
hist(wt.2.nb.out$msediffsave[-(1:1000)],col=8,breaks=50)

