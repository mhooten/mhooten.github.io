nb.reg.mcmc <- function(y,X,betamn,betavar,n.mcmc,betatune=1){

#
#  Mevin Hooten (20080410)  Last Updated:  20111010
#  Negative Binomial regression with uncorrelated errors
#
#  EXAMPLE USE:
#  ------------
#
#  tmp.out=nb.reg.mcmc(y,X,rep(0,dim(X)[2]),10,1000,.01)
#  matplot(t(tmp.out$betasave),type="l")
#
#

###
###  Subroutines
###


###
###  Preliminary Variables
###

n.burn=round(n.mcmc/10)
X=as.matrix(X)
y=as.vector(y)
n=length(y)
p=dim(X)[2]

mse.y=rep(0,n.mcmc)
mse.ypred=rep(0,n.mcmc)
msediffsave=rep(0,n.mcmc)
ypredsave=matrix(0,n,n.mcmc)
msesave=rep(0,n.mcmc)
Nsave=rep(0,n.mcmc)
betasave=matrix(0,p,n.mcmc)
lamsave=matrix(0,n,n.mcmc)
Davgsave=rep(0,n.mcmc)

###
###  Starting Values and Priors
###

logN.mn=log(1)
logN.sd=log(3)

N=4
beta=betamn
lam=exp(X%*%beta)
betasave[,1]=beta
lamsave[,1]=lam
beta.acc=1
N.tune=.5

###
###  Gibbs Loop
###

for(k in 1:n.mcmc){
  if(k%%100==0) cat(k," ");flush.console()

  ###
  ### Sample beta
  ###

  betastar=rnorm(p,beta,betatune)
  lamstar=exp(X%*%betastar)

  mh1=sum(dnbinom(y,mu=lamstar,size=N,log=TRUE))+sum(dnorm(betastar,betamn,sqrt(betavar),log=TRUE))
  mh2=sum(dnbinom(y,mu=lam,size=N,log=TRUE))+sum(dnorm(beta,betamn,sqrt(betavar),log=TRUE))

  mhratio=exp(mh1-mh2)
  if(mhratio > runif(1)){
    beta=betastar   
    lam=lamstar   
    beta.acc=beta.acc+1
  }

  ###
  ### Sample N 
  ###

  N.star=exp(rnorm(1,log(N),N.tune))

  mh1=sum(dnbinom(y,mu=lam,size=N.star,log=TRUE))+dnorm(log(N.star),logN.mn,logN.sd,log=TRUE)
  mh2=sum(dnbinom(y,mu=lam,size=N,log=TRUE))+dnorm(log(N),logN.mn,logN.sd,log=TRUE)
  
  mhratio=exp(mh1-mh2)
  if(mhratio > runif(1)){
    N=N.star
  }

  ###
  ### DIC Calculations 
  ###

  Davgsave[k]=-2*(sum(dnbinom(y,mu=lam,size=N,log=TRUE)))

  ###
  ### Obtain Predictions 
  ###

  ypred=rnbinom(n,mu=lam,size=N)

  mse.y[k]=mean((y-lam)^2)
  mse.ypred[k]=mean((ypred-lam)^2)

  msediffsave[k]=mse.ypred[k]-mse.y[k]
 
  msesave[k]=mean((ypred-y)^2)

  ###
  ### Save Samples 
  ###

  ypredsave[,k]=ypred
  betasave[,k]=beta
  Nsave[k]=N
  lamsave[,k]=lam

}
cat("\n");flush.console()

###
###  Calculate DIC 
###

postlammn=apply(lamsave[,-(1:n.burn)],1,mean)
Nmn=mean(Nsave[-(1:n.burn)])
Dhat=-2*(sum(dnbinom(y,mu=postlammn,size=Nmn,log=TRUE)))
Davg=mean(Davgsave[-(1:n.burn)])
pD=Davg-Dhat
DIC=2*Davg-Dhat

cat("Dhat:",Dhat,"Davg:",Davg,"pD:",pD,"DIC:",DIC,"\n")

###
### Calculate P-value based on MSE 
###

p.value=sum(mse.ypred>mse.y)/n.mcmc
 
###
###  Write output 
###

list(y=y,X=X,n.mcmc=n.mcmc,betasave=betasave,lamsave=lamsave,beta.acc=beta.acc,msediffsave=msediffsave,mse.y=mse.y,mse.ypred=mse.ypred,ypredsave=ypredsave,msesave=msesave,p.value=p.value,Nsave=Nsave)

}
