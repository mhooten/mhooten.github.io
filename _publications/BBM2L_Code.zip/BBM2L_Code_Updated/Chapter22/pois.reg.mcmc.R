pois.reg.mcmc <- function(y,X,betamn,betavar,n.mcmc,betatune=1){

#
#  Mevin Hooten (20080410)  Last Updated:  20111002
#  Poisson regression with uncorrelated errors
#
#  EXAMPLE USE:
#  ------------
#
#  tmp.out=pois.reg.mcmc(y,X,rep(0,dim(X)[2]),10,1000,.01)
#  matplot(t(tmp.out$betasave),type="l")
#
#

###
###  Subroutines
###


###
###  Preliminary Variables
###

n.burn=round(n.mcmc/10)
X=as.matrix(X)
y=as.vector(y)
n=length(y)
p=dim(X)[2]

mse.y=rep(0,n.mcmc)
mse.ypred=rep(0,n.mcmc)
msediffsave=rep(0,n.mcmc)
ypredsave=matrix(0,n,n.mcmc)
msesave=rep(0,n.mcmc)
betasave=matrix(0,p,n.mcmc)
lamsave=matrix(0,n,n.mcmc)
Davgsave=rep(0,n.mcmc)

###
###  Starting Values
###

beta=betamn
lam=exp(X%*%beta)
betasave[,1]=beta
lamsave[,1]=lam
beta.acc=1

###
###  Gibbs Loop
###

for(k in 1:n.mcmc){
  if(k%%100==0) cat(k," ");flush.console()

  ###
  ### Sample beta
  ###

  betastar=rnorm(p,beta,betatune)
  lamstar=exp(X%*%betastar)

  mh1=sum(dpois(y,lamstar,log=TRUE))+sum(dnorm(betastar,betamn,sqrt(betavar),log=TRUE))
  mh2=sum(dpois(y,lam,log=TRUE))+sum(dnorm(beta,betamn,sqrt(betavar),log=TRUE))

  mhratio=exp(mh1-mh2)
  if(mhratio > runif(1)){
    beta=betastar   
    lam=lamstar   
    beta.acc=beta.acc+1
  }

  ###
  ### DIC Calculations 
  ###

  Davgsave[k]=-2*(sum(dpois(y,lam,log=TRUE)))

  ###
  ### Obtain Predictions 
  ###

  ypred=rep(0,n)
  ypred=rpois(n,lam)

  mse.y[k]=mean((y-lam)^2)
  mse.ypred[k]=mean((ypred-lam)^2)

  msediffsave[k]=mse.ypred[k]-mse.y[k]
 
  msesave[k]=mean((ypred-y)^2)

  ###
  ### Save Samples 
  ###

  ypredsave[,k]=ypred
  betasave[,k]=beta
  lamsave[,k]=lam

}
cat("\n");flush.console()

###
###  Calculate DIC 
###

postlammn=apply(lamsave[,-(1:n.burn)],1,mean)
Dhat=-2*(sum(dpois(y,postlammn,log=TRUE)))
Davg=mean(Davgsave[-(1:n.burn)])
pD=Davg-Dhat
DIC=2*Davg-Dhat

cat("Dhat:",Dhat,"Davg:",Davg,"pD:",pD,"DIC:",DIC,"\n")

###
### Calculate P-value based on MSE 
###

p.value=sum(mse.ypred>mse.y)/n.mcmc
 
###
###  Write output 
###

list(y=y,X=X,n.mcmc=n.mcmc,betasave=betasave,lamsave=lamsave,beta.acc=beta.acc,msediffsave=msediffsave,mse.y=mse.y,mse.ypred=mse.ypred,ypredsave=ypredsave,msesave=msesave,p.value=p.value)

}
