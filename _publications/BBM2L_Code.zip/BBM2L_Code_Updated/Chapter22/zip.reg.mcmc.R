zip.reg.mcmc <- function(y,X,beta.mn,beta.var,n.mcmc){

###
###  Code Box 22.1
###

###
###  Preliminary Variables
###

X=as.matrix(X)
y=as.vector(y)
n=length(y)
pp=dim(X)[2]

beta.save=matrix(0,pp,n.mcmc)
lam.save=matrix(0,n,n.mcmc)
z.save=matrix(0,n,n.mcmc)
p.save=rep(0,n.mcmc)

###
###  Starting Values
###

beta.sd=sqrt(beta.var)
beta=beta.mn
z=rep(0,n)
z[y>0]=1
lam=exp(X%*%beta)
p=.9
beta.tune=.1

###
###  MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ### Sample z 
  ###

  p.tmp=p*exp(-lam[y==0])/(1-p+p*exp(-lam[y==0]))
  z[y==0]=rbinom(sum(y==0),1,p.tmp)

  ###
  ### Sample p 
  ###

  p=rbeta(1,sum(z)+1,n-sum(z)+1)

  ###
  ### Sample beta
  ###

  beta.star=rnorm(pp,beta,beta.tune)
  lam.star=exp(X%*%beta.star)
  mh1=sum(dpois(y[z==1],lam.star[z==1],log=TRUE))+sum(dnorm(beta.star,beta.mn,beta.sd,log=TRUE))
  mh2=sum(dpois(y[z==1],lam[z==1],log=TRUE))+sum(dnorm(beta,beta.mn,beta.sd,log=TRUE))
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    beta=beta.star   
    lam=lam.star   
  }

  ###
  ### Save Samples 
  ###

  z.save[,k]=z
  p.save[k]=p
  beta.save[,k]=beta
  lam.save[,k]=lam

}
cat("\n")

###
###  Write output 
###

list(y=y,X=X,n.mcmc=n.mcmc,beta.save=beta.save,p.save=p.save,z.save=z.save)

}
