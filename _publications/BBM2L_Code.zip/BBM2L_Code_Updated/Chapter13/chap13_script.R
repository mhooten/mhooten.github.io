###
###  Chapter 13 R Code
###

###
###  Code Box 13.2
###
###  Load Deer Data and Make Design Matrices
###

load("deer.RData")
n=dim(deer.df)[1]
y=deer.df$y
n=length(y)

L=11
X.list=vector("list",L)
X.list[[11]]=cbind(rep(1,n),as.matrix(deer.df[,c(2:5)]))
X.list[[11]][,2]=ifelse(X.list[[11]][,2]==599,0,1)

X.list[[1]]=X.list[[11]][,c(1,2)]
X.list[[2]]=X.list[[11]][,c(1,3)]
X.list[[3]]=X.list[[11]][,c(1,4)]
X.list[[4]]=X.list[[11]][,c(1,4:5)]
X.list[[5]]=X.list[[11]][,c(1,2:3)]
X.list[[6]]=X.list[[11]][,c(1,2,4)]
X.list[[7]]=X.list[[11]][,c(1,2,4,5)]
X.list[[8]]=X.list[[11]][,c(1,2,3,4)]
X.list[[9]]=X.list[[11]][,c(1,3,4)]
X.list[[10]]=X.list[[11]][,c(1,3,4,5)]

mcmc.out.list=vector("list",L)
DIC.vec=rep(0,L)
pD.vec=rep(0,L)
source("norm.reg.mcmc.DIC.R") #  Code Box 13.1
set.seed(1)
for(l in 1:L){
  p=dim(X.list[[l]])[2]
  mcmc.out.list[[l]]=norm.reg.mcmc.DIC(y=y,X=X.list[[l]],beta.mn=rep(0,p),beta.var=10000,s2.mn=50,s2.sd=1000,n.mcmc=10000)
  DIC.vec[l]=mcmc.out.list[[l]]$DIC
  pD.vec[l]=mcmc.out.list[[l]]$pD
}
cbind(1:L,pD.vec,DIC.vec)

