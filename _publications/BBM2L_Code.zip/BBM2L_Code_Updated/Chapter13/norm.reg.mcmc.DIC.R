norm.reg.mcmc.DIC <- function(y,X,beta.mn,beta.var,s2.mn,s2.sd,n.mcmc,no.print=FALSE){

###
### Code Box 13.1 
###

###
### Subroutines 
###

library(mvtnorm)

invgammastrt <- function(igmn,igvar){
  q <- 2+(igmn^2)/igvar
  r <- 1/(igmn*(q-1))
  list(r=r,q=q)
}

###
### Set up Variables and Hyperparameters
###

n=dim(X)[1]
p=dim(X)[2]
n.burn=round(.1*n.mcmc)
r=invgammastrt(s2.mn,s2.sd^2)$r
q=invgammastrt(s2.mn,s2.sd^2)$q
Sig.beta=beta.var*diag(p)

beta.save=matrix(0,p,n.mcmc)
s2.save=rep(0,n.mcmc)
Dbar=0
y.pred.mn=rep(0,n)

###
### Starting Values
###

beta=solve(t(X)%*%X)%*%t(X)%*%y

###
### MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%100==0) cat(k," ");flush.console()

  ###
  ### Sample s2
  ###

  tmp.r=(1/r+.5*t(y-X%*%beta)%*%(y-X%*%beta))^(-1)
  tmp.q=n/2+q

  s2=1/rgamma(1,tmp.q,,tmp.r) 

  ###
  ### Sample beta
  ###

  tmp.var=solve(t(X)%*%X/s2 + solve(Sig.beta))
  tmp.mn=tmp.var%*%(t(X)%*%y/s2 + solve(Sig.beta)%*%beta.mn)

  beta=as.vector(rmvnorm(1,tmp.mn,tmp.var,method="chol"))

  ###
  ### DIC Calculations 
  ###

  if(k > n.burn){
    Dbar=Dbar-2*sum(dnorm(y,X%*%beta,sqrt(s2),log=TRUE))/(n.mcmc-n.burn)
  }

  ###
  ### Posterior Predictive Calculations 
  ###

  if(k > n.burn){
    y.pred=rnorm(n,X%*%beta,sqrt(s2))
    y.pred.mn=y.pred.mn+y.pred/(n.mcmc-n.burn)
  }

  ###
  ### Save Samples
  ###
  
  beta.save[,k]=beta
  s2.save[k]=s2

}
cat("\n");flush.console()

###
###  Calculate DIC and Print to Screen
###

if(dim(X)[2]==1){
  postbetamn=mean(beta.save[,-(1:n.burn)])
}
if(dim(X)[2]>1){
  postbetamn=apply(beta.save[,-(1:n.burn)],1,mean)
}
posts2mn=mean(s2.save[-(1:n.burn)])
cat("Posterior Mean for Beta:","\n")
print(postbetamn)
cat("Posterior Mean for s2:","\n")
print(posts2mn)
Dhat=-2*(sum(dnorm(y,X%*%postbetamn,sqrt(posts2mn),log=TRUE)))
pD=Dbar-Dhat
DIC=Dhat+2*pD

cat("Dhat:",Dhat,"Dbar:",Dbar,"pD:",pD,"DIC:",DIC,"\n")

###
###  Write Output
###

list(beta.save=beta.save,s2.save=s2.save,y=y,X=X,n.mcmc=n.mcmc,n=n,r=r,q=q,p=p,Dhat=Dhat,Dbar=Dbar,pD=pD,DIC=DIC,y.pred.mn=y.pred.mn)

}
