###
###  Chapter 8 R Script
###

###
###  Code Box 8.1
###
###  Normal-IG Posterior
###

n=10
mu=2
s2=1
set.seed(1)
y=rnorm(n,mu,sqrt(s2))

s2.mn=2
s2.var=100
q=(s2.mn^2)/s2.var+2
r=1/(s2.mn*(q-1))

q.tilda=n/2+q
r.tilda=1/(sum((y-mu)^2)/2+1/r)

dIG <- function(x,r,q){x^(-(q+1))*exp(-1/r/x)/(r^q)/gamma(q)}

pdf(file="s2_post.pdf",width=8,height=5)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
curve(dIG(x,r.tilda,q.tilda),n=1000,from=0,to=6,lwd=1.5,xlab=bquote(sigma^2),ylab="Density")
curve(dIG(x,r,q),n=1000,from=0,to=6,lwd=1.5,lty=2,add=TRUE)
dev.off()

1/(r*(q-1))
1/(r.tilda*(q.tilda-1))

