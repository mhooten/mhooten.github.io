###
###  Chapter 23 R Script
###

###
###  Code Box 23.2
###
###  Read in Occupancy Data and fit Simple Occupancy Model
###

full.df=read.delim("PlosOne-DataFinnmark.txt",header=TRUE,sep="\t")
spp.idx=full.df$Species=="Willow Warbler"
y=apply(full.df[spp.idx,1:3],1,sum) # 2015 data  
n=length(y)
X=matrix(1,n,5)
X[,2]=scale(full.df[spp.idx,"Pland"])
X[,3]=scale(full.df[spp.idx,"ed"])
X[,4]=scale(full.df[spp.idx,"wheight"])
X[,5]=scale(full.df[spp.idx,"wpf"])

source("occ.simple.mcmc.R")  # Code Box 23.1
n.mcmc=50000
set.seed(1)
mcmc.out=occ.simple.mcmc(y=y,J=3,X=X,n.mcmc=n.mcmc)

#layout(matrix(1:2,2,1))
#matplot(t(mcmc.out$beta.save),type="l",lty=1)
#plot(mcmc.out$p.save,type="l")

pdf(file="occ_simple_post.pdf",width=8,height=10)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:6,3,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[0]),prob=TRUE,main="a")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[1]),prob=TRUE,main="b")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[2]),prob=TRUE,main="c")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[4,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[3]),prob=TRUE,main="d")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[5,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[4]),prob=TRUE,main="e")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$p.save[-(1:1000)],breaks=30,col=8,xlab="p",xlim=c(0,1),prob=TRUE,main="f")
curve(dunif(x),lwd=2,add=TRUE)
dev.off()

mean(mcmc.out$p.save[-(1:1000)])
quantile(mcmc.out$p.save[-(1:1000)],c(0.025,0.975))

pow.detect=1-(1-mcmc.out$p.save[-(1:1000)])^3
mean(pow.detect)
quantile(pow.detect,c(0.025,0.975))

###
###  Code Box 23.5
###
###  Fit General Occupancy Model 1
###

full.df=read.delim("PlosOne-DataFinnmark.txt",header=TRUE,sep="\t")
spp.idx=full.df$Species=="Willow Warbler"
y=apply(full.df[spp.idx,1:3],1,sum) # 2015 data  
n=length(y)
X=matrix(1,n,3)
X[,2]=scale(full.df[spp.idx,"Pland"])
X[,3]=scale(full.df[spp.idx,"wheight"])
W=matrix(1,n,3)
W[,2]=scale(full.df[spp.idx,"Pland"])
W[,3]=scale(full.df[spp.idx,"wheight"])

source("occ.gen1.mcmc.R")  #  Code Box 23.4
n.mcmc=300000
set.seed(1)
mcmc.out=occ.gen1.mcmc(y=y,J=rep(3,n),W=W,X=X,n.mcmc=n.mcmc)

#layout(matrix(1:2,2,1))
#matplot(t(mcmc.out$alpha.save),type="l",lty=1)
#matplot(t(mcmc.out$beta.save),type="l",lty=1)

pdf(file="occ_gen1_post.pdf",width=8,height=10)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:6,3,2))
hist(mcmc.out$alpha.save[1,-(1:1000)],breaks=30,col=8,xlab=bquote(alpha[0]),prob=TRUE,main="a")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$alpha.save[2,-(1:1000)],breaks=30,col=8,xlab=bquote(alpha[1]),prob=TRUE,main="c")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$alpha.save[3,-(1:1000)],breaks=30,col=8,xlab=bquote(alpha[2]),prob=TRUE,main="e")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[1,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[0]),prob=TRUE,main="b")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[1]),prob=TRUE,main="d")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,-(1:1000)],breaks=40,col=8,xlab=bquote(beta[2]),prob=TRUE,main="f")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
dev.off()

###
###  Code Box 23.7
###
###  Fit General Occupancy Model 2
###

full.df=read.delim("PlosOne-DataFinnmark.txt",header=TRUE,sep="\t")
spp.idx=full.df$Species=="Willow Warbler"
Y=as.matrix(full.df[spp.idx,1:3])   
n=dim(Y)[1]
J=dim(Y)[2]
X=matrix(1,n,3)
X[,2]=scale(full.df[spp.idx,"Pland"])
X[,3]=scale(full.df[spp.idx,"wheight"])
W=matrix(1,n*J,3)
W[,2]=scale(c(col(Y)))
W[,3]=rep(scale(full.df[spp.idx,"wheight"]),J)

source("occ.gen2.mcmc.R")  # Code Box 23.6
n.mcmc=300000
set.seed(1)
mcmc.out=occ.gen2.mcmc(Y=Y,J=J,W=W,X=X,n.mcmc=n.mcmc)

layout(matrix(1:2,2,1))
matplot(t(mcmc.out$alpha.save),type="l",lty=1)
abline(h=0,col=8)
matplot(t(mcmc.out$beta.save),type="l",lty=1)
abline(h=0,col=8)

pdf(file="occ_gen2_post.pdf",width=8,height=10)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:6,3,2))
hist(mcmc.out$alpha.save[1,-(1:1000)],breaks=30,col=8,xlab=bquote(alpha[0]),prob=TRUE,main="a")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$alpha.save[2,-(1:1000)],breaks=30,col=8,xlab=bquote(alpha[1]),prob=TRUE,main="c")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$alpha.save[3,-(1:1000)],breaks=30,col=8,xlab=bquote(alpha[2]),prob=TRUE,main="e")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[1,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[0]),prob=TRUE,main="b")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[1]),prob=TRUE,main="d")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[2]),prob=TRUE,main="f")
curve(dnorm(x,0,1.5),lwd=2,add=TRUE)
dev.off()

mean(mcmc.out$N.save[-(1:1000)])
quantile(mcmc.out$N.save[-(1:1000)],c(0.025,0.975))

###
###  Code Box 23.9
###
###  Fit General Occupancy Model using Auxiliary Variables 
###

full.df=read.delim("PlosOne-DataFinnmark.txt",header=TRUE,sep="\t")
spp.idx=full.df$Species=="Willow Warbler"
Y=as.matrix(full.df[spp.idx,1:3])   
n=dim(Y)[1]
J=dim(Y)[2]
X=matrix(1,n,3)
X[,2]=scale(full.df[spp.idx,"Pland"])
X[,3]=scale(full.df[spp.idx,"wheight"])
W=matrix(1,n*J,3)
W[,2]=scale(c(col(Y)))
W[,3]=rep(scale(full.df[spp.idx,"wheight"]),J)

source("occ.aux.mcmc.R")  # Code Box 23.8
n.mcmc=100000
set.seed(1)
mcmc.out=occ.aux.mcmc(Y=Y,J=J,W=W,X=X,n.mcmc=n.mcmc)

#layout(matrix(1:2,2,1))
#matplot(t(mcmc.out$alpha.save),type="l",lty=1)
#abline(h=0,col=8)
#matplot(t(mcmc.out$beta.save),type="l",lty=1)
#abline(h=0,col=8)

pdf(file="occ_aux_post.pdf",width=8,height=10)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:6,3,2))
hist(mcmc.out$alpha.save[1,-(1:1000)],breaks=30,col=8,xlab=bquote(alpha[0]),prob=TRUE,main="a")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
hist(mcmc.out$alpha.save[2,-(1:1000)],breaks=30,col=8,xlab=bquote(alpha[1]),prob=TRUE,main="c")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
hist(mcmc.out$alpha.save[3,-(1:1000)],breaks=30,col=8,xlab=bquote(alpha[2]),prob=TRUE,main="e")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[1,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[0]),prob=TRUE,main="b")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[1]),prob=TRUE,main="d")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,-(1:1000)],breaks=30,col=8,xlab=bquote(beta[2]),prob=TRUE,main="f")
curve(dnorm(x,0,1),lwd=2,add=TRUE)
dev.off()

mean(mcmc.out$N.save[-(1:1000)])
quantile(mcmc.out$N.save[-(1:1000)],c(0.025,0.975))

