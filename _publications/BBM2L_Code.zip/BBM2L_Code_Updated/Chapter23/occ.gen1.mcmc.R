occ.gen1.mcmc <- function(y,J,W,X,n.mcmc){

####
####  Libraries and Subroutines
####

logit.inv <- function(logit){
  exp(logit)/(1+exp(logit)) 
}

####
####  Create Variables 
####

n=length(y)
pX=dim(X)[2]
pW=dim(W)[2]
beta.save=matrix(0,pX,n.mcmc)
alpha.save=matrix(0,pW,n.mcmc)
z.mean=rep(0,n)
N.save=rep(0,n.mcmc)

####
####  Priors and Starting Values 
####

beta.mn=rep(0,pX)
alpha.mn=rep(0,pW)
beta.sd=1.5
alpha.sd=1.5
z=rep(0,n)
z[y>0]=1

beta=as.vector(glm(z ~ 0+X,family=binomial())$coefficients)
beta.tune=2*abs(beta)

alpha=as.vector(glm(cbind(y[y>1],J[y>1]-y[y>1]) ~ 0+W[y>1,],family=binomial())$coefficients)
alpha.tune=3*abs(alpha)

####
####  Begin MCMC Loop 
####

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ####
  ####  Sample beta 
  ####
  
  beta.star=rnorm(pX,beta,beta.tune)
  mh1=sum(dbinom(z,1,logit.inv(X%*%beta.star),log=TRUE))+sum(dnorm(beta.star,beta.mn,beta.sd,log=TRUE))
  mh2=sum(dbinom(z,1,logit.inv(X%*%beta),log=TRUE))+sum(dnorm(beta,beta.mn,beta.sd,log=TRUE))
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    beta=beta.star
  }
  psi=logit.inv(X%*%beta)

  ####
  ####  Sample alpha 
  ####

  alpha.star=rnorm(pW,alpha,alpha.tune)
  mh1=sum(dbinom(y[z==1],J[z==1],logit.inv(W[z==1,]%*%alpha.star),log=TRUE))+sum(dnorm(alpha.star,alpha.mn,alpha.sd,log=TRUE))
  mh2=sum(dbinom(y[z==1],J[z==1],logit.inv(W[z==1,]%*%alpha),log=TRUE))+sum(dnorm(alpha,alpha.mn,alpha.sd,log=TRUE))
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    alpha=alpha.star
  }
  p=logit.inv(W%*%alpha)
 
  ####
  ####  Sample z 
  ####

  num.tmp=psi*(1-p)^J 
  psi.tmp=num.tmp/(num.tmp+(1-psi))
  z[y==0]=rbinom(sum(y==0),1,psi.tmp[y==0])

  ####
  ####  Save Samples 
  ####

  beta.save[,k]=beta
  alpha.save[,k]=alpha
  z.mean=z.mean+z/n.mcmc
  N.save[k]=sum(z)

}
cat("\n")

####
####  Write Output 
####

list(beta.save=beta.save,alpha.save=alpha.save,N.save=N.save,z.mean=z.mean,n.mcmc=n.mcmc)

}
