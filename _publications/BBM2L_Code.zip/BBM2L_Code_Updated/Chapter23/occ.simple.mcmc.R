occ.simple.mcmc <- function(y,J,X,n.mcmc){

####
####  Code Box 23.1
####

####
####  Libraries and Subroutines
####

logit.inv <- function(logit){
  exp(logit)/(1+exp(logit)) 
}

####
####  Create Variables 
####

n=length(y)
pX=dim(X)[2]
beta.save=matrix(0,pX,n.mcmc)
z.mean=rep(0,n)
p.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)

####
####  Priors and Starting Values 
####

alpha.p=1
beta.p=1
beta.mn=rep(0,pX)
beta.sd=1.5
beta.var=beta.sd^2
z=rep(0,n)
z[y>0]=1

beta=as.vector(glm(z ~ 0+X,family=binomial())$coefficients)
beta.tune=1

####
####  Begin MCMC Loop 
####

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ####
  ####  Sample beta 
  ####
  
  beta.star=rnorm(pX,beta,beta.tune)
  mh1=sum(dbinom(z,1,logit.inv(X%*%beta.star),log=TRUE))+sum(dnorm(beta.star,beta.mn,beta.sd,log=TRUE))
  mh2=sum(dbinom(z,1,logit.inv(X%*%beta),log=TRUE))+sum(dnorm(beta,beta.mn,beta.sd,log=TRUE))
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    beta=beta.star
  }
  psi=logit.inv(X%*%beta)

  ####
  ####  Sample p 
  ####

  p=rbeta(1,sum(y[z==1])+alpha.p,sum((J-y)[z==1])+beta.p)
 
  ####
  ####  Sample z 
  ####

  num.tmp=psi*(1-p)^J 
  psi.tmp=num.tmp/(num.tmp+(1-psi))
  z[y==0]=rbinom(sum(y==0),1,psi.tmp[y==0])

  ####
  ####  Save Samples 
  ####

  beta.save[,k]=beta
  p.save[k]=p
  z.mean=z.mean+z/n.mcmc
  N.save[k]=sum(z)

}
cat("\n")

####
####  Write Output 
####

list(beta.save=beta.save,p.save=p.save,N.save=N.save,z.mean=z.mean,n.mcmc=n.mcmc)

}
