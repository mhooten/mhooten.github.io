###
###  Chapter 19 R Script 
###

###
###  Code Box 19.2
###
###  Read in Eye Temp Data and Fit Hierarchical Model
###

et.df=read.table("eyetemp.txt")
names(et.df)=c("id","sex","date","time","event","airtemp","relhum","sun","bodycond","eyetemp")
head(et.df)

id.unique=unique(et.df$id)
J=length(id.unique)
y.list=vector("list",J)
for(j in 1:J){
  y.list[[j]]=as.vector(et.df[et.df$id==id.unique[j],"eyetemp"])
}

source("norm.hier.mcmc.R") # Code Box 19.1
n.mcmc=50000
set.seed(1)
mcmc.out=norm.hier.mcmc(y.list=y.list,n.mcmc=n.mcmc)

#matplot(t(mcmc.out$muj.save),type="l",lty=1)
#matplot(t(sqrt(mcmc.out$s2j.save)),type="l",lty=1)

all.mu=rbind(mcmc.out$muj.save,mcmc.out$mu.save)
all.s2=rbind(mcmc.out$s2j.save,mcmc.out$s2.save)

pdf(file="hier_post.pdf",width=10,height=10)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:2,2,1))
plot(1:(J+1),rep(0,J+1),ylim=range(apply(all.mu,1,quantile,c(0.025,0.975))),ylab=bquote(mu["j"]),xlab="individual",xaxt="n",type="n",main="a")
mtext(bquote(mu),4,.5,cex=1.25)
axis(1,1:(J+1),labels=c(1:J,"pop"),cex.axis=1.1)
segments(1:(J+1),apply(all.mu,1,quantile,0.025),1:(J+1),apply(all.mu,1,quantile,0.975),lwd=2,lty=c(rep(1,J),6))
points(1:(J+1),apply(all.mu,1,mean),pch=20,cex=1.5)
abline(h=mean(mcmc.out$mu.save),col=8)
points(1:J,sapply(y.list,mean),pch=4,col=8,cex=1.5)
plot(1:(J+1),rep(0,J+1),ylim=range(apply(all.s2,1,quantile,c(0.025,0.975))),ylab=bquote(sigma["j"]^2),xlab="individual",xaxt="n",type="n",main="b")
mtext(bquote(sigma^2),4,.5,cex=1.25)
axis(1,1:(J+1),labels=c(1:J,"pop"),cex.axis=1.1)
segments(1:(J+1),apply(all.s2,1,quantile,0.025),1:(J+1),apply(all.s2,1,quantile,0.975),lwd=2,lty=c(rep(1,J),6))
points(1:(J+1),apply(all.s2,1,mean),pch=20,cex=1.5)
abline(h=mean(mcmc.out$s2.save),col=8)
dev.off()

###
###  Code Box 19.3
###
###  Nonhierarchical NNIG model for comparison
###

source("NNIG.mcmc.R")
set.seed(1)
NNIG.mcmc.out=NNIG.mcmc(y=unlist(y.list),mu0=0,s20=10000,q=0.001,r=1000,mu.strt=30,n.mcmc=n.mcmc)
mean(NNIG.mcmc.out$mu.save)
mean(mcmc.out$mu.save)
quantile(NNIG.mcmc.out$mu.save,c(0.025,0.975))
quantile(mcmc.out$mu.save,c(0.025,0.975))

###
###  Code Box 19.5
###
###  Lunn Method 
###

n.mcmc.1=100000
n.mcmc.2=10000
mu.mat=matrix(0,J,n.mcmc.2)
source("NNIG.mcmc.R")
set.seed(1)
for(j in 1:J){
  mu.mat[j,]=NNIG.mcmc(y=y.list[[j]],mu0=0,s20=10000,q=0.001,r=1000,mu.strt=30,n.mcmc=n.mcmc.1)$mu.save[round(seq(1,n.mcmc.1,,n.mcmc.2))]
}

source("norm.hier.L.mcmc.R")  # Code Box 19.4
mcmc.L.out=norm.hier.L.mcmc(muj.mat=mu.mat)

all.mu=rbind(mcmc.out$muj.save,mcmc.out$mu.save)
all.mu.L=rbind(mcmc.L.out$muj.save,mcmc.L.out$mu.save)
pdf(file="hier_L_post.pdf",width=10,height=5)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
plot(1:(J+1),rep(0,J+1),ylim=range(apply(all.mu,1,quantile,c(0.01,0.99))),ylab=bquote(mu["j"]),xlab="individual",xaxt="n",type="n")
mtext(bquote(mu),4,.5,cex=1.25)
axis(1,1:(J+1),labels=c(1:J,"pop"),cex.axis=1.1)
segments((1:(J+1))-0.15,apply(all.mu,1,quantile,0.025),(1:(J+1))-0.15,apply(all.mu,1,quantile,0.975),lwd=2,lty=c(rep(1,J),6))
points((1:(J+1))-0.15,apply(all.mu,1,mean),pch=20,cex=1.5)
segments((1:(J+1))+0.15,apply(all.mu.L,1,quantile,0.025),(1:(J+1))+0.15,apply(all.mu.L,1,quantile,0.975),lwd=2,lty=c(rep(1,J),6),col=8)
points((1:(J+1))+0.15,apply(all.mu.L,1,mean),pch=20,cex=1.5,col=8)
segments(1:J,apply(mu.mat,1,quantile,0.025),1:J,apply(mu.mat,1,quantile,0.975),lwd=2,col=gray(.5))
points(1:J,apply(mu.mat,1,mean),pch=20,cex=1.5,col=gray(.5))
dev.off()


