norm.hier.mcmc <- function(y.list,n.mcmc){

####
####  Code Box 19.1
####

####
####  Setup Variables 
####

J=length(y.list)
nj=sapply(y.list,length)

mu.save=rep(0,n.mcmc)
s2.save=rep(0,n.mcmc)

muj.save=matrix(0,J,n.mcmc)
s2j.save=matrix(0,J,n.mcmc)

####
####  Hyperparameters and Starting Values 
####

q=0.001
r=1000

mu.0=0
s2.0=10000

mu=mean(unlist(y.list))
muj=sapply(y.list,mean)
s2j=sapply(y.list,var)
rl=as.relistable(y.list)

####
####  Begin MCMC Loop 
####

for(k in 1:n.mcmc){
  if((k%%1000)==0) cat(k," ")

  ####
  ####  Sample s2 
  ####

  q.tmp=J/2+q
  r.tmp=1/(sum((muj-mu)^2)/2+1/r)
  s2=1/rgamma(1,q.tmp,,r.tmp)

  ####
  ####  Sample mu 
  ####

  tmp.var=1/(J/s2+1/s2.0)
  tmp.mn=tmp.var*(sum(muj)/s2+mu.0/s2.0)
  mu=rnorm(1,tmp.mn,sqrt(tmp.var))

  ####
  ####  Sample mu_j
  ####

  tmp.var=1/(nj/s2j+1/s2) 
  tmp.mn=tmp.var*(sapply(y.list,sum)/s2j+mu/s2)
  muj=rnorm(J,tmp.mn,sqrt(tmp.var))

  ####
  ####  Sample s2_j
  ####

  q.tmp=nj/2+q
  tmp.sum=relist((unlist(y.list)-rep(muj,nj))^2,rl)
  r.tmp=1/(sapply(tmp.sum,sum)/2+1/r)
  s2j=1/rgamma(J,q.tmp,,r.tmp)

  ####
  ####  Save Samples 
  ####

  mu.save[k]=mu
  s2.save[k]=s2
  muj.save[,k]=muj
  s2j.save[,k]=s2j

};cat("\n")

####
####  Write Output 
####

list(n.mcmc=n.mcmc,mu.save=mu.save,s2.save=s2.save,muj.save=muj.save,s2j.save=s2j.save)

}

