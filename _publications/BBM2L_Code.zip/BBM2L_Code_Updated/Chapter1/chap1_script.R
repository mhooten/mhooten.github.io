###
###  Code Box 1.1
###

n=5
set.seed(101)
p=runif(1)
p
y=rbinom(n,1,p)
y

