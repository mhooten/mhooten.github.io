gray.colors.rev <- function (n, start = 0, end = 1, gamma = 1){ 

#
#  Mevin Hooten (20080425)
#
#  For use with filled.contour()
#

gray(seq.int(to= start^gamma, from = end^gamma, length.out = n)^(1/gamma))

}
