draw.contour <- function (a, alpha = 0.95, limits = NULL, density.res = 300, 
    bw = NULL, ...) 
{
    require(MASS)
    if (is.matrix(a)) {
        a = list(x = a[, 1], y = a[, 2])
    }
    if (is.null(limits)) {
        limits = c(range(a$x), range(a$y))
        limits[1] = limits[1] - diff(range(a$x))/2
        limits[2] = limits[2] + diff(range(a$x))/2
        limits[3] = limits[3] - diff(range(a$y))/2
        limits[4] = limits[4] + diff(range(a$y))/2
    }
    if (!is.null(bw)) {
        f1 <- kde2d(a$x, a$y, h = bw, n = density.res, lims = limits)
    }
    if (is.null(bw)) {
        f1 <- kde2d(a$x, a$y, n = density.res, lims = limits)
    }
    zdens <- rev(sort(f1$z))
    Czdens <- cumsum(zdens)
    Czdens <- (Czdens/Czdens[length(zdens)])
    crit.val <- zdens[max(which(Czdens <= alpha))]
    b.full = contourLines(f1, levels = crit.val)
    b.full
}

