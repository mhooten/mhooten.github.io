###
###  Chapter 21 R Script
###

###
###  Code Box 21.2
###
###  Read in US bird richness data (and remove outliers) and fit Poisson regression models
###

bird.df=read.csv("birds.csv")
idx.outlier=(1:51)[(bird.df$spp==min(bird.df$spp) | bird.df$area==max(bird.df$area))]
bird.df=bird.df[-idx.outlier,]
#head(bird.df)

y=bird.df$spp
n=length(y)
L=6
X=vector("list",L)
X[[1]]=cbind(rep(1,n),scale(bird.df[,5]))
X[[2]]=cbind(rep(1,n),scale(bird.df[,6]))
X[[3]]=cbind(rep(1,n),scale(bird.df[,7]))
X[[4]]=cbind(rep(1,n),scale(bird.df[,5:6]))
X[[5]]=cbind(rep(1,n),scale(bird.df[,c(5,7)]))
X[[6]]=cbind(rep(1,n),scale(bird.df[,6:7]))

out.list=vector("list",L)
source("pois.reg.mcmc.R")  # Code Box 21.1
n.mcmc=20000
DIC.vec=rep(0,L)
set.seed(1)
for(l in 1:L){
  out.list[[l]]=pois.reg.mcmc(y=y,X=X[[l]],beta.mn=rep(0,dim(X[[l]])[2]),beta.var=1000,beta.tune=.01,n.mcmc=n.mcmc)
  DIC.vec[l]=out.list[[l]]$DIC
}

apply(out.list[[4]]$beta.save,1,mean)

apply(out.list[[4]]$beta.save,1,quantile,c(0.025,0.975))

###
###  Prepare Data for Section 21.2
###
###  Read in SPP Data and Make Plot 
###

library(raster)
library(MASS)
library(spatstat)
source("gray.colors.rev.R")
source("draw.contour.R")
source("draw.contour.2.R")
load("mtnlion.RData")
names(mtnlion.df)=c("x","y","time")

hr.tmp=draw.contour(mtnlion.df[,1:2],bw=NULL,alpha=.99)
n.contour=length(hr.tmp)
mat=matrix(0, nrow = n.contour, ncol = 1)
for(i in 1:n.contour) {
  mat[i]=length(hr.tmp[[i]]$x)
}
hr=owin(poly=list(list(x=rev(hr.tmp[[which.max(mat)]]$x[-1]),y=rev(hr.tmp[[which.max(mat)]]$y[-1]))))
pts=inside.owin(mtnlion.df$x,mtnlion.df$y,hr)
pts=data.frame(x=mtnlion.df$x,y=mtnlion.df$y,inout=pts)
pts=subset(pts,pts$inout=="TRUE")
pts.ppp=ppp(x=pts$x,y=pts$y,window=hr)
grid.hr.TF=inside.owin(grid.centers[,1],grid.centers[,2],hr)
elev.NA.rast=elevation.rast
values(elev.NA.rast)[!grid.hr.TF]=NA

mtnlion.count.rast=elev.NA.rast
values(mtnlion.count.rast)[grid.hr.TF]=0
mtnlion.cells=cellFromXY(elev.NA.rast,mtnlion.df[,1:2])
mtnlion.table=table(mtnlion.cells)
mtnlion.cell.idx=as.numeric(attr(table(mtnlion.cells),"dimnames")$mtnlion.cells)
values(mtnlion.count.rast)[mtnlion.cell.idx]=mtnlion.table

pdf(file="mtnlion_data.pdf",width=10,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,2,4,5))
layout(matrix(1:2,1,2))
plot(pts.ppp,type="n",cex=1.5,pch=19,cex.axis=1.2,cex.lab=1.5,cex.main=1.5,xlab="",ylab="",asp=TRUE,main="a")
points(pts.ppp,pch=19,col=rgb(0,0,0,alpha=.6))
lines(hr$bdry[[1]],lwd=3,col=rgb(0,0,0,alpha=.4))
plot(pts.ppp,type="n",cex=1.5,pch=19,col=0,cex.axis=1.2,cex.lab=1.5,cex.main=1.5,xlab="",ylab="",asp=TRUE,main="b")
plot(mtnlion.count.rast,col=gray.colors.rev(100),add=TRUE)
lines(hr$bdry[[1]],lwd=3,col=rgb(0,0,0,alpha=.4))
dev.off()

###
###  Make Plots of Covariate Data 
###

set.seed(101)
n.bg=1000
bg.ppp=rpoint(n.bg,win=hr)

elev.NA.rast=elevation.rast
slope.NA.rast=slope.rast
exposure.NA.rast=exposure.rast
values(elev.NA.rast)[!grid.hr.TF]=NA
values(slope.NA.rast)[!grid.hr.TF]=NA
values(exposure.NA.rast)[!grid.hr.TF]=NA
values(elev.NA.rast)[grid.hr.TF]=scale(values(elev.NA.rast)[grid.hr.TF])
values(slope.NA.rast)[grid.hr.TF]=scale(values(slope.NA.rast)[grid.hr.TF])
values(exposure.NA.rast)[grid.hr.TF]=scale(values(exposure.NA.rast)[grid.hr.TF])

pdf(file="mtnlion_covs.pdf",height=10,width=3.5)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5)
layout(matrix(1:3,3,1))
plot(pts.ppp,type="n",cex=1.5,pch=19,col=0,cex.axis=1.2,cex.lab=1.5,cex.main=1.5,xlab="",ylab="",asp=TRUE,main="a")
plot(elev.NA.rast,col=gray.colors.rev(100),add=TRUE)
plot(pts.ppp,type="n",cex=1.5,pch=19,col=0,cex.axis=1.2,cex.lab=1.5,cex.main=1.5,xlab="",ylab="",asp=TRUE,main="b")
plot(slope.NA.rast,col=gray.colors.rev(100),add=TRUE)
lines(hr$bdry[[1]],lwd=3,col=rgb(0,0,0,alpha=.4))
plot(pts.ppp,type="n",cex=1.5,pch=19,col=0,cex.axis=1.2,cex.lab=1.5,cex.main=1.5,xlab="",ylab="",asp=TRUE,main="c")
plot(exposure.NA.rast,col=gray.colors.rev(100),add=TRUE)
lines(hr$bdry[[1]],lwd=3,col=rgb(0,0,0,alpha=.4))
dev.off()

###
###  Code Box 21.3
###
###  Fit Poisson Regression Model to SPP Data
###

load("ml_pois.RData")
y=c(ml.df$y[!is.na(ml.df$y)])
X=model.matrix(y~elev+slope+exposure,family=poisson(link="log"),data=ml.df)
summary(glm(y~0+X))
source("pois.reg.mcmc.R")
n.mcmc=40000
mcmc.out=pois.reg.mcmc(y=y,X=X,beta.mn=rep(0,dim(X)[2]),beta.var=100,beta.tune=.1,n.mcmc)

matplot(t(mcmc.out$beta.save),type="l",lty=1)

pdf(file="mtnlion_post.pdf",width=8,height=8)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,],prob=TRUE,col=8,breaks=40,main="a",xlab=bquote(beta[0]))
curve(dnorm(x,0,10),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,],prob=TRUE,col=8,breaks=40,main="b",xlab=bquote(beta[1]))
curve(dnorm(x,0,10),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,],prob=TRUE,col=8,breaks=40,main="c",xlab=bquote(beta[2]))
curve(dnorm(x,0,10),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[4,],prob=TRUE,col=8,breaks=40,main="d",xlab=bquote(beta[3]))
curve(dnorm(x,0,10),lwd=2,add=TRUE)
dev.off()

###
###  Read in SSF Mountain Lion Data 
###

library(raster)
library(sp)
library(rgdal)
load("ml_ssf.RData")
source("gray.colors.rev.R")

SLO.rast=terrain(ELE.rast,opt='slope',unit='degrees')
ASP.rast=terrain(ELE.rast,opt='aspect',unit='degrees')
ELE.rast=scale(ELE.rast)
SLO.rast=scale(SLO.rast)
ASP.rast=cos((ASP.rast+135)*pi/180)

pdf(file="mtnlion_ssf_covs.pdf",height=10,width=3.5)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,bty="n")
layout(matrix(1:3,3,1))
plot(ELE.rast,col=gray.colors.rev(100,.3),axes=FALSE,main="a")
lines(ml.df[,1:2],type="o",cex=.5,lwd=3,col=1)
plot(SLO.rast,col=gray.colors.rev(100,.3),axes=FALSE,main="b")
lines(ml.df[,1:2],type="o",cex=.5,lwd=3,col=1)
plot(ASP.rast,col=gray.colors.rev(100,.3),axes=FALSE,main="c")
lines(ml.df[,1:2],type="o",cex=.5,lwd=3,col=1)
dev.off()

###
###  Code Box 21.5
###
###  Calculate Availability Regions for SSF Mountain Lion Data 
###

d.vec=sqrt(apply(apply(ml.df[,1:2],2,diff)^2,1,sum))
t.d.vec=diff(ml.df[,3])
d.sc=d.vec/t.d.vec
delta.star=quantile(d.sc,.95)

library(plotrix)
pdf(file="mtnlion_ssf_avail.pdf",height=10,width=10)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,bty="n")
plot(ELE.rast,col=gray.colors.rev(100,.3),axes=FALSE)
lines(ml.df[,1:2],type="o",cex=.5,lwd=1,col=1)
n=dim(ml.df)[1]
y=NULL
x.1=NULL
x.2=NULL
x.3=NULL
r.vec=NULL
n.0=NULL
n.vec=NULL
for(i in 2:n){ 
  if(i%%50==0) cat(i," ")
  r.vec=c(r.vec,delta.star*t.d.vec[i-1])
  draw.circle(ml.df[i-1,1],ml.df[i-1,2],r.vec[i-1],border=rgb(0,0,0,.6))
  x.1=c(x.1,unlist(extract(x=ELE.rast,y=ml.df[i,1:2],df=TRUE)[2]))
  x.2=c(x.2,unlist(extract(x=SLO.rast,y=ml.df[i,1:2],df=TRUE)[2]))
  x.3=c(x.3,unlist(extract(x=ASP.rast,y=ml.df[i,1:2],df=TRUE)[2]))
  y=c(y,1)
  tmp.1.extract=extract(x=ELE.rast,y=ml.df[i,1:2],buffer=r.vec[i-1],df=TRUE)[,2]
  tmp.2.extract=extract(x=SLO.rast,y=ml.df[i,1:2],buffer=r.vec[i-1],df=TRUE)[,2]
  tmp.3.extract=extract(x=ASP.rast,y=ml.df[i,1:2],buffer=r.vec[i-1],df=TRUE)[,2]
  n.0=c(n.0,length(tmp.1.extract))
  n.vec=c(n.vec,n.0[i-1]+1)
  x.1=c(x.1,unlist(tmp.1.extract))
  x.2=c(x.2,unlist(tmp.2.extract))
  x.3=c(x.3,unlist(tmp.3.extract))
  y=c(y,rep(0,n.0[i-1]))
};cat("\n")
dev.off()

###
###  Code Box 21.6
###
###  Fit CPR Model to SSF Mountain Lion Data 
###

X.cpr=cbind(x.1,x.2,x.3)
p=dim(X.cpr)[2]
idx=rep(1:(n-1),n.vec)

source("cpr.mcmc.R")  # Code Box 21.4
n.mcmc=20000
set.seed(1)
mcmc.out=cpr.mcmc(y=y,X=X.cpr,step.idx=idx,beta.mn=rep(0,p),beta.var=10000,beta.tune=0.05,n.mcmc=n.mcmc)

#matplot(t(mcmc.out$beta.save),type="l",lty=1)
#abline(h=coef(clogit(y~x.1+x.2+x.3+strata(idx),method="exact")),col=1:3)
#beta.post.mn=apply(mcmc.out$beta.save,1,mean)
#abline(h=beta.post.mn,lty=2,col=1:3)
#apply(mcmc.out$beta.save,1,sd)

pdf(file="mtnlion_ssf_post.pdf",width=10,height=3.5)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:3,1,3,byrow=TRUE))
hist(mcmc.out$beta.save[1,],prob=TRUE,col=8,breaks=40,main="a",xlab=bquote(beta[1]))
curve(dnorm(x,0,10),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,],prob=TRUE,col=8,breaks=40,main="b",xlab=bquote(beta[2]))
curve(dnorm(x,0,10),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[3,],prob=TRUE,col=8,breaks=40,main="c",xlab=bquote(beta[3]))
curve(dnorm(x,0,10),lwd=2,add=TRUE)
dev.off()

apply(mcmc.out$beta.save,1,mean)
apply(mcmc.out$beta.save,1,quantile,c(0.025,0.975))

###
###  Code Box 21.8
###
###  Load in Scaup Data (stratum 46, 1980-2009) and fit Poisson Malthusian model
###

y=c(13,14,40,84,113,53,71,42,80,57,45,20,47,24,49,199,173,185,133,204,308,368,185,234,618,177,353,193,206,152)
T=length(y)
years=1980:2009

source("pois.mg.mcmc.R") # Code Box 21.7
n.mcmc=20000
set.seed(1)
mcmc.out=pois.mg.mcmc(y=y,u=2,r.tune=.05,n.mcmc=n.mcmc)

quantile(mcmc.out$r.save,c(0.025,0.975))
mean(mcmc.out$r.save)

###
###  Code Box 21.9
###
###  Obtain Posterior Predictions from Scaup Data 
###

y.pred=y
y.pred.save=matrix(0,T+3,n.mcmc)
set.seed(1)
for(k in 1:n.mcmc){

  ###
  ### Sample y[1] 
  ###
  
  r=mcmc.out$r.save[k] 

  y1.star=rpois(1,y.pred[1])
  mh1=dpois(y[2],(1+r)*y1.star,log=TRUE)+dpois(y.pred[1],y1.star,log=TRUE)
  mh2=dpois(y[2],(1+r)*y.pred[1],log=TRUE)+dpois(y1.star,y.pred[1],log=TRUE)
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    y.pred[1]=y1.star
  }

  ###
  ### Sample y.pred[t] 
  ###

  for(t in 2:(T-1)){
    yt.star=rpois(1,y.pred[t])
    mh1=dpois(y[t+1],(1+r)*yt.star,log=TRUE)+dpois(yt.star,(1+r)*y[t-1],log=TRUE)+dpois(y.pred[t],yt.star,log=TRUE)
    mh2=dpois(y[t+1],(1+r)*y.pred[t],log=TRUE)+dpois(y.pred[t],(1+r)*y[t-1],log=TRUE)+dpois(yt.star,y.pred[t],log=TRUE)
    mh=exp(mh1-mh2)
    if(mh > runif(1)){
      y.pred[t]=yt.star
    }
  }

  ###
  ### Sample y.pred[T] 
  ###

  y.pred[T]=rpois(1,(1+r)*y[T-1])

  ###
  ### Sample y.pred[T+1], y.pred[T+2], y.pred[T+3]
  ###

  y.pred[T+1]=rpois(1,(1+r)*y[T])
  y.pred[T+2]=rpois(1,(1+r)*y.pred[T+1])
  y.pred[T+3]=rpois(1,(1+r)*y.pred[T+2])

  ###
  ### Save Predictions 
  ###

  y.pred.save[,k]=y.pred

}

y.m=apply(y.pred.save,1,mean)
y.u=apply(y.pred.save,1,quantile,.975)
y.l=apply(y.pred.save,1,quantile,.025)

years.pred=c(years,max(years)+1:3)

pdf(file="pois_mg_pred.pdf",width=10,height=6)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
matplot(years.pred,cbind(y.l,y.u),type="n",ylab="y",xlab="year")
polygon(c(years.pred,rev(years.pred)),c(y.u,rev(y.l)),col=rgb(0,0,0,.2),border=NA)
lines(years.pred,y.m,lwd=1.5)
points(years,y,lwd=1.5)
abline(v=2009,lty=2)
dev.off()

###
###  Code Box 21.10
###
###  Calculate Posterior Predictive P-value 
###

ind.TF=rep(0,n.mcmc)
for(k in 1:n.mcmc){
  mse.pred=mean((y.pred.save[2:T,k]-(1+mcmc.out$r.save[k])*y[-T])^2)
  mse.y=mean((y[-1]-(1+mcmc.out$r.save[k])*y[-T])^2)
  ind.TF[k]=mse.pred>mse.y
}
p.val=mean(ind.TF)
p.val

###
###  Code Box 21.12
###
###  Fit NB Model to Scaup Data 
###

source("nb.mg.mcmc.R")  #  Code Box 21.11
n.mcmc=50000
set.seed(1)
mcmc.out=nb.mg.mcmc(y=y,u=2,r.tune=0.05,logN.tune=.1,n.mcmc=n.mcmc)
mcmc.out$p.value
quantile(mcmc.out$r.save,c(0.025,0.975))

#layout(matrix(1:2,2,1))
#plot(mcmc.out$r.save,type="l")
#plot(mcmc.out$N.save,type="l")

pdf(file="nb_mg_post.pdf",width=10,height=5)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:2,1,2))
hist(mcmc.out$r.save,col=8,breaks=40,main="a",xlab="r",prob=TRUE)
curve(dunif(x,-1,2),lwd=2,add=TRUE)
hist(mcmc.out$N.save,col=8,breaks=40,main="b",xlab="N",prob=TRUE)
lines(density(exp(rnorm(100000,log(10),log(10)))),lwd=2)
dev.off()

years.pred=c(years,max(years)+1:3)
y.m=apply(mcmc.out$y.pred.save,1,mean)
y.u=apply(mcmc.out$y.pred.save,1,quantile,.975)
y.l=apply(mcmc.out$y.pred.save,1,quantile,.025)

years.pred=c(years,max(years)+1:3)

pdf(file="nb_mg_pred.pdf",width=10,height=6)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
matplot(years.pred,cbind(y.l,y.u),type="n",ylab="y",xlab="year")
polygon(c(years.pred,rev(years.pred)),c(y.u,rev(y.l)),col=rgb(0,0,0,.2),border=NA)
lines(years.pred,y.m,lwd=1.5)
points(years,y,lwd=1.5)
abline(v=2009,lty=2)
dev.off()

###
###  Code Box 21.14
###
###  Read in Bird Richness Data and Fit Quantile Model (known quantiles)
###

bird.df=read.csv("birds.csv")
idx.outlier=(1:51)[(bird.df$spp==min(bird.df$spp) | bird.df$area==max(bird.df$area))]
bird.df=bird.df[-idx.outlier,]
y=bird.df$spp
n=length(y)
X=matrix(1,n,2)
X[,2]=scale(bird.df$temp)
p=dim(X)[2]

tau.vec=c(.1,.25,.5,.75,.9)
n.tau=length(tau.vec)
out.list=vector("list",n.tau)
beta.mat=matrix(0,p,n.tau)
s.vec=rep(0,n.tau)
source("count.qr.mcmc.R") # Code Box 21.13
n.mcmc=20000
set.seed(1)
for(j in 1:n.tau){
  out.list[[j]]=count.qr.mcmc(y=y,X=X,tau=tau.vec[j],beta.mn=rep(0,p),beta.var=1000,s.u=1,n.mcmc=n.mcmc)
  beta.mat[,j]=apply(out.list[[j]]$beta.save,1,mean)
  s.vec[j]=mean(sqrt(out.list[[j]]$s2.save))
}
cbind(tau.vec,t(beta.mat),s.vec)

pdf(file="count_qr_fit.pdf",width=8,height=6)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
plot(X[,2],y,xlab="temp",ylab="bird spp richness")
for(j in 1:n.tau){
  lines(out.list[[j]]$X.pred[,2],out.list[[j]]$y.pred.mn,lwd=1.5)
}
dev.off()

###
###  Code Box 21.16
###
###  Fit Quantile Model to Bird Richness Data (estimate quantile)
###

source("count.qr.tau.mcmc.R")
n.mcmc=50000
set.seed(1)
mcmc.out=count.qr.tau.mcmc(y=y,X=X,tau=.5,beta.mn=rep(0,p),beta.var=1000,s.u=1,n.mcmc=n.mcmc)

#layout(matrix(1:3,3,1))
#matplot(t(mcmc.out$beta.save),type="l",lty=1)
#plot(mcmc.out$s2.save,type="l")
#plot(mcmc.out$tau.save,type="l")

keep.idx=mcmc.out$n.burn:n.mcmc
pdf(file="count_qr_tau_post.pdf",width=8,height=8)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:4,2,2,byrow=TRUE))
hist(mcmc.out$beta.save[1,keep.idx],prob=TRUE,col=8,breaks=30,main="a",xlab=bquote(beta[0]))
curve(dnorm(x,0,sqrt(10000)),lwd=2,add=TRUE)
hist(mcmc.out$beta.save[2,keep.idx],prob=TRUE,col=8,breaks=30,main="b",xlab=bquote(beta[1]))
curve(dnorm(x,0,sqrt(10000)),lwd=2,add=TRUE)
hist(sqrt(mcmc.out$s2.save[keep.idx]),prob=TRUE,col=8,breaks=40,main="c",xlab=bquote(sigma))
abline(h=1/100,lwd=2)
hist(mcmc.out$tau.save[keep.idx],prob=TRUE,col=8,breaks=30,xlim=c(0,1),main="d",xlab=bquote(tau))
abline(h=1,lwd=2)
dev.off()

mean(mcmc.out$tau.save[keep.idx])
quantile(mcmc.out$tau.save[keep.idx],c(0.025,0.975))

###
###  Code Box 21.18
###
###  Fit Binom-Beta-Pois model to simulated fish survival data 
###

y=c(15,11,12,5,12)
n=length(y)
lambda=50

source("binom.beta.pois.mcmc.R") # Code Box 21.17
n.mcmc=20000
set.seed(1)
mcmc.out=binom.beta.pois.mcmc(y=y,lambda=lambda,n.mcmc=n.mcmc)

pdf(file="binom_beta_pois_post.pdf",width=8,height=4)
par(cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:2,1,2))
hist(mcmc.out$phi.save[-(1:1000)],breaks=30,col=8,xlim=c(0,1),prob=TRUE,xlab=bquote(phi),main="a")
hist(mcmc.out$N.total.save[-(1:1000)],breaks=seq(180,330,1),col=8,prob=TRUE,xlab="N",ylab="Probability",main="b")
dev.off()

mean(mcmc.out$phi.save[-(1:1000)])
quantile(mcmc.out$phi.save[-(1:1000)],c(0.025,0.975))
quantile(mcmc.out$N.total.save[-(1:1000)],c(0.025,0.975))

