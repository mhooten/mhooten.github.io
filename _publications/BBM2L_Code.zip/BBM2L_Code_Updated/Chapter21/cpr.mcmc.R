cpr.mcmc <- function(y,X,step.idx,beta.mn,beta.var,beta.tune,n.mcmc){

###
###  Code Box 21.4
###

###
###  Subroutines and Libraries 
###

library(survival)
library(dplyr)

ldcpr<-function(loglam,lam,first.idx,step.idx){
  sum.1=sum(loglam[first.idx])
  tmp.df=data.frame(lam,step.idx)
  sum.2=sum(log(summarise(group_by(tmp.df,step.idx),sum(lam))[[2]]))
  sum.1-sum.2
}

###
###  Preliminary Variables
###

X=as.matrix(X)
n=dim(X)[1]
p=dim(X)[2]

beta.save=matrix(0,p,n.mcmc)

n.vec=rle(step.idx)$lengths
n.1=length(n.vec)
first.idx=c(1,cumsum(n.vec)[-((n.1-1):n.1)]+1)

###
###  Starting Values
###

beta=coef(clogit(y~X+strata(step.idx),method="exact"))

beta.sd=sqrt(beta.var)
loglam=as.vector(X%*%beta)
lam=exp(loglam)
loglik=ldcpr(loglam,lam,first.idx,step.idx)
beta.save[,1]=beta

###
###  MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%100==0) cat(k," ")

  ###
  ### Sample beta
  ###

  beta.star=rnorm(p,beta,beta.tune)
  loglam.star=as.vector(X%*%beta.star)
  lam.star=exp(loglam.star) 
  loglik.star=ldcpr(loglam.star,lam.star,first.idx,step.idx)
  mh1=loglik.star+sum(dnorm(beta.star,beta.mn,beta.sd,log=TRUE))
  mh2=loglik+sum(dnorm(beta,beta.mn,beta.sd,log=TRUE))
  mh=exp(mh1-mh2)

  if(mh > runif(1)){
    beta=beta.star   
    lam=lam.star   
    loglam=loglam.star   
    loglik=loglik.star
  }

  ###
  ### Save Samples 
  ###

  beta.save[,k]=beta

}
cat("\n")

###
###  Write output 
###

list(n.mcmc=n.mcmc,beta.save=beta.save)

}
