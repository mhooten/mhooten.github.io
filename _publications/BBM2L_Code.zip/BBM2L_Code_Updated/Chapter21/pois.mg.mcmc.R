pois.mg.mcmc <- function(y,u,r.tune,n.mcmc){

###
###  Code Box 21.7
###

###
###  Preliminary Variables
###

n.burn=round(n.mcmc/10)
y=as.vector(y)
T=length(y)
r.save=rep(0,n.mcmc)

###
###  Starting Values
###

r=0
Davg=0

###
###  MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ### Sample r 
  ###

  r.star=rnorm(1,r,r.tune)
  if((r.star > -1) & (r.star < u)){
    mh1=sum(dpois(y[-1],(1+r.star)*y[-T],log=TRUE))
    mh2=sum(dpois(y[-1],(1+r)*y[-T],log=TRUE))
    mhratio=exp(mh1-mh2)
    if(mhratio > runif(1)){
      r=r.star
    }
  }

  ###
  ### DIC Calculations 
  ###

  Davg=Davg-2*(sum(dpois(y[-1],(1+r)*y[-T],log=TRUE)))/(n.mcmc-n.burn)

  ###
  ### Save Samples 
  ###

  r.save[k]=r

}
cat("\n");flush.console()

###
###  Calculate DIC 
###

r.mean=mean(r.save[-(1:n.burn)])
Dhat=-2*(sum(dpois(y[-1],(1+r.mean)*y[-T],log=TRUE)))
pD=Davg-Dhat
DIC=2*Davg-Dhat

###
###  Write output 
###

list(y=y,n.mcmc=n.mcmc,r.save=r.save)

}
