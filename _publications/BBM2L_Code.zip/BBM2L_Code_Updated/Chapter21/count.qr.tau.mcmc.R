count.qr.tau.mcmc <- function(y,X,tau,beta.mn,beta.var,s.u,n.mcmc){

###
###  Code Box 21.15
###

###
### Subroutines 
###

ldasymlap <- function(y,tau,mu,sig){
  rho <- function(u){u*(tau-(u<0))}
  ld=log(tau)+log(1-tau)-log(sig)-rho((y-mu)/sig)
  ld
}

###
### Hyperpriors
###

n=dim(X)[1]
p=dim(X)[2]
n.burn=round(.1*n.mcmc)

Sig.beta.inv=solve(beta.var*diag(p))
beta.save=matrix(0,p,n.mcmc)
s2.save=rep(0,n.mcmc)
tau.save=rep(0,n.mcmc)

n.pred=100
y.pred.mn=rep(0,n.pred)

###
### Starting Values
###

beta=solve(t(X)%*%X)%*%t(X)%*%log(y+runif(n)-tau)

s.tune=.1
beta.tune=.05
tau.tune=.1

s2=(s.u^2)/100
sig=sqrt(s2)

X.pred=matrix(1,n.pred,p)
X.pred[,2]=seq(min(X[,2]),max(X[,2]),,n.pred)

###
### MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ### Sample u 
  ###

  u=runif(n)
  z=log(y+u-tau)

  ###
  ### Sample s
  ###

  s.star=rnorm(1,sig,s.tune)
  if((s.star < s.u) & (s.star > 0)){
    mh.1=sum(ldasymlap(z,tau,X%*%beta,s.star))
    mh.2=sum(ldasymlap(z,tau,X%*%beta,sig))
    mh=exp(mh.1-mh.2)
 
    if(mh > runif(1)){
      sig=s.star
    }
  }

  ###
  ### Sample beta
  ###

  beta.star=rnorm(p,beta,beta.tune)
  mh.1=sum(ldasymlap(z,tau,X%*%beta.star,sig))-0.5*t(beta.star-beta.mn)%*%Sig.beta.inv%*%(beta.star-beta.mn)
  mh.2=sum(ldasymlap(z,tau,X%*%beta,sig))-0.5*t(beta-beta.mn)%*%Sig.beta.inv%*%(beta-beta.mn)
  mh=exp(mh.1-mh.2)
  
  if(mh > runif(1)){
    beta=beta.star
  } 

  ###
  ### Sample tau (quantile) 
  ###
 
  tau.star=rnorm(1,tau,tau.tune)
  if((tau.star >0) & (tau.star<1)){
    mh.1=sum(ldasymlap(z,tau.star,X%*%beta,sig))
    mh.2=sum(ldasymlap(z,tau,X%*%beta,sig))
    mh=exp(mh.1-mh.2)
 
    if(mh > runif(1)){
      tau=tau.star
    }
  } 

  ###
  ### Posterior Predictive Calculations 
  ###
  
  if(k > n.burn){
    y.pred=ceiling(tau+exp(X.pred%*%beta)-1)
    y.pred.mn=y.pred.mn+y.pred/(n.mcmc-n.burn)
  }

  ###
  ### Save Samples
  ###
  
  beta.save[,k]=beta
  s2.save[k]=sig^2
  tau.save[k]=tau

}
cat("\n")

###
###  Write Output
###

list(beta.save=beta.save,s2.save=s2.save,y=y,X=X,n.mcmc=n.mcmc,n=n,p=p,tau.save=tau.save,y.pred.mn=y.pred.mn,X.pred=X.pred,n.burn=n.burn)

}
