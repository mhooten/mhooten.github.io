nb.mg.mcmc <- function(y,u,r.tune,logN.tune,n.mcmc){

###
###  Code Box 21.11
###

###
###  Preliminary Variables
###

n.burn=round(n.mcmc/10)
y=as.vector(y)
T=length(y)

mse.y=rep(0,n.mcmc)
mse.ypred=rep(0,n.mcmc)
msediffsave=rep(0,n.mcmc)
r.save=rep(0,n.mcmc)
N.save=rep(0,n.mcmc)
y.pred.save=matrix(0,T+3,n.mcmc)
msesave=rep(0,n.mcmc)
Davg=0

y.pred=y

###
###  Starting Values and hyperpriors
###

r=0
logN=log(10)

logN.mn=log(10)
logN.sd=log(10)

###
###  MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%1000==0) cat(k," ")

  ###
  ### Sample r 
  ###

  r.star=rnorm(1,r,r.tune)
  if((r.star > -1) & (r.star < u)){
    mh1=sum(dnbinom(y[-1],mu=(1+r.star)*y[-T],size=exp(logN),log=TRUE))
    mh2=sum(dnbinom(y[-1],mu=(1+r)*y[-T],size=exp(logN),log=TRUE))
    mhratio=exp(mh1-mh2)

    if(mhratio > runif(1)){
      r=r.star
    }
  }

  ###
  ### Sample logN 
  ###

  logN.star=rnorm(1,logN,logN.tune)

  mh1=sum(dnbinom(y[-1],mu=(1+r)*y[-T],size=exp(logN.star),log=TRUE))+dnorm(logN.star,logN.mn,logN.sd,log=TRUE)
  mh2=sum(dnbinom(y[-1],mu=(1+r)*y[-T],size=exp(logN),log=TRUE))+dnorm(logN,logN.mn,logN.sd,log=TRUE)
  mhratio=exp(mh1-mh2)

  if(mhratio > runif(1)){
    logN=logN.star
  }

  ###
  ### DIC Calculations 
  ###
 
  if(k > n.burn){
    Davg=Davg-2*(sum(dnbinom(y[-1],mu=(1+r)*y[-T],size=exp(logN),log=TRUE)))/(n.mcmc-n.burn)
  }

  ###
  ### Sample y[1] 
  ###
 
  y1.star=rpois(1,y.pred[1])
  mh1=dnbinom(y[2],mu=(1+r)*y1.star,size=exp(logN),log=TRUE)+dpois(y.pred[1],y1.star,log=TRUE)
  mh2=dnbinom(y[2],mu=(1+r)*y.pred[1],size=exp(logN),log=TRUE)+dpois(y1.star,y.pred[1],log=TRUE)
  mh=exp(mh1-mh2)
  if(mh > runif(1)){
    y.pred[1]=y1.star
  }

  ###
  ### Sample y[t] 
  ###

  for(t in 2:(T-1)){
    yt.star=rpois(1,y.pred[t])
    mh1=dnbinom(y[t+1],mu=(1+r)*yt.star,size=exp(logN),log=TRUE)+dnbinom(yt.star,mu=(1+r)*y[t-1],size=exp(logN),log=TRUE)+dpois(y.pred[t],yt.star,log=TRUE)
    mh2=dnbinom(y[t+1],mu=(1+r)*y.pred[t],size=exp(logN),log=TRUE)+dnbinom(y.pred[t],mu=(1+r)*y[t-1],size=exp(logN),log=TRUE)+dpois(yt.star,y.pred[t],log=TRUE)
    mh=exp(mh1-mh2)
    if(mh > runif(1)){
      y.pred[t]=yt.star
    }
  }

  ###
  ### Sample y[T], y[T+1], y[T+2], y[T+3] 
  ###

  y.pred[T]=rnbinom(1,mu=(1+r)*y[T-1],size=exp(logN))
  y.pred[T+1]=rnbinom(1,mu=(1+r)*y[T],size=exp(logN))
  y.pred[T+2]=rnbinom(1,mu=(1+r)*y.pred[T+1],size=exp(logN))
  y.pred[T+3]=rnbinom(1,mu=(1+r)*y.pred[T+2],size=exp(logN))

  ###
  ### Calculate MSE 
  ###

  mse.y[k]=mean((y[-1]-(1+r)*y[-T])^2)
  mse.ypred[k]=mean((y.pred[2:T]-(1+r)*y[-T])^2)
  msediffsave[k]=mse.ypred[k]-mse.y[k]
  msesave[k]=mean((y.pred[1:T]-y)^2)

  ###
  ### Save Samples 
  ###

  y.pred.save[,k]=y.pred
  r.save[k]=r
  N.save[k]=exp(logN)

}
cat("\n")

###
###  Calculate DIC 
###

r.mean=mean(r.save[-(1:n.burn)])
N.mean=mean(N.save[-(1:n.burn)])
Dhat=-2*(sum(dnbinom(y[-1],mu=(1+r.mean)*y[-T],size=N.mean,log=TRUE)))
pD=Davg-Dhat
DIC=2*Davg-Dhat

###
### Calculate P-value based on MSE 
###

p.value=mean((mse.ypred>mse.y)[n.burn:n.mcmc])
 
###
###  Write output 
###

list(y=y,n.mcmc=n.mcmc,r.save=r.save,p.value=p.value,N.save=N.save,y.pred.save=y.pred.save)

}
