binom.beta.pois.mcmc <- function(y,lambda,n.mcmc){

####
####  Code Box 21.17
####

####
####  Setup Variables 
####

n=length(y)

N.save=matrix(0,n,n.mcmc)
N.total.save=rep(0,n.mcmc)
phi.save=rep(0,n.mcmc)

####
####  Priors and Starting Values 
####

alpha=1
beta=1

N=y+1

####
####  Begin Gibbs Loop 
####
  
for(k in 1:n.mcmc){
  if(k%%1000==0){cat(k," ")}

  ####
  ####  Sample phi 
  ####

  phi=rbeta(1,sum(y)+alpha,sum(N-y)+beta)

  ####
  ####  Sample N 
  ####

  N=y+rpois(n,(1-phi)*lambda)

  ####
  ####  Save Samples 
  ####

  phi.save[k]=phi
  N.save[,k]=N
  N.total.save[k]=sum(N)

}
cat("\n")

####
####  Write Output 
####
 
list(n.mcmc=n.mcmc,phi.save=phi.save,N.save=N.save,N.total.save=N.total.save)

}
