###
###  Chapter 5 Script
###

###
###  Code Box 5.1
###
###  Posterior mean approximation with IS 
###

RNGkind(sample.kind = "Rounding")
set.seed(1)
theta=runif(1000)
w=dbinom(0,1,theta)
theta.mean=sum(theta*w)/sum(w)
theta.mean

###
###  Code Box 5.2
###
###  IS Resampling 
###

RNGkind(sample.kind = "Rounding")
set.seed(1)
theta1=runif(1000)
theta2=runif(10000)
theta3=runif(100000)

w1=dbinom(0,1,theta1)
w2=dbinom(0,1,theta2)
w3=dbinom(0,1,theta3)

theta1.resamp=sample(theta1,1000,replace=TRUE,prob=w1)
theta2.resamp=sample(theta2,10000,replace=TRUE,prob=w2)
theta3.resamp=sample(theta3,100000,replace=TRUE,prob=w3)

pdf(file="theta_IS_hist.pdf",width=8,height=3)
par(cex.lab=1.5,cex.lab=1.25,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:3,1,3))
hist(theta1.resamp,col=8,prob=TRUE,breaks=30,xlab=bquote(theta),main="a")
segments(0,2,1,0,lty=2)
hist(theta2.resamp,col=8,prob=TRUE,breaks=30,xlab=bquote(theta),main="b")
segments(0,2,1,0,lty=2)
hist(theta3.resamp,col=8,prob=TRUE,breaks=30,xlab=bquote(theta),main="c")
segments(0,2,1,0,lty=2)
dev.off()

