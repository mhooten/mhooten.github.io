###
###  Code Box 14.2
###
###  Compare mvn sampling methods
###

library(mvtnorm)
p=1000
X=matrix(rnorm(p^2),p,p)
A=t(X)%*%X
b=rnorm(p)

init.time=proc.time()
tmp.var=solve(A)
tmp.mn=tmp.var%*%b
y.1=as.vector(rmvnorm(1,tmp.mn,tmp.var,method="chol"))
(proc.time()-init.time)[3]

init.time=proc.time()
tmp.chol=chol(A)
y.2=backsolve(tmp.chol,backsolve(tmp.chol,b,transpose=TRUE)+rnorm(p))
(proc.time()-init.time)[3]

###
###  Load Deer Data and Make Design Matrices
###

load("deer.RData")
n=dim(deer.df)[1]
y=deer.df$y
n=length(y)
X=cbind(rep(1,n),scale(as.matrix(deer.df[,c(2:5)])))
p=dim(X)[2]
cor(X)

###
###  Code Box 14.3
###
###  Fit Models using MCMC and Cross-Validation
###

RNGkind(sample.kind = "Rounding")
K=10
set.seed(1)
rand.idx=sample(1:n,n) # randomize data for CV
X.rand=X[rand.idx,]
y.rand=y[rand.idx]
n.u=floor(n/K)
n.o=n.u*K-n.u
L=50
sig.beta.vec=seq(7,20,,L)
beta.mat=matrix(0,L,p)
spe.vec=rep(0,L)
source("norm.reg.ridge.cv.mcmc.R") # Code Box 14.1
for(l in 1:L){
  cat(l,"\n")
  for(k in 1:K){
    idx.u=(k-1)*n.u+(1:n.u)
    X.o=X.rand[-idx.u,]
    X.u=X.rand[idx.u,]
    y.o=y.rand[-idx.u]
    y.u=y.rand[idx.u]
    cat(k,"\n")
    p=dim(X)[2]
    mcmc.out=norm.reg.ridge.cv.mcmc(y=y.o,X=X.o,beta0.mn=0,beta0.var=10000,beta.mn=rep(0,p-1),beta.var=sig.beta.vec[l]^2,s2.mn=50,s2.sd=1000,n.mcmc=100000,X.pred=X.u)
    spe.vec[l]=spe.vec[l]+sum((y.u-mcmc.out$y.pred.mn)^2)
  }
  beta.mat[l,]=apply(norm.reg.ridge.cv.mcmc(y=y.rand,X=X.rand,beta0.mn=0,beta0.var=10000,beta.mn=rep(0,p-1),beta.var=sig.beta.vec[l]^2,s2.mn=50,s2.sd=1000,n.mcmc=100000,X.pred=matrix(0,2,p))$beta.save,1,mean)
}
#cbind(1:L,sig.beta.vec,spe.vec)
sig.beta.opt=sig.beta.vec[spe.vec==min(spe.vec)]

pdf(file="normreg_reg.pdf",width=7,height=12)
par(cex.lab=1.5,cex.lab=1.5,cex.main=1.5,mar=c(5,5,4,2))
layout(matrix(1:5,5,1))
plot(sig.beta.vec,beta.mat[,2],type="l",lwd=1.5,xlab=bquote(sigma[beta]),ylab=bquote(beta[1]),main="a")
abline(v=sig.beta.opt,col=8)
plot(sig.beta.vec,beta.mat[,3],type="l",lwd=1.5,xlab=bquote(sigma[beta]),ylab=bquote(beta[2]),main="b")
abline(v=sig.beta.opt,col=8)
plot(sig.beta.vec,beta.mat[,4],type="l",lwd=1.5,xlab=bquote(sigma[beta]),ylab=bquote(beta[3]),main="c")
abline(v=sig.beta.opt,col=8)
plot(sig.beta.vec,beta.mat[,5],type="l",lwd=1.5,xlab=bquote(sigma[beta]),ylab=bquote(beta[4]),main="d")
abline(v=sig.beta.opt,col=8)
plot(sig.beta.vec,spe.vec/n.u/K,type="l",lwd=1.5,xlab=bquote(sigma[beta]),ylab="MSPE",main="e")
abline(v=sig.beta.opt,col=8)
dev.off()


