norm.reg.ridge.cv.mcmc <- function(y,X,beta0.mn,beta0.var,beta.mn,beta.var,s2.mn,s2.sd,n.mcmc,X.pred){

###
### Code Box 14.1 
###

###
### Subroutines 
###

invgammastrt <- function(igmn,igvar){
  q <- 2+(igmn^2)/igvar
  r <- 1/(igmn*(q-1))
  list(r=r,q=q)
}

###
### Set up Variables and Hyperparameters
###

n=dim(X)[1]
n.pred=dim(X.pred)[1]
p=dim(X)[2]
n.burn=round(.1*n.mcmc)
r=invgammastrt(s2.mn,s2.sd^2)$r
q=invgammastrt(s2.mn,s2.sd^2)$q
beta.mn.all=c(beta0.mn,beta.mn)
Sig.beta=diag(p)
diag(Sig.beta)=c(beta0.var,rep(beta.var,p-1))
Sig.beta.inv=solve(Sig.beta)

beta.save=matrix(0,p,n.mcmc)
s2.save=rep(0,n.mcmc)
y.pred.mn=rep(0,n.pred)

###
### Starting Values
###

beta=solve(t(X)%*%X)%*%t(X)%*%y

###
### MCMC Loop
###

for(k in 1:n.mcmc){
  if(k%%10000==0) cat(k," ")

  ###
  ### Sample s2
  ###

  tmp.r=(1/r+.5*t(y-X%*%beta)%*%(y-X%*%beta))^(-1)
  tmp.q=n/2+q

  s2=1/rgamma(1,tmp.q,,tmp.r) 
  s=sqrt(s2)

  ###
  ### Sample beta
  ###

  tmp.chol=chol(t(X)%*%X/s2 + Sig.beta.inv)
  beta=backsolve(tmp.chol,backsolve(tmp.chol,t(X)%*%y/s2 + Sig.beta.inv%*%beta.mn.all,transpose=TRUE)+rnorm(p))

  ###
  ### Posterior Predictive Calculations 
  ###

  if(k > n.burn){
    y.pred.mn=y.pred.mn+X.pred%*%beta/(n.mcmc-n.burn)
  }

  ###
  ### Save Samples
  ###
  
  beta.save[,k]=beta
  s2.save[k]=s2

}
cat("\n")

###
###  Write Output
###

list(beta.save=beta.save,s2.save=s2.save,y=y,X=X,n.mcmc=n.mcmc,n=n,r=r,q=q,p=p,y.pred.mn=y.pred.mn)

}
